"""Reviewable public-contract integration and observability specifications."""
import json,copy,hashlib
from specification import OUT,save,version,s,FIELDS,obj,enum,sha
ROOT=OUT.parent.parent

def apply_patch(document,operations):
    result=copy.deepcopy(document)
    for op in operations:
        keys=[p.replace('~1','/').replace('~0','~') for p in op['path'].strip('/').split('/')];parent=result
        for k in keys[:-1]:parent=parent[k]
        k=keys[-1]
        if op['op']=='test':
            if parent[k]!=op['value']:raise ValueError('Patch precondition failed: '+op['path'])
        elif op['op']=='add':parent[k]=copy.deepcopy(op['value'])
        else:raise ValueError('Unsupported generated patch operation')
    return result

def public_preview():
    source=ROOT/'output/credit-workspace-backend-architecture/api/openapi.json';base=json.loads(source.read_text());ext=json.loads((OUT/'api/public-extensions.openapi.json').read_text())
    patch=[{'op':'test','path':'/info/version','value':base['info']['version']}]
    def add(path,value):patch.append({'op':'add','path':path,'value':value})
    def rewrite(x):
        if isinstance(x,dict):return {k:('#/components/schemas/ML'+v.rsplit('/',1)[-1] if k=='$ref' and v.startswith('#/components/schemas/') else rewrite(v)) for k,v in x.items()}
        if isinstance(x,list):return [rewrite(v) for v in x]
        return x
    add('/openapi','3.1.0')
    add('/info/version','1.3.0-design')
    add('/info/description',base['info'].get('description','')+' ML integration preview; source files unchanged. Financial requirements depend on server-side versioned product policy.')
    for n,sc in ext['components']['schemas'].items():
        if 'ML'+n in base['components']['schemas']:raise ValueError('Namespace collision '+n)
        add('/components/schemas/ML'+n,rewrite(sc))
    for path,methods in ext['paths'].items():
        if path in base['paths']:raise ValueError('Unexpected path collision '+path)
        add('/paths/'+path.replace('~','~0').replace('/','~1'),rewrite(methods))
    for n in ['Submit','InformationResponse','Application','InformationDraft']:add('/components/schemas/'+n+'/properties/financialStatementVersion',version())
    add('/components/schemas/Application/properties/financialSnapshotId',s())
    for n in ['Submit','InformationResponse']:add('/components/schemas/'+n+'/description',base['components']['schemas'][n].get('description','')+' financialStatementVersion обязателен для product requirements финансового baseline. Подтверждение проверяет сервер, financialSnapshotId создаётся сервером.')
    item=base['components']['schemas']['InformationItem']['properties']['fieldPath']['enum']
    add('/components/schemas/InformationItem/properties/fieldPath/enum',item+['financialStatement.values.'+f for f in FIELDS])
    add('/components/schemas/MLRankingMetadata',obj({'exposureId':s(),'releaseId':s(),'mode':enum('MODEL','RULES'),'candidateSetDigest':sha(),'catalogVersion':version(),'eligibilityVersion':version()},['exposureId','releaseId','mode','candidateSetDigest','catalogVersion']))
    for n in ['RecommendationList','Feed']:add('/components/schemas/'+n+'/properties/rankingMetadata',{'$ref':'#/components/schemas/MLRankingMetadata'})
    save('api/baseline-integration.patch.json',patch);save('api/integration-preview.openapi.json',apply_patch(base,patch))
    save('api/integration-preview-metadata.json',{'status':'REVIEW_ONLY_NOT_APPLIED_TO_BASELINE','baselinePath':str(source),'baselineSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'baselineVersion':base['info']['version'],'targetVersion':'1.3.0-design','originalOperations':49,'newOperations':11,'conditionalRequirements':'financialStatementVersion optional in global schema, required by versioned product requirements for new financial-baseline flows; existing applications remain supported.','submitDoesNotAcceptClientSnapshotId':True,'rfi':'Full financial draft is compared to saved version; non-requested fields must remain unchanged.'})

def observability():
    metrics=[
      ('credit_ml_requests_total','counter',['family','slot','result','mode'],'Requests: bounded result SUCCESS/ERROR/TIMEOUT/REJECTED and slot CHAMPION/CANDIDATE/FALLBACK.'),
      ('credit_ml_request_duration_seconds','histogram',['family','slot','mode'],'End-to-end duration including dependency reads.'),
      ('credit_ml_fallback_total','counter',['family','reason'],'Fallback, bounded allowlist reason.'),
      ('credit_ml_inflight','gauge',['family','slot'],'Active requests.'),
      ('credit_ml_oldest_job_age_seconds','gauge',['queue_kind'],'OCR/EMBEDDING/TRAIN/EVALUATE/KB_PURGE queues.'),
      ('credit_ml_dq_failures_total','counter',['family','check_kind'],'Schema, availability, units, missingness, digest, parity.'),
      ('credit_ml_report_last_success_timestamp_seconds','gauge',['family','report_kind'],'Unix time of last complete report.'),
      ('credit_ml_quality_score','gauge',['family','metric','cohort_kind'],'Quality only with enough mature/verified labels; absent otherwise.'),
      ('credit_ml_quality_sample_size','gauge',['family','metric','cohort_kind'],'Quality denominator.'),
      ('credit_ml_release_info','gauge',['family','slot','bundle_digest'],'Only currently active/current/previous bundles; not per request.'),
      ('credit_rag_revoked_source_exposures_total','counter',['stage'],'Any positive increment is critical; RETRIEVAL/CONTEXT/OUTPUT/HISTORY.'),
      ('credit_rag_revocation_enforcement_age_seconds','gauge',['corpus_kind'],'Oldest pending revocation, no document label.'),
      ('credit_rag_no_answer_total','counter',['reason'],'No evidence, conflicting sources, access unavailable.'),
      ('credit_recsys_ineligible_output_total','counter',['scope'],'Rejected model output before display.'),
      ('credit_ml_approval_wait_age_seconds','gauge',['family'],'Oldest validated candidate waiting approval.'),
      ('credit_ml_update_requests_total','counter',['family','state'],'Durable update transitions.'),
      ('credit_ml_monitor_heartbeat_timestamp_seconds','gauge',['component'],'Independent monitoring heartbeat.')]
    save('observability/metrics-catalog.json',{'status':'DESIGN_INSTRUMENTATION_CONTRACT_NOT_DEPLOYED','labelsPolicy':'No actor/company/application/document IDs, raw questions, exception strings or feature values. Bounded enums only.','durationBucketsSeconds':[.01,.025,.05,.1,.15,.3,.5,1,2,5,10,20,30],'metrics':[dict(name=n,type=t,labels=l,meaning=m) for n,t,l,m in metrics]})
    panels=[
      dict(id='online',title='Online health',queries={'rps':'sum by (family) (rate(credit_ml_requests_total[5m]))','p95':'histogram_quantile(0.95, sum by (le, family, slot) (rate(credit_ml_request_duration_seconds_bucket[5m])))','fallback':'sum by (family) (rate(credit_ml_fallback_total[15m])) / clamp_min(sum by (family) (rate(credit_ml_requests_total[15m])), 0.001)'},owner='SRE + serving'),
      dict(id='data',title='Data health',queries={'dq':'sum by (family, check_kind) (increase(credit_ml_dq_failures_total[15m]))','queueAge':'credit_ml_oldest_job_age_seconds'},owner='Data owner'),
      dict(id='quality',title='Model quality and maturity',queries={'quality':'credit_ml_quality_score','denominator':'credit_ml_quality_sample_size'},owner='Risk/ML validator'),
      dict(id='rag',title='RAG and KB safety',queries={'revoked':'sum(increase(credit_rag_revoked_source_exposures_total[5m]))','enforcementAge':'credit_rag_revocation_enforcement_age_seconds','noAnswer':'sum by (reason) (rate(credit_rag_no_answer_total[15m]))'},owner='Content + ML'),
      dict(id='release',title='Lifecycle and approvals',queries={'active':'credit_ml_release_info','approvalAge':'credit_ml_approval_wait_age_seconds','updates':'sum by (family, state) (increase(credit_ml_update_requests_total[1d]))'},owner='ML platform'),
      dict(id='resources',title='CPU/GPU and capacity',queries={'gpuMemory':'DCGM_FI_DEV_FB_USED','gpuUtilization':'DCGM_FI_DEV_GPU_UTIL','inflight':'credit_ml_inflight'},owner='Platform; DCGM exporter compatibility required')]
    alerts=[
      dict(name='MLHighErrorRate',expr='sum by (family) (rate(credit_ml_requests_total{result=~"ERROR|TIMEOUT"}[5m])) / clamp_min(sum by (family) (rate(credit_ml_requests_total[5m])), 0.001) > 0.01 and on(family) sum by(family) (increase(credit_ml_requests_total[5m])) >= 100',forDuration='5m',action='Hold rollout; inspect dependency/data errors.'),
      dict(name='RevokedKBExposure',expr='sum(increase(credit_rag_revoked_source_exposures_total[5m])) > 0',forDuration='0m',action='Critical fail-closed; stop canary; investigate fence/authority. Rollback cannot remove deny.'),
      dict(name='RevocationNotEnforced',expr='max(credit_rag_revocation_enforcement_age_seconds) > 5',forDuration='0m',action='Keep RAG closed until ENFORCED.'),
      dict(name='MLQueueOldestAge',expr='max by(queue_kind) (credit_ml_oldest_job_age_seconds) > 300',forDuration='5m',action='Admission control; defer training/evaluation and inspect drain capacity.'),
      dict(name='MLMonitorHeartbeatMissing',expr='time() - credit_ml_monitor_heartbeat_timestamp_seconds > 300 or absent(credit_ml_monitor_heartbeat_timestamp_seconds)',forDuration='5m',action='Independent SRE path; missing monitor is not healthy quality.')]
    save('observability/dashboard-specs.json',{'format':'DESIGN_SPEC_NOT_GRAFANA_IMPORT_JSON','panels':panels,'alerts':alerts,'reportStorage':'governed S3 with reference/current/evaluation versions','productionGate':'PromQL/rules must be exercised on a real Prometheus/Grafana installation. This package validates catalog consistency, not PromQL execution.'})

def write_all():public_preview();observability()
