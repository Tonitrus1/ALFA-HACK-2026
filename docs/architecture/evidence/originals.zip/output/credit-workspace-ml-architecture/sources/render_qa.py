"""Render every final page and record objective bounds; human visual review is separate."""
from pathlib import Path
import sys,json,hashlib,os
import pypdfium2 as pdfium
from PIL import Image,ImageOps,ImageDraw,ImageFont
OUT=Path(__file__).resolve().parents[1];TMP=OUT.parent.parent/'tmp/ml-pdfs/qa';TMP.mkdir(parents=True,exist_ok=True)
FONT=str(Path(os.environ.get('CREDIT_FONT_DIR','/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/LibreOfficeDev.app/Contents/Resources/fonts/truetype'))/'DejaVuSans.ttf')
def main():
    reports=[];index=[]
    for name in ['ml-system-guide.pdf','ml-architecture-atlas.pdf']:
        p=OUT/name;doc=pdfium.PdfDocument(p);pages=[];previews=[]
        for i in range(len(doc)):
            page=doc[i];tp=page.get_textpage();w,h=page.get_size();outside=[];text=tp.get_text_range()
            for n in range(tp.count_chars()):
                ch=tp.get_text_range(n,1)
                if ch.isspace():continue
                l,b,r,t=tp.get_charbox(n)
                if l < -1 or b < -1 or r>w+1 or t>h+1:outside.append({'char':ch,'box':[l,b,r,t]})
            png=TMP/(p.stem+'-%02d.png'%(i+1));im=page.render(scale=1.6 if 'atlas' in name else 1.4).to_pil().convert('RGB');im.save(png)
            previews.append(png);pages.append({'page':i+1,'widthPt':w,'heightPt':h,'characters':tp.count_chars(),'outside':outside,'replacementCharacters':text.count('\ufffd'),'preview':str(png)})
            tp.close();page.close()
        doc.close();reports.append({'file':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'pages':pages})
        cols=3 if 'guide' in name else 2;rows=3 if 'guide' in name else 2;tw=360 if 'guide' in name else 650;th=510 if 'guide' in name else 470
        font=ImageFont.truetype(FONT,16)
        for start in range(0,len(previews),cols*rows):
            subset=previews[start:start+cols*rows];sheet=Image.new('RGB',(cols*tw,rows*(th+32)),(225,231,237));draw=ImageDraw.Draw(sheet)
            for j,fp in enumerate(subset):
                im=Image.open(fp);im.thumbnail((tw-16,th-10));x=(j%cols)*tw+(tw-im.width)//2;y=(j//cols)*(th+32)+28
                sheet.paste(im,(x,y));draw.text(((j%cols)*tw+10,(j//cols)*(th+32)+6),f'{p.stem} / {start+j+1}',font=font,fill='#182839')
            path=TMP/(p.stem+'-contact-%02d.png'%(start//(cols*rows)+1));sheet.save(path);index.append({'pdf':name,'firstPage':start+1,'lastPage':start+len(subset),'contactSheet':str(path)})
    report={'scope':'All PDF pages rendered; exact character bounds checked. Contact sheets and selected full pages require visual inspection.','files':reports,'outOfBoundsCount':sum(len(p['outside']) for f in reports for p in f['pages']),'replacementCharacterCount':sum(p['replacementCharacters'] for f in reports for p in f['pages'])}
    (OUT/'pdf-geometry-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(TMP/'index.json').write_text(json.dumps(index,indent=2)+'\n')
    print(json.dumps({'pages':sum(len(r['pages']) for r in reports),'outOfBounds':report['outOfBoundsCount'],'replacementCharacters':report['replacementCharacterCount'],'contactSheets':index},ensure_ascii=False))
if __name__=='__main__':main()
