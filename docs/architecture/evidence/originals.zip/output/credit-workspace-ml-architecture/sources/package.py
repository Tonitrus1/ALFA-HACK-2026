"""Package only reviewed static architecture artifacts, not runtime services."""
from pathlib import Path
import sys,json,hashlib,zipfile
from specification import OUT
from validate import main as validate
def main():
    if validate():raise SystemExit('Validation failed')
    review=json.loads((OUT/'visual-review.json').read_text())
    if review.get('status')!='PASS':raise SystemExit('Visual review missing')
    for name,h in review['pdfSha256'].items():
        if hashlib.sha256((OUT/name).read_bytes()).hexdigest()!=h:raise SystemExit('Stale visual review: '+name)
    geometry=json.loads((OUT/'pdf-geometry-review.json').read_text())
    if geometry['outOfBoundsCount'] or geometry['replacementCharacterCount']:raise SystemExit('PDF geometry failed')
    for f in geometry['files']:
        if hashlib.sha256((OUT/f['file']).read_bytes()).hexdigest()!=f['sha256']:raise SystemExit('Stale PDF geometry: '+f['file'])
    files=[p for p in sorted(OUT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ['.DS_Store','checksums.json']]
    hashes={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (OUT/'checksums.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2)+'\n')
    zip_path=OUT.parent/(OUT.name+'.zip')
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files+[OUT/'checksums.json']:z.write(p,str(p.relative_to(OUT.parent)))
    print(json.dumps({'zip':str(zip_path),'files':len(files)+1,'bytes':zip_path.stat().st_size},ensure_ascii=False))
if __name__=='__main__':main()
