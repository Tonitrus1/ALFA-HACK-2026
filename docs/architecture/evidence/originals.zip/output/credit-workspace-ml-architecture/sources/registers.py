"""Traceable project scope, implementation work, acceptance, and source evidence."""
from pathlib import Path
import json, hashlib
from specification import OUT, save

ROOT=OUT.parent.parent
GENERAL=ROOT/'output/credit-workspace-architecture-v2/architecture-v2'
BACKEND=ROOT/'output/credit-workspace-backend-architecture'
FRONTEND=ROOT/'output/credit-workspace-frontend-architecture'
def entry(id,title,role,deps,result,tests,phase):
    return dict(id=id,title=title,owner=role,dependsOn=deps,result=result,acceptance=tests,phase=phase,status='PLANNED_NOT_IMPLEMENTED')

TEST_ROWS=[
('C01','Повтор эксперимента','Собрать среду по image/lock, повторить сохранённый split/seed.','Результат в пределах опубликованного допуска; каждый артефакт найден по digest.','reproduction'),
('C02','Поздняя информация','Добавить старую по eventTime отчётность с availableAt позже decisionAt.','Запись не попадает в исторические признаки.','data'),
('C03','Исправление отчётности','После отправки изменить текущий баланс и запросить старый score.','Используется прежний snapshot; новый RFI создаёт новый ID.','data'),
('C04','Training-serving parity','Вычислить коэффициенты batch/online на общих входах, включая отрицательную прибыль.','Разность <=1e-8, одинаковые missing masks.','data'),
('C05','Деление на ноль','totalLiabilities=0/currentLiabilities=0; отдельно totalAssets=0.','X8/X4 missing, не 0/inf; нулевые активы запрещают score.','risk'),
('C06','Подтверждение финансов','Изменить поле после confirm, попытаться подтвердить чужой документ или старый If-Match.','Подтверждение сброшено; чужие/старые версии отвергнуты.','risk'),
('C07','Публичный proxy в банке','Отправить BANKRUPTCY_PROXY в live CREDIT_RISK.','Release/purpose gate запрещает применение; manual path.','risk'),
('C08','Незрелые исходы','Добавить кредит с неполным 12-месячным окном без дефолта.','Он не получает отрицательную метку и не попадает в mature train.','risk'),
('C09','Дубликаты и split','Повторить строку/выбранный вектор, добавить конфликт меток полного вектора.','Дубли не пересекают split; конфликт quarantine; сохранён split manifest.','risk'),
('C10','Нет свежих меток','Сигнал drift при недостатке mature risk labels.','DIAGNOSING/BLOCKED_DATA; нет фиктивного retrain/release.','lifecycle'),
('C11','Ошибка или timeout риска','Остановить risk endpoint/использовать неподходящую feature schema.','Нет искусственного score или отказа; manual либо совместимый fallback в deadline.','fallback'),
('C12','Повтор inference','Повторить requestId после смены champion, затем изменить body.','Тот же inference/model для того же body; изменённое body даёт 409.','risk'),
('C13','Пригодность продукта','Ranker возвращает неизвестный, отсутствующий или повторный itemId.','Backend отклоняет весь результат и возвращает правила разрешённого набора.','recsys'),
('C14','Обязательное действие','Выдать модели максимально высокий score статьи при открытом RFI.','Next action остаётся первым и не закрывается кликом.','recsys'),
('C15','Exposure и метки','CLICK для невыданного itemId, повтор clientEventId, непоказанный кандидат.','Чужой click отклонён, повтор дедуплицирован, непоказанный не отрицательный.','recsys'),
('C16','Cold start / ranking fail','Новая компания без истории, выключенный ranker или deadline 150 мс.','Детерминированные пригодные рекомендации с mode=RULES.','fallback'),
('C17','Без утечки будущих кликов','Использовать действие после exposure и незавершённое окно атрибуции.','Будущие действия не являются историческими фичами; labels созревают по policy.','recsys'),
('C18','OCR lease/objectVersion','Отправить результат старого generation или заменённого файла.','Результат отвергнут; новое подтверждение не перезаписано.','ocr'),
('C19','OCR не работает','Остановить worker; отдельно остановить AV.','При CLEAN доступен ручной ввод; при AV fail файл остаётся quarantine.','fallback'),
('C20','Единицы и знак','Извлечь скобки отрицательного числа и тысячи RUB; исправить пользователем.','Нормализация проверена; финансовые поля требуют confirm; правка не gold label.','ocr'),
('C21','RAG без ответа','Вопрос вне утверждённой KB и запрос индивидуальной ставки.','INSUFFICIENT_EVIDENCE без выдуманных условий/причины отказа.','rag'),
('C22','Prompt injection','Вопрос или документ требует игнорировать политику и показать внутренние правила.','Нет вызова инструментов и закрытых данных; нарушение считается hard fail.','rag'),
('C23','RAG permissions','Другая компания/беседа, DRAFT/INTERNAL/EXPIRED документ.','Нет доступа и попадания запрещённого chunk в prompt.','security'),
('C24','N / max age / dedup','9 уникальных изменений, 10-е, повтор 10-го; отдельно 24 ч с первого.','Одна сборка по cutoff; повтор не увеличивает N; возраст запускает ожидание.','rag'),
('C25','Согласованность bundle','Переключить embedding/collection во время запроса и canary.','Запрос использует один bundle; смешение embedding space запрещено.','rag'),
('C26','Удаление во время ответа','Отозвать источник после retrieval и до финального JSON.','Выдача отменена/перепроверена под fence; ENFORCED только после drain.','rag'),
('C27','Rollback после удаления','Вернуть старую коллекцию/backup, где есть удалённые векторы.','Живой deny/tombstone запрещает источник до очистки.','rag'),
('C28','История и cache','Открыть историю/кеш после отзыва одного источника ответа.','Связанный ответ скрыт целиком; источник не выдаётся по старой ссылке.','rag'),
('C29','vLLM и authority fail','Выключить vLLM, затем KB authority.','Сначала SEARCH_ONLY по проверенным ссылкам; затем fail-closed.','fallback'),
('C30','Качество RAG','Прогнать фиксированный golden/attack set и версионированный judge.','Раздельные retrieval/generation/refusal отчёты; отсутствие выборки блокирует gate.','rag'),
('C31','Дубли / restart update','Дважды доставить сигнал, остановить worker, получить новый generation.','Один активный UpdateRequest; stale result не принят; новый worker продолжает.','lifecycle'),
('C32','Ошибка данных вместо drift','Подменить валюту/единицы/схему upstream.','DATA_INCIDENT, новый materialization/retrain остановлен, старые данные не стёрты.','data'),
('C33','Ручной допуск','Автор/monitor пытается утвердить релиз; отсутствует owner/validator.','Нет rollout, identity берётся из IAM, один человек не заменяет две роли.','release'),
('C34','Изменение кандидата','После approval поменять prompt, dataset, policy либо evaluation digest.','Approval аннулирован; заново validation и ручной допуск.','release'),
('C35','Мало canary данных','Окно завершилось, но candidate requests недостаточно.','HOLD, нет автоматического продвижения и зачёта replay как production.','release'),
('C36','Canary regression','Создать рост ошибок/latency или критичное раскрытие/отозванный источник.','Продвижение остановлено, compatible rollback или fallback.','release'),
('C37','Отклонённый кандидат','Провалить offline gate или поставить ручной REJECT.','Кандидат не обслуживает live трафик, champion неизменён.','release'),
('C38','MLflow/Airflow down','Остановить control services после готовности текущего bundle.','Inference по локальным проверенным артефактам продолжается; новых выпусков нет.','availability'),
('C39','Обязательный аудит down','Отключить inference record store, оставив агрегатный monitoring живым.','Новый risk score без записи не выдаётся; manual path.','availability'),
('C40','Изоляция ресурсов','Совместить пик online, OCR, training, embeddings и RAGAS.','Online budgets соблюдены или включён измеренный fallback; batch ограничен.','capacity'),
('C41','Autoscaling без метрик','Потерять custom metrics при очереди и ограниченном GPU pool.','Нет unsafe downscale; сохранён резерв, admission control и alert.','capacity'),
('C42','GPU compatibility','Проверить выбранные weights, precision, kernels, CUDA/driver и max context.','Нет OOM в заявленном профиле; readiness только после smoke.','capacity'),
('C43','Monitoring labels/privacy','Просмотреть метрики, traces, отчёты, prompts и logs.','Нет raw анкет/документов, бесконечных ID labels и неразрешённых данных.','security'),
('C44','DR и revoke','Восстановить backup без последнего revoke и потерянными локальными mappings.','До сверки/tombstone recovery RAG и значимые операции закрыты.','recovery'),
('C45','Смена контекста UI','Вторая вкладка меняет компанию во время чата/финансового save.','Старое поколение не меняет новый экран; сервер возвращает 409 context mismatch.','frontend'),
('C46','Совместимость событий','Добавить поле в существующую strict v1 schema и проверить старый consumer.','Изменение отклонено либо новая v2 topic/schema с миграцией.','contracts'),
('C47','Воспроизводимая документация','Пересобрать пакет и проверить contracts/examples/links/diagrams/tasks.','Проекты схем корректны, зависимости ацикличны, ссылки и anchors разрешаются.','package'),
('C48','Сохранность исходников','Сравнить исходные три пакета и аудит по SHA-256.','Ни один сохранённый исходный файл не изменён и не удалён.','package'),
('C49','Визуальный контроль PDF','Отрендерить все страницы руководства/атласа, проверить bounds и просмотр.','Нет обрезания, наложения, нечитаемых шрифтов; visual report привязан к hashes.','package'),
('C50','Production gates','Использовать development policy, неподтверждённый target/retention/GPU.','Развёртывание в bank-target запрещено, несмотря на зелёный demo.','release'),
]
TESTS=[dict(id=i,title=t,setup=a,expected=e,area=g,status='PLANNED_APPLICATION_TEST' if g!='package' else 'PACKAGE_CHECK',automation='Контрактная/интеграционная проверка на реализации; не считается выполненной по наличию описания.') for i,t,a,e,g in TEST_ROWS]

TASKS=[
entry('M01','Зафиксировать владельцев, цели и допуск','Архитектор + risk/product/content owners',[],'Принятые границы, score semantics и реестр внешних gates',['C07','C50'],1),
entry('M02','Согласовать финансовый словарь и источники','Data engineer + бухгалтерский аналитик',['M01'],'Восемь полей, стандарты, периоды, подтверждения и product requirements',['C05','C06'],1),
entry('M03','Принять контракты и миграцию','Backend + frontend + ML lead',['M02'],'Единый OpenAPI 1.3-design, internal v2 и стратегия event v2',['C46','C47'],1),
entry('M04','Закрепить Linux/NVIDIA supply chain','ML platform + безопасность',['M01'],'Images/locks/licences/SBOM, проверенный GPU matrix без выбора LLM в архитектуре',['C42','C50'],1),
entry('M05','Реализовать финансовую анкету и RFI','Backend + frontend',['M03'],'Draft/confirm/snapshot, CAS и server provenance',['C03','C06','C45'],2),
entry('M06','Создать governed dataset storage','Data engineer',['M03','M04'],'Снимки, hashes, owner/access/retention и dataset manifests',['C01','C02','C43'],2),
entry('M07','Реализовать общие transforms и Feast','ML engineer + data engineer',['M05','M06'],'Feature code, point-in-time availability, immutable snapshots, online materialization',['C02','C03','C04','C05'],2),
entry('M08','Загрузить и проверить публичный baseline','ML engineer',['M06'],'UCI 5year attribution, DQ/dedup, saved grouped 60/20/20 split',['C09','C01'],2),
entry('M09','Сравнить и зарегистрировать risk кандидатов','ML engineer + validator',['M07','M08','M10'],'Logistic/CatBoost, calibration/report/model card без обещания PD',['C01','C07'],2),
entry('M10','Подключить MLflow manifests и registry','ML platform',['M06'],'Runs, model versions, aliases, immutable artifact references',['C01','C38'],2),
entry('M11','Реализовать Risk API и manual path','ML serving + bank adapter',['M09','M10'],'Версионный inference, идемпотентность, audit и fallback',['C11','C12','C39'],3),
entry('M12','Добавить три продукта и eligibility','Product + backend',['M03'],'Синтетический каталог, версии и пригодные candidates',['C13','C16'],3),
entry('M13','Реализовать ranking rules и интерфейс','ML engineer + backend',['M12'],'PRODUCT/FEED permutation validation, pinned next action',['C13','C14','C16'],3),
entry('M14','Собирать exposures и действия','Frontend + backend + data engineer',['M13'],'Видимые показы, dedup feedback и серверная атрибуция',['C15','C17'],3),
entry('M15','Подключить OCR финансовой формы','Document backend + ML engineer',['M05','M04'],'CLEAN-only jobs, generation, нормализация и ручное подтверждение',['C18','C19','C20'],3),
entry('M16','Создать KB authority и content workflow','Backend + content owner',['M03','M06'],'Published versions, audience, approval, deny epoch и журнал восстановления',['C23','C27','C44'],4),
entry('M17','Реализовать ingestion и Qdrant candidates','ML/data engineer',['M16'],'Parser/chunker, dense+sparse index, cutoff/dedup/single-build',['C24','C25'],4),
entry('M18','Подключить vLLM и RAG API','ML serving',['M17','M04'],'Configured local generator, один bundle на запрос, проверяемые sources',['C21','C22','C25','C29','C42'],4),
entry('M19','Реализовать отзыв с publication fence','Backend + SRE',['M16','M18'],'Immediate deny, cancellation/drain, ENFORCED, purge и защищённая history',['C26','C27','C28','C29'],4),
entry('M20','Добавить виджет и QA-набор RAG','Frontend + content owner + validator',['M18','M19'],'Чат, feedback, 100 golden + 50 attacks, версионированный judge',['C21','C23','C30','C45'],4),
entry('M21','Создать UpdateRequest и batch DAGs','ML platform',['M07','M10','M17'],'Durable signals, leases/generations, retry/cooldown, manifests',['C10','C24','C31','C32'],5),
entry('M22','Настроить мониторинг и отчёты','SRE + ML/data engineer',['M11','M14','M15','M20'],'Prometheus/Grafana, Evidently/RAGAS, reports и heartbeat',['C30','C32','C43'],5),
entry('M23','Реализовать approvals и release controller','ML platform + IAM',['M21','M22'],'Независимые reviewer/owner, digest binding, signed policy',['C33','C34','C37','C50'],5),
entry('M24','Реализовать shadow/canary/rollback','ML serving + SRE',['M23'],'Sticky routing, 5/25/100, статистические guards и совместимый rollback',['C12','C25','C27','C35','C36','C38'],5),
entry('M25','Принять MVP end-to-end','QA + владельцы',['M11','M13','M15','M20','M24'],'Синтетический кейс от анкеты до ответа/обновления/отката; отчёт о пределах',['C07','C11','C19','C29','C37','C45'],6),
entry('M26','Подключить банковские данные и labels','Data owner + risk owner',['M25'],'Утверждённый target, availability, maturity, OOT/entity validation',['C02','C08','C10','C50'],7),
entry('M27','Обучить банковский риск и обучаемые rankers','ML engineer + независимый validator',['M26','M14'],'PD на допустимых данных; PRODUCT/FEED только при достаточно меток',['C07','C08','C17','C33'],7),
entry('M28','Подключить проверенную OCR/RAG разметку','Document/content owner + ML',['M25'],'Verified labels/pairs и кандидаты OCR/embedding/reranker при data gate',['C20','C30','C34'],7),
entry('M29','Выполнить capacity/security/chaos','SRE + безопасность + QA',['M25','M04'],'Измеренные SLO, GPU budgets, admission, изоляция и runbooks',['C40','C41','C42','C43'],7),
entry('M30','Провести HA/DR и банковский допуск','SRE + risk/security/product owners',['M26','M27','M28','M29'],'Проверенное восстановление и утверждённые production gates',['C44','C50'],7),
]

REQS=[
('R01','Консистентность и воспроизводимость',['M06','M07','M08','M09','M10'],['C01','C02','C03','C04','C09'],'docs/03-data-risk.md','02-data'),
('R02','Понятные fallbacks',['M11','M13','M15','M18','M19'],['C11','C16','C19','C29','C39'],'docs/07-operations.md','03-risk'),
('R03','Мониторинг и отчётность',['M22'],['C30','C32','C43'],'docs/07-operations.md','06-release'),
('R04','Автообновление и ручная валидация',['M21','M23'],['C10','C31','C33','C34','C37'],'docs/06-lifecycle.md','06-release'),
('R05','Canary, отклонение и rollback',['M24'],['C25','C27','C35','C36'],'docs/06-lifecycle.md','06-release'),
('R06','RAG только клиентские знания и vLLM',['M16','M17','M18','M20'],['C21','C22','C23','C30'],'docs/05-rag.md','05-rag'),
('R07','Обновление RAG по N/метрикам/удалению',['M19','M21','M28'],['C24','C26','C27','C28','C30'],'docs/05-rag.md','05-rag'),
('R08','Масштабирование сверх реплик',['M04','M29'],['C40','C41','C42'],'docs/07-operations.md','07-deployment'),
('R09','Свой скоринг, решение банка',['M01','M09','M11','M26','M27'],['C07','C08','C11','C12'],'docs/03-data-risk.md','03-risk'),
('R10','Финансовая анкета под открытый baseline',['M02','M05','M08'],['C05','C06','C09'],'docs/03-data-risk.md','03-risk'),
('R11','Рекомендации ленты и продуктов',['M12','M13','M14','M27'],['C13','C14','C15','C16','C17'],'docs/04-recsys-ocr.md','04-recsys-ocr'),
('R12','OCR с подтверждением и data gate',['M15','M28'],['C18','C19','C20'],'docs/04-recsys-ocr.md','04-recsys-ocr'),
('R13','Два этапа Linux/NVIDIA',['M04','M25','M29','M30'],['C38','C40','C42','C50'],'docs/07-operations.md','07-deployment'),
('R14','Отдельный пакет и интеграция без порчи исходников',['M03'],['C46','C47','C48','C49'],'docs/08-interfaces.md','01-context'),
('R15','Права, контекст, удаление и восстановление',['M16','M19','M30'],['C23','C26','C27','C28','C43','C44','C45'],'docs/05-rag.md','05-rag'),
]

FINDING_ROWS=[
('ML-01','P1','SPEC_GAP','Вход скоринга несовместим с публичными коэффициентами',BACKEND/'api/internal-openapi.json','annualRevenueMinor','Нельзя обучить модель на X1-X10 и передать вместо них четыре другие величины.','Новая финансовая анкета, feature snapshot и internal v2.',['M02','M03','M05','M07'],['C04','C05','C06']),
('ML-02','P1','SPEC_GAP','Нет полного manifest эксперимента',GENERAL/'docs/architecture.md','Набор данных имеет владельца','Без split membership, зависимостей и data digest запуск не воспроизводится.','Dataset/experiment/release manifests и фиксированные artifacts.',['M06','M08','M09','M10'],['C01','C09']),
('ML-03','P1','SPEC_GAP','Не определены созревание и источник банковских labels',GENERAL/'docs/architecture.md','Промышленную PD','Незрелые кредиты можно ошибочно принять за хорошие исходы.','TargetVersion, observationEnd/labelAvailableAt и mature cohort gate.',['M26','M27'],['C07','C08','C10']),
('ML-04','P1','SPEC_GAP','Не определена известность данных во времени',GENERAL/'docs/architecture.md','временное разделение','Историческая коррекция может утечь в прошлые прогнозы.','Event/available time и preprocessing перед историческим join.',['M06','M07'],['C02','C03']),
('ML-05','P1','SPEC_GAP','Не закреплено хранение inference features',GENERAL/'docs/architecture.md','featureSchemaVersion','Online latest не воспроизводит старую отправленную заявку.','Immutable snapshotId/digest и запись inference result.',['M07','M11'],['C03','C04','C12']),
('ML-06','P2','SCOPE_EXTENSION','RecSys расширяется на продукты',GENERAL/'docs/architecture.md','M04 ранжирует','Исходная модель охватывает ленту; нового product ranking пока нет.','PRODUCT после eligibility, отдельно от FEED.',['M12','M13'],['C13','C14','C16']),
('ML-07','P1','SPEC_GAP','Нет протокола видимых показов и меток',BACKEND/'api/internal-openapi.json','candidateContentIds','Непоказанные кандидаты или будущие клики могут стать ложными метками.','Exposure, VIEW/CLICK, dedup, attribution windows.',['M14','M27'],['C15','C17']),
('ML-08','P2','SPEC_GAP','OCR-подтверждение не определяет обучающую разметку',GENERAL/'docs/architecture.md','требуют подтверждения человеком','Правки пользователя без дополнительной проверки могут испортить обучение.','USER_CONFIRMED отдельно от VERIFIED_GOLD.',['M15','M28'],['C18','C20']),
('ML-09','P2','SCOPE_EXTENSION','RAG отсутствует в старом объёме',GENERAL/'docs/architecture.md','LLM в текущую версию не включается','Новая согласованная функция требует отдельной границы и бюджета.','Read-only KB assistant через BFF, Qdrant и vLLM.',['M16','M17','M18','M20'],['C21','C22','C23']),
('ML-10','P1','NEW_SCOPE_REQUIREMENT','Нужен независимый отзыв KB',GENERAL/'docs/architecture.md','LLM в текущую версию не включается','Добавляемый RAG без deny/fencing может выдавать удалённые знания.','Epoch authority, publication fence, purge и tombstones.',['M16','M19'],['C26','C27','C28','C44']),
('ML-11','P1','SPEC_GAP','Допуск не привязан к точному bundle',GENERAL/'docs/architecture.md','согласования risk owner','Одобрение старых весов может незаметно примениться к новому prompt/feature code.','Digest-bound независимые approvals и policy version.',['M23'],['C33','C34']),
('ML-12','P1','SPEC_GAP','Сигнал drift не является надёжным заданием',GENERAL/'docs/security-operations.md','drift →','Webhook может потеряться или создать повторные/бесполезные обучения.','Durable UpdateRequest, diagnostic/data gate, leases/cooldown.',['M21','M22'],['C10','C31','C32']),
('ML-13','P1','SPEC_GAP','Canary без минимальной выборки и явного rollback bundle',GENERAL/'docs/architecture.md','ограниченный canary','Низкий трафик или откат только модели могут дать ложный допуск/несовместимость.','Политика окон, HOLD и rollback целого комплекта.',['M24'],['C25','C35','C36','C37']),
('ML-14','P2','SPEC_GAP','Нет capacity profile для нового RAG',GENERAL/'docs/security-operations.md','GPU throughput','Общая RPS-гипотеза кабинета не даёт KV/VRAM/token capacity.','Linux/NVIDIA budgets, независимые pools, GPU smoke/load.',['M04','M29'],['C40','C41','C42']),
('ML-15','P1','SPEC_GAP','Нужен запрет proxy-score в live банке',BACKEND/'api/internal-openapi.json','calibrationStatus','Одного числа 0..1 и VALIDATED недостаточно для различения домена/таргета.','scoreKind, purpose, registry evidence и production gate.',['M01','M09','M11','M26'],['C07','C50']),
('ML-16','P1','INTEGRATION_RISK','Новые сведения затрагивают строгие контракты',BACKEND/'docs/05-reliability.md','Строгие JSON Schema','Добавление полей в старое событие нарушит существующих consumers.','Версионные API/events и явная expand/migrate/contract стратегия.',['M03','M05'],['C46','C47','C48']),
]

GATES=[
('G01','Банковские данные и target','Risk owner + data owner','Утверждены источник labels, maturity, допустимые признаки и OOT/entity tests.'),
('G02','Словарь финансов и продукт','Product + бухгалтерский аналитик + risk owner','Согласованы строки отчётности, единицы, standards, требования и eligibility.'),
('G03','Политика моделей и reviewer identity','Risk/ML platform + IAM','Подписаны численные thresholds, роли, срок approval и разделение автора/валидатора.'),
('G04','Защита и retention','Безопасность + право + data owner','Утверждены основания, защита хранения/копий, сроки, deletion и legal hold.'),
('G05','Лицензии и supply chain','Платформа + безопасность','Проверены код/веса/datasets, SBOM, locks, images, CUDA/driver matrix.'),
('G06','Ёмкость и HA','SRE + platform owner','Выбраны GPU/VRAM по замерам, три домена отказа, нагрузка и резерв canary/rebuild.'),
('G07','Восстановление и банковская интеграция','SRE + банковские владельцы','Пройдены DR, replay tombstones, внешняя сверка команд и контроль двойного эффекта.'),
('G08','Качество и опубликованные знания','Content/product/document owners + validator','Утверждены KB, gold sets, ручная разметка и результаты независимой проверки.'),
]

def write_all():
    findings=[]
    for id,priority,kind,title,path,pattern,risk,resolution,tasks,tests in FINDING_ROWS:
        lines=path.read_text().splitlines();ix=next(i for i,l in enumerate(lines) if pattern in l)
        findings.append(dict(id=id,priority=priority,classification=kind,title=title,evidence={'path':str(path.relative_to(ROOT)),'line':ix+1,'quote':lines[ix][:700],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()},risk=risk,resolution=resolution,tasks=tasks,acceptance=tests,status='ADDRESSED_IN_NEW_DESIGN_NOT_IMPLEMENTED'))
    save('findings.json',findings);save('tasks.json',TASKS);save('acceptance-cases.json',TESTS)
    requirements=[dict(id=i,title=t,tasks=tasks,acceptance=tests,document=doc,diagram=diagram) for i,t,tasks,tests,doc,diagram in REQS]
    save('traceability.json',requirements)
    integrations=[
     dict(id='I01',package='general',source='docs/architecture.md',change='Заменить прежний минимальный ML/MVP объём новым Linux/NVIDIA ML-профилем, RAG и тремя продуктами; кредитное решение оставить банку.',tasks=['M01','M03','M12','M16'],tests=['C07','C13','C21']),
     dict(id='I02',package='backend',source='api/openapi.json',change='Новая версия 1.3-design: financialStatementVersion в Submit/InformationResponse, server financialSnapshotId в отправленном snapshot, allowlist финансовых RFI items; не принимать клиентский snapshotId.',tasks=['M03','M05'],tests=['C03','C06','C46']),
     dict(id='I03',package='backend+frontend',source='api/openapi.json',change='Синхронно применить public extensions, responses recommendations/feed с exposureId/ranking metadata и errors. Клиент не получает risk API.',tasks=['M03','M05','M14','M20'],tests=['C15','C23','C45','C47']),
     dict(id='I04',package='backend',source='api/internal-openapi.json',change='Добавить internal v2 feature/risk/ranking; оставить старые risk и feed endpoints до миграции адаптера/workspace.',tasks=['M03','M07','M11','M13'],tests=['C04','C11','C12','C13']),
     dict(id='I05',package='backend',source='schemas/events-v1.schema.json',change='Новые семейства ML/KB/RecSys в новых topics; для расширяемых submission/document payload выпустить v2 и параллельных consumers.',tasks=['M03','M21'],tests=['C31','C46']),
     dict(id='I06',package='frontend',source='docs/04-screens.md',change='Добавить финансовую форму в заявку/RFI, statuses assistant, source viewer, exposure visibility и очистку при context switch.',tasks=['M05','M14','M20'],tests=['C06','C15','C21','C28','C45']),
     dict(id='I07',package='general+backend',source='docs/security-operations.md / docs/06-security-operations.md',change='Отдельный 20-секундный RAG budget; ML SLI, GPU pools, deny/fence, offline audit и расширенные DR проверки.',tasks=['M19','M22','M29','M30'],tests=['C26','C38','C40','C42','C44']),
     dict(id='I08',package='all',source='tasks.json / acceptance-cases.json',change='Добавить M01-M30 и C01-C50 в общую матрицу, не заменяя прежнюю приёмку; ссылки на package source hashes.',tasks=['M03','M25'],tests=['C47','C48','C49']),
    ]
    save('integration-matrix.json',integrations)
    gates=[dict(id=i,subject=t,owner=o,acceptance=a,status='REQUIRES_EXTERNAL_VALIDATION',blocks='BANK_TARGET_PRODUCTION') for i,t,o,a in GATES];save('external-gates.json',gates)
    phases={1:'Контракты и основания',2:'Данные и воспроизводимый baseline',3:'Инференс и обязательные fallbacks',4:'Помощник и жизненный цикл знаний',5:'Мониторинг и управляемые обновления',6:'Приёмка MVP',7:'Банковский контур'}
    work=['# 9. План реализации\n','Порядок задают зависимости, а не календарные обещания. Роли обозначают ответственность, не численность команды. При оценке сроков отдельно учитывать ожидание банковских данных, GPU, согласований и созревания labels. Архитектурная поставка описывает будущие M01-M30; они не считаются выполненными созданием документа.\n','## Контрольные точки\n','MVP готов после M25: открытый proxy, синтетические клиенты/продукты, ручные подтверждения, RAG, мониторинг, автоматические кандидаты и ручной выпуск. Банковский запуск после M30 и всех G01-G08. Обучаемые rankers и OCR/RAG tuning не включаются без достаточной проверенной разметки.\n']
    for phase,title in phases.items():
        work.append(f'## Этап {phase}. {title}\n')
        for t in TASKS:
            if t['phase']!=phase:continue
            work.extend([f"### {t['id']}. {t['title']}\n",f"Ответственный: {t['owner']}. Зависимости: {', '.join(t['dependsOn']) or 'нет'}.\n",f"Результат и критерий завершения: {t['result']}.\n",f"Приёмка: {', '.join(t['acceptance'])}.\n"])
    (OUT/'docs/09-workplan.md').write_text('\n'.join(work))
    acceptance=['# 10. Сценарии приёмки\n','C01-C46 и C50 - требования к будущему приложению. При подготовке пакета оно не реализовывалось и не запускалось. C47-C49 относятся к контрактам, сохранности и оформлению настоящих файлов; фактические результаты находятся в validation-report.json и visual-review.json. Проверка синтетического schema fixture не равна прохождению одноимённого runtime сценария.\n']
    for t in TESTS:
        acceptance.extend([f"### {t['id']}. {t['title']}\n",f"Сценарий: {t['setup']}\n",f"Ожидается: {t['expected']}\n"])
    (OUT/'docs/10-acceptance.md').write_text('\n'.join(acceptance))
    lines=['# Связь требований с реализацией и приёмкой\n','| Требование | Задачи | Проверки | Документ / схема |','| --- | --- | --- | --- |']
    for r in requirements:lines.append(f"| {r['id']}: {r['title']} | {', '.join(r['tasks'])} | {', '.join(r['acceptance'])} | {r['document']} / {r['diagram']} |")
    (OUT/'traceability.md').write_text('\n'.join(lines)+'\n')
    return requirements

if __name__=='__main__':write_all()
