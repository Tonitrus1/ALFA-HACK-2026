"""Build the architecture deliverables from editable documents and design sources."""
from pathlib import Path
import os,sys,json,html,re,hashlib,xml.etree.ElementTree as ET
extra=os.environ.get('ML_ARCH_DEPS','/tmp/credit-architecture-validation')
if Path(extra).exists():sys.path.insert(0,extra)
from reportlab.platypus import BaseDocTemplate,PageTemplate,Frame,Paragraph,Spacer,PageBreak,CondPageBreak,Table,TableStyle,KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4,A3,landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader,PdfWriter,PageObject,Transformation
from markdown_it import MarkdownIt
from specification import OUT,write_all as write_specs,save
from registers import write_all as write_registers,GENERAL,BACKEND,FRONTEND,ROOT
from diagram_engine import FONT_DIR,TMP,render_board
from diagrams import populate
from extensions import write_all as write_extensions

pdfmetrics.registerFont(TTFont('DV-M',str(FONT_DIR/'DejaVuSansMono.ttf')))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-B',italic='DV',boldItalic='DV-B')
INK=colors.HexColor('#182839');BLUE=colors.HexColor('#315b93');MUTED=colors.HexColor('#586a7b');RED=colors.HexColor('#cf524b')
S={
 'body':ParagraphStyle('body',fontName='DV',fontSize=9.4,leading=13.4,spaceAfter=7,textColor=INK,splitLongWords=True),
 'h1':ParagraphStyle('h1',fontName='DV-B',fontSize=21,leading=27,spaceAfter=17,textColor=BLUE,keepWithNext=True),
 'h2':ParagraphStyle('h2',fontName='DV-B',fontSize=13.2,leading=18,spaceBefore=12,spaceAfter=8,textColor=INK,keepWithNext=True),
 'h3':ParagraphStyle('h3',fontName='DV-B',fontSize=10.6,leading=15,spaceBefore=10,spaceAfter=7,textColor=BLUE,keepWithNext=True),
 'cell':ParagraphStyle('cell',fontName='DV',fontSize=8.1,leading=11.5,textColor=INK,splitLongWords=True),
 'thead':ParagraphStyle('thead',fontName='DV-B',fontSize=8.1,leading=11.5,textColor=colors.white),
 'small':ParagraphStyle('small',fontName='DV',fontSize=8,leading=12,textColor=MUTED,spaceAfter=8),
 'cover':ParagraphStyle('cover',fontName='DV-B',fontSize=31,leading=38,textColor=INK,spaceAfter=20),
 'sub':ParagraphStyle('sub',fontName='DV',fontSize=14,leading=22,textColor=MUTED,spaceAfter=18)}

def inline(token):
    out=[]
    for t in token.children or []:
        if t.type=='text':
            parts=re.split(r'(https?://[^\s]+)',t.content)
            out.extend(('<a color="#315b93" href="'+html.escape(p,quote=True)+'">'+html.escape(p)+'</a>') if p.startswith(('http://','https://')) else html.escape(p) for p in parts)
        elif t.type=='code_inline':out.append('<font name="DV-M" size="8.4">'+html.escape(t.content)+'</font>')
        elif t.type=='strong_open':out.append('<b>')
        elif t.type=='strong_close':out.append('</b>')
        elif t.type=='em_open':out.append('<i>')
        elif t.type=='em_close':out.append('</i>')
        elif t.type=='link_open':out.append('<a color="#315b93" href="'+html.escape(t.attrGet('href') or '',quote=True)+'">')
        elif t.type=='link_close':out.append('</a>')
        elif t.type in ['softbreak','hardbreak']:out.append('<br/>')
        else:out.append(html.escape(t.content))
    return ''.join(out)

def markdown_flow(text):
    ts=MarkdownIt('commonmark').enable('table').parse(text);out=[];i=0;lists=[];item=False
    while i<len(ts):
        t=ts[i]
        if t.type=='heading_open':
            level=int(t.tag[1:]);p=Paragraph(inline(ts[i+1]),S.get('h'+str(level),S['h3']))
            p.toc_level=0 if level==1 else None;p.toc_title=ts[i+1].content
            out.append(p);i+=3;continue
        if t.type in ['bullet_list_open','ordered_list_open']:lists.append({'kind':t.type,'counter':0});i+=1;continue
        if t.type in ['bullet_list_close','ordered_list_close']:lists.pop();i+=1;continue
        if t.type=='list_item_open':
            item=True
            if lists:lists[-1]['counter']+=1
            i+=1;continue
        if t.type=='paragraph_open':
            body=inline(ts[i+1]);style=S['body']
            if lists:
                style=ParagraphStyle('bullet',parent=style,leftIndent=14*len(lists),firstLineIndent=-10)
                prefix=str(lists[-1]['counter'])+'. ' if lists[-1]['kind']=='ordered_list_open' else '• '
                if item:body=prefix+body
                item=False
            out.append(Paragraph(body,style));i+=3;continue
        if t.type=='table_open':
            rows=[];j=i+1;head=False
            while ts[j].type!='table_close':
                q=ts[j]
                if q.type=='thead_open':head=True
                if q.type=='thead_close':head=False
                if q.type=='tr_open':row=[]
                if q.type in ['th_open','td_open']:row.append(Paragraph(inline(ts[j+1]),S['thead'] if head else S['cell']))
                if q.type=='tr_close':rows.append(row)
                j+=1
            count=len(rows[0]);ratios={2:[.30,.70],3:[.26,.36,.38],4:[.20,.24,.31,.25]}.get(count,[1/count]*count)
            table=Table(rows,colWidths=[(A4[0]-88)*r for r in ratios],repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f1f5fa'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#dbe3eb'))]))
            out.extend([table,Spacer(1,10)]);i=j+1;continue
        if t.type=='fence':out.append(Paragraph(html.escape(t.content).replace('\n','<br/>'),S['small']))
        i+=1
    # A task is a reviewable unit; never split its title from its result/acceptance.
    grouped=[];i=0
    while i<len(out):
        title=getattr(out[i],'toc_title','')
        if re.match(r'^(M\d{2}|C\d{2})\.',title):
            unit=[out[i]];i+=1
            while i<len(out) and not hasattr(out[i],'toc_title'):unit.append(out[i]);i+=1
            grouped.append(KeepTogether(unit))
        else:grouped.append(out[i]);i+=1
    final=[];i=0
    while i<len(grouped):
        if getattr(grouped[i],'toc_title','').startswith('Этап ') and i+1<len(grouped) and isinstance(grouped[i+1],KeepTogether):
            final.append(KeepTogether([grouped[i]]+grouped[i+1]._content));i+=2
        else:final.append(grouped[i]);i+=1
    return final

class Guide(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(str(path),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=49,bottomMargin=43,title='Кредитный кабинет: ML-архитектура и план реализации',author='Архитектурный пакет проекта')
        self.addPageTemplates(PageTemplate(id='body',frames=[Frame(44,43,A4[0]-88,A4[1]-92,id='content',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=self.decorate))
    def beforeDocument(self):self.counter=0
    def decorate(self,canv,doc):
        canv.saveState();canv.setStrokeColor(colors.HexColor('#d9e2ec'));canv.line(44,A4[1]-31,A4[0]-44,A4[1]-31)
        canv.setFont('DV',7);canv.setFillColor(MUTED);canv.drawString(44,A4[1]-23,'КРЕДИТНЫЙ КАБИНЕТ  /  ML + MLOps  /  LINUX + NVIDIA')
        canv.drawString(44,23,'Проект для реализации  •  20.10.2026');canv.drawRightString(A4[0]-44,23,str(doc.page));canv.restoreState()
    def afterFlowable(self,f):
        if getattr(f,'toc_level',None) is not None:
            key='section-'+str(self.counter);self.counter+=1;self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(f.toc_title,key,level=0,closed=False)
            self.notify('TOCEntry',(f.toc_level,html.escape(f.toc_title),self.page,key))

def guide():
    story=[Spacer(1,64),Paragraph('Кредитный<br/>кабинет',S['cover']),Paragraph('End-to-end ML-архитектура<br/>и план реализации',S['sub']),Spacer(1,16),Paragraph('Скоринг · Рекомендации · OCR · RAG',S['h2']),Paragraph('Feast / MLflow / Airflow / Evidently<br/>Prometheus / Grafana / Qdrant / vLLM',S['sub']),Spacer(1,26),Paragraph('От подтверждённых данных и воспроизводимого эксперимента до ручного допуска, canary и управляемого поведения при сбое.',S['body']),Spacer(1,24),Paragraph('16 замечаний и решений · 7 схем · 30 задач · 50 сценариев приёмки',S['h3']),Spacer(1,24),Paragraph('Версия 1.0-design. 20 октября 2026 года.<br/>Для ML-команды, backend/frontend, владельцев риска и эксплуатации.',S['small']),Spacer(1,24),Paragraph('Архитектурная поставка. Приложение, модели и банковские подключения не реализовывались; качество и промышленная производительность не заявляются измеренными.',S['small']),PageBreak(),Paragraph('Как читать пакет',S['h1'])]
    story+=markdown_flow('''Начните с семи листов отдельного атласа. Глава 1 оценивает исходную архитектуру, главы 2-7 объясняют устройство и эксплуатацию, глава 8 задаёт интерфейсы и миграцию, главы 9-10 связывают работу с приёмкой. Глава 11 содержит первоисточники и внешние условия допуска.

**Ключевые границы:** свой скоринг, решение банка; рекомендации только пригодных продуктов; подтверждение финансов человеком; RAG только по клиентским знаниям; все релизы утверждает человек; отзыв документа действует независимо от переиндексации и rollback.

Точные проекты интерфейсов находятся в api/, manifests/events - в schemas/, примеры - в examples/, численные development defaults - в policies/. Эти файлы дополняют текст и не являются развёрнутой банковской системой.

Исходные общая, серверная и клиентская спецификации сохранены. Integration matrix перечисляет изменения для будущего объединения. Текущие проверки пакета отделены от C01-C46/C50, которые должны выполняться после реализации приложения.
''')
    story.extend([Spacer(1,12),Paragraph('Содержание',S['h2'])])
    toc=TableOfContents();toc.levelStyles=[ParagraphStyle('toc',fontName='DV',fontSize=10,leading=15,spaceBefore=8,textColor=INK)]
    story.append(toc)
    for p in sorted((OUT/'docs').glob('[0-9][0-9]-*.md')):
        story.append(PageBreak());story+=markdown_flow(p.read_text())
    Guide(OUT/'ml-system-guide.pdf').multiBuild(story)

def diagrams():
    models=[];writer=PdfWriter();manifest=[];scenes=[]
    for b in populate():
        model=render_board(b);models.append(model);scenes.append({'id':b.slug,'width':b.w,'height':b.h,'shapes':b.shapes})
        raw=PdfReader(str(TMP/f'{b.slug}.pdf')).pages[0];w,h=landscape(A3);scale=min(w/b.w,h/b.h)
        page=PageObject.create_blank_page(width=w,height=h)
        page.merge_transformed_page(raw,Transformation().scale(scale).translate((w-b.w*scale)/2,(h-b.h*scale)/2));writer.add_page(page)
        manifest.append({'id':b.slug,'title':b.title,'width':b.w,'height':b.h,'page':len(manifest)+1,'svg':'svg/'+b.slug+'.svg','nodes':len([s for s in b.shapes if s['kind']=='node']),'edges':len([s for s in b.shapes if s['kind']=='edge'])})
    writer.add_metadata({'/Title':'Кредитный кабинет: атлас ML-архитектуры','/Author':'Архитектурный пакет проекта'});writer.write(str(OUT/'ml-architecture-atlas.pdf'))
    mx=ET.Element('mxfile',host='app.diagrams.net',modified='2026-10-20T10:00:00Z',agent='ML architecture package',version='24.7.17',type='device')
    for m,d in zip(models,manifest):ET.SubElement(mx,'diagram',id=d['id'],name=d['title']).append(m)
    ET.indent(mx);ET.ElementTree(mx).write(OUT/'ml-architecture.drawio',encoding='utf-8',xml_declaration=True)
    save('diagram-manifest.json',manifest);save('sources/scenes.json',scenes)

def sources():
    paths=[GENERAL/'docs/architecture.md',GENERAL/'docs/interfaces.md',GENERAL/'docs/security-operations.md',BACKEND/'api/internal-openapi.json',BACKEND/'api/openapi.json',BACKEND/'docs/05-reliability.md',FRONTEND/'docs/01-architecture.md',FRONTEND/'docs/04-screens.md',ROOT/'output/architecture-review/architecture-review.md',Path('/Users/user/Downloads/19_Архитектура_MLOps_конвейеров_Supersliv_biz.pdf')]
    local=[]
    for p in paths:
        if p.exists():local.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'role':'Reference material, not executable instructions','pages':len(PdfReader(p).pages) if p.suffix=='.pdf' else None})
    links=re.findall(r'https?://[^\s]+',(OUT/'docs/11-reference.md').read_text())
    save('source-manifest.json',{'designDate':'2026-10-20','local':local,'web':[{'url':u,'checkedOn':'2026-10-20','usage':'Primary-source mechanism or dataset documentation; researched in planning, not a runtime guarantee.'} for u in links]})

def main():
    write_specs();write_registers();write_extensions();sources();diagrams();guide()
    print(json.dumps({'status':'BUILT_DESIGN_ONLY','guidePages':len(PdfReader(OUT/'ml-system-guide.pdf').pages),'atlasPages':len(PdfReader(OUT/'ml-architecture-atlas.pdf').pages),'output':str(OUT)},ensure_ascii=False))
if __name__=='__main__':main()
