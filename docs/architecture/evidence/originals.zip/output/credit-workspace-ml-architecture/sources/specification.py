"""Generate design contracts and synthetic fixtures, never a live ML service."""
from pathlib import Path
import json, hashlib, copy

OUT = Path(__file__).resolve().parents[1]
MAXINT = 9007199254740991
FIELDS = ['totalAssetsMinor','totalLiabilitiesMinor','currentAssetsMinor','currentLiabilitiesMinor','equityMinor','revenueMinor','netProfitMinor','ebitMinor']
FEATURES = ['X1','X2','X3','X4','X7','X8','X9','X10']
FAMILIES = ['RISK','PRODUCT','FEED','OCR','RAG_INDEX','RAG_COMPONENT']
def save(path, value):
    p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def s(n=128):return {'type':'string','minLength':1,'maxLength':n}
def enum(*items):return {'type':'string','enum':list(items)}
def version():return {'type':'integer','minimum':1,'maximum':MAXINT}
def integer(lo=0,hi=MAXINT):return {'type':'integer','minimum':lo,'maximum':hi}
def sha():return {'type':'string','pattern':'^[0-9a-f]{64}$'}
def dt():return {'type':'string','format':'date-time'}
def ref(n):return {'$ref':'#/components/schemas/'+n}
def arr(it,lo=0,hi=100,unique=False):
    x={'type':'array','items':it,'minItems':lo,'maxItems':hi}
    if unique:x['uniqueItems']=True
    return x
def obj(p,required=None):return {'type':'object','properties':p,'required':list(p) if required is None else required,'additionalProperties':False}

def schemas():
    c={}
    c['Error']=obj({'code':s(),'message':s(500),'correlationId':s(),'fallbackAction':enum('MANUAL_REVIEW','RULES','MANUAL_INPUT','SEARCH_ONLY','RETRY_LATER','NONE')},['code','message','correlationId'])
    c['Receipt']=obj({'operationId':s(),'status':enum('ACCEPTED','RUNNING','SUCCEEDED','FAILED'),'resourceId':s()})
    c['ObjectRef']=obj({'bucket':s(),'key':s(512),'objectVersion':s(),'sha256':sha()})
    c['DocumentReference']=obj({'documentId':s(),'documentVersion':version(),'objectVersion':s()})
    vals={n:integer(-MAXINT if n in ['equityMinor','netProfitMinor','ebitMinor'] else 0) for n in FIELDS}
    c['FinancialValues']=obj(vals,[])
    c['FinancialInput']=obj({'periodStart':{'type':'string','format':'date'},'periodEnd':{'type':'string','format':'date'},'reportingStandard':enum('DEMO','RSBU','IFRS'),'currency':{'const':'RUB'},'values':ref('FinancialValues'),'sourceDocumentReferences':arr(ref('DocumentReference'),0,10)})
    c['FinancialConfirmation']=obj({'expectedStatementVersion':version(),'confirmedFieldNames':arr({'type':'string','enum':FIELDS},8,8,True),'documentReferences':arr(ref('DocumentReference'),0,10)})
    c['FieldProvenance']=obj({'field':{'type':'string','enum':FIELDS},'sourceType':enum('MANUAL','OCR'),'confirmedBy':s(),'confirmedAt':dt(),'extractionId':s(),'objectVersion':s()},['field','sourceType','confirmedBy','confirmedAt'])
    c['FieldProvenance']['allOf']=[{'if':{'properties':{'sourceType':{'const':'OCR'}}},'then':{'required':['extractionId','objectVersion']}}]
    c['FinancialStatement']=obj({'statementVersion':version(),'containerVersion':version(),'confirmed':{'type':'boolean'},'statement':ref('FinancialInput'),'provenance':arr(ref('FieldProvenance'),0,8)})
    c['FinancialStatement']['allOf']=[{'if':{'properties':{'confirmed':{'const':True}}},'then':{'properties':{'statement':{'properties':{'values':{'required':FIELDS}}},'provenance':{'minItems':8}}}}]
    c['FeatureSnapshotInput']=obj({'applicationId':s(),'submissionSnapshotId':s(),'financialStatementVersion':version(),'asOf':dt(),'purpose':enum('DEMO_RESEARCH','CREDIT_RISK')})
    ratios=obj({n:{'type':['number','null']} for n in FEATURES})
    c['FeatureSnapshot']=obj({'featureSnapshotId':s(),'submissionSnapshotId':s(),'financialStatementVersion':version(),'featureSchemaVersion':{'const':2},'featureCodeDigest':sha(),'featureAsOf':dt(),'latestSourceAvailableAt':dt(),'features':ratios,'missingFeatures':arr({'type':'string','enum':FEATURES},0,8,True),'snapshotDigest':sha()})
    c['RiskRequest']=obj({'requestId':s(),'featureSnapshotId':s(),'featureSnapshotDigest':sha(),'featureSchemaVersion':{'const':2},'purpose':enum('DEMO_RESEARCH','CREDIT_RISK')})
    c['RiskResult']=obj({'inferenceId':s(),'requestId':s(),'score':{'type':'number','minimum':0,'maximum':1},'scoreKind':enum('BANKRUPTCY_PROXY','PD'),'calibrationStatus':enum('DEMONSTRATION','VALIDATED'),'releaseId':s(),'bundleDigest':sha(),'modelVersion':s(),'featureSnapshotId':s(),'featureSnapshotDigest':sha(),'internalReasonCodes':arr(s(),0,20)})
    c['RiskResult']['allOf']=[{'if':{'properties':{'scoreKind':{'const':'BANKRUPTCY_PROXY'}}},'then':{'properties':{'calibrationStatus':{'const':'DEMONSTRATION'}}}},{'if':{'properties':{'scoreKind':{'const':'PD'}}},'then':{'properties':{'calibrationStatus':{'const':'VALIDATED'}}}}]
    c['RankingRequest']=obj({'requestId':s(),'scope':enum('PRODUCT','FEED'),'candidateIds':arr(s(),1,100,True),'candidateSetDigest':sha(),'catalogVersion':version(),'eligibilityVersion':version(),'stage':s(),'contextCategory':s(),'fundingPurpose':s()},['requestId','scope','candidateIds','candidateSetDigest','catalogVersion','stage','contextCategory'])
    c['RankingRequest']['allOf']=[{'if':{'properties':{'scope':{'const':'PRODUCT'}}},'then':{'required':['eligibilityVersion','fundingPurpose']}}]
    c['RankingResult']=obj({'requestId':s(),'scope':enum('PRODUCT','FEED'),'rankedIds':arr(s(),1,100,True),'candidateSetDigest':sha(),'exposureId':s(),'releaseId':s(),'mode':enum('MODEL','RULES'),'reasonCategory':s()})
    c['RecommendationFeedback']=obj({'clientEventId':s(),'exposureId':s(),'itemId':s(),'action':enum('VIEW','CLICK'),'occurredAt':dt()})
    c['AssistantInput']=obj({'conversationId':s(),'message':s(2000)},['message'])
    c['Citation']=obj({'documentId':s(),'documentVersion':version(),'chunkId':s(),'title':s(256),'locator':s(128),'sourcePath':{'type':'string','pattern':'^/api/v1/knowledge/[A-Za-z0-9_-]+/versions/[1-9][0-9]*$'}})
    c['AssistantResponse']=obj({'conversationId':s(),'messageId':s(),'status':enum('ANSWER','INSUFFICIENT_EVIDENCE','SEARCH_ONLY'),'answer':{'type':'string','maxLength':4000},'citations':arr(ref('Citation'),0,5),'releaseId':s(),'bundleDigest':sha(),'kbEpoch':version()})
    c['AssistantResponse']['allOf']=[{'if':{'properties':{'status':{'const':'ANSWER'}}},'then':{'properties':{'citations':{'minItems':1},'answer':{'minLength':1}}}},{'if':{'properties':{'status':{'const':'SEARCH_ONLY'}}},'then':{'properties':{'answer':{'const':''},'citations':{'minItems':1}}}}]
    c['HiddenMessage']=obj({'messageId':s(),'status':{'const':'HIDDEN_SOURCE_REVOKED'}})
    c['Conversation']=obj({'conversationId':s(),'messages':arr({'oneOf':[ref('AssistantResponse'),ref('HiddenMessage')]},0,100)})
    c['AssistantFeedback']=obj({'clientEventId':s(),'messageId':s(),'rating':enum('HELPFUL','NOT_HELPFUL')})
    c['KnowledgeDocument']=obj({'documentId':s(),'documentVersion':version(),'title':s(256),'text':s(100000),'effectiveUntil':dt()})
    c['KBPublish']=obj({'corpusId':s(),'documentVersion':version(),'objectRef':ref('ObjectRef'),'title':s(256),'audience':{'const':'CLIENT'},'effectiveFrom':dt(),'effectiveUntil':dt(),'contentApprovalId':s()})
    c['KBRevoke']=obj({'corpusId':s(),'documentVersion':version(),'reason':enum('WITHDRAWN','EXPIRED','ACCESS_REMOVED','INCORRECT'),'expectedEpoch':version()})
    c['Revocation']=obj({'revocationId':s(),'corpusId':s(),'epoch':version(),'enforcementState':enum('PENDING','ENFORCED','FAILED_CLOSED'),'purgeState':enum('PENDING','RUNNING','COMPLETE','FAILED'),'affectedDocumentId':s(),'acceptedAt':dt()})
    c['UpdateInput']=obj({'family':{'type':'string','enum':FAMILIES},'reason':enum('SCHEDULE','NEW_MATURE_LABELS','DRIFT','QUALITY_DROP','KB_CHANGED','KB_REVOKED','NEW_VERIFIED_LABELS'),'deduplicationKey':s(256),'sourceWindowRef':s(512),'triggerPolicyVersion':s(),'reportDigest':sha()},['family','reason','deduplicationKey','sourceWindowRef','triggerPolicyVersion'])
    c['UpdateRequest']=obj({'updateRequestId':s(),'family':{'type':'string','enum':FAMILIES},'state':enum('REQUESTED','DIAGNOSING','BLOCKED_DATA','PREPARING','RUNNING','VALIDATING','AWAITING_APPROVAL','REJECTED','RELEASED','FAILED'),'generation':version(),'createdAt':dt(),'reasonCode':s(),'reportRef':s(512)},['updateRequestId','family','state','generation','createdAt','reasonCode'])
    c['ClaimInput']=obj({'workerId':s(),'expectedGeneration':version()})
    c['Lease']=obj({'workerId':s(),'leaseToken':s(),'generation':version(),'expiresAt':dt()})
    c['LeaseProof']=obj({'workerId':s(),'leaseToken':s(),'generation':version()})
    c['WorkResult']=obj({'workerId':s(),'leaseToken':s(),'generation':version(),'status':enum('SUCCEEDED','FAILED'),'manifestRef':ref('ObjectRef'),'reportDigest':sha(),'errorCode':s()},['workerId','leaseToken','generation','status'])
    c['WorkResult']['allOf']=[{'if':{'properties':{'status':{'const':'SUCCEEDED'}}},'then':{'required':['manifestRef','reportDigest']}},{'if':{'properties':{'status':{'const':'FAILED'}}},'then':{'required':['errorCode']}}]
    c['ApprovalInput']=obj({'decision':enum('APPROVE','REJECT'),'reviewRole':enum('VALIDATOR','OWNER'),'bundleDigest':sha(),'evaluationDigest':sha(),'policyVersion':s(),'expiresAt':dt(),'comment':s(1000)})
    c['ApprovalRecord']=obj({'approvalId':s(),'actorId':s(),'recordedAt':dt(),'releaseId':s(),'decision':enum('APPROVE','REJECT'),'reviewRole':enum('VALIDATOR','OWNER'),'bundleDigest':sha(),'evaluationDigest':sha(),'policyVersion':s(),'expiresAt':dt()})
    c['RolloutInput']=obj({'expectedRoutingVersion':version(),'action':enum('START_SHADOW','CANARY_5','CANARY_25','PROMOTE_100'),'bundleDigest':sha(),'approvalSetDigest':sha()})
    c['RollbackInput']=obj({'expectedRoutingVersion':version(),'targetReleaseId':s(),'reason':s(1000)})
    c['DatasetManifest']=obj({'datasetId':s(),'kind':enum('PUBLIC_PROXY','BANK_CREDIT','PRODUCT','FEED','OCR','RAG_EVAL'),'createdAt':dt(),'objects':arr(ref('ObjectRef'),1,10000),'sourceLicense':s(256),'attribution':s(1000),'targetVersion':s(),'availabilityRule':s(1000),'splitMembership':ref('ObjectRef'),'splitSeed':integer(0),'rowCount':integer(1),'positiveCount':integer(0)})
    c['ExperimentManifest']=obj({'runId':s(),'datasetDigest':sha(),'gitCommit':{'type':'string','pattern':'^[0-9a-f]{40}$'},'imageDigest':{'type':'string','pattern':'^sha256:[0-9a-f]{64}$'},'dependencyLock':ref('ObjectRef'),'featureCodeDigest':sha(),'featureSchemaVersion':version(),'targetVersion':s(),'seed':integer(0),'hardwareFingerprint':s(1000),'hyperparameters':{'type':'object','maxProperties':100,'additionalProperties':{'type':['number','string','boolean','null']}},'evaluationReport':ref('ObjectRef'),'reproductionTolerance':{'type':'number','minimum':0}})
    c['ReleaseManifest']=obj({'releaseId':s(),'family':{'type':'string','enum':FAMILIES},'createdBy':s(),'createdAt':dt(),'imageDigest':{'type':'string','pattern':'^sha256:[0-9a-f]{64}$'},'datasetDigest':sha(),'evaluationDigest':sha(),'policyVersion':s(),'assets':{'type':'object','minProperties':1,'maxProperties':20,'propertyNames':{'enum':['model','preprocessor','calibrator','featureRegistry','corpus','embedding','sparseConfig','reranker','tokenizer','prompt','retrievalConfig','generator','ocrParser']},'additionalProperties':ref('ObjectRef')},'featureSchemaVersion':version(),'scoreKind':enum('BANKRUPTCY_PROXY','PD'),'collectionName':s(),'corpusCutoff':dt(),'kbEpoch':version()},['releaseId','family','createdBy','createdAt','imageDigest','datasetDigest','evaluationDigest','policyVersion','assets'])
    c['ReleaseManifest']['allOf']=[{'if':{'properties':{'family':{'const':'RISK'}}},'then':{'required':['featureSchemaVersion','scoreKind'],'properties':{'assets':{'required':['model','preprocessor','featureRegistry']}}}},{'if':{'properties':{'family':{'enum':['RAG_INDEX','RAG_COMPONENT']}}},'then':{'required':['collectionName','corpusCutoff','kbEpoch'],'properties':{'assets':{'required':['corpus','embedding','sparseConfig','reranker','tokenizer','prompt','retrievalConfig','generator']}}}}]
    return c

def standalone(c,name):
    def convert(x):
        if isinstance(x,dict):return {k:(v.replace('#/components/schemas/','#/$defs/') if k=='$ref' else convert(v)) for k,v in x.items()}
        if isinstance(x,list):return [convert(v) for v in x]
        return x
    return {'$schema':'https://json-schema.org/draft/2020-12/schema','$ref':'#/$defs/'+name,'$defs':convert(c)}

def contracts(c):
    def spec(title,ver,public):
        return {'openapi':'3.1.0','info':{'title':title,'version':ver,'description':'Проект дополнения; приложения нет. Synthetic fixtures не являются результатами обученных моделей.'},'servers':[{'url':'https://credit.bank.example' if public else 'https://internal.credit.bank.example'}],'security':[{'SessionCookie':[]}] if public else [{'ServiceCertificate':[]}],'paths':{},'components':{'securitySchemes':{'SessionCookie':{'type':'apiKey','in':'cookie','name':'credit_session'}} if public else {'ServiceCertificate':{'type':'mutualTLS'}},'schemas':copy.deepcopy(c)}}
    pub=spec('Кредитный кабинет: ML-клиентские дополнения','1.3.0-design',True)
    internal=spec('Кредитный кабинет: ML и KB внутренние интерфейсы','2.0.0-design',False)
    def op(spec,path,method,name,request,response,roles,description='',deadline='2 с',success='200',financial=False):
        public=spec is pub
        params=[]
        import re
        for p in re.findall(r'{([^}]+)}',path):params.append({'name':p,'in':'path','required':True,'schema':version() if p=='documentVersion' else s()})
        if public:
            params.append({'name':'X-Company-Context','in':'header','required':True,'schema':version()})
            if method!='get':params.append({'name':'X-CSRF-Token','in':'header','required':True,'schema':s(256)})
        if method!='get':params.append({'name':'Idempotency-Key','in':'header','required':True,'schema':s()})
        if financial and method!='get':params.append({'name':'If-Match','in':'header','required':True,'schema':s(),'description':'ETag Application/InformationDraft, не statementVersion.'})
        codes=['400','401','403','404','409','422','429','500','503','504']
        responses={code:{'description':'Безопасная ошибка: '+code,'content':{'application/json':{'schema':ref('Error')}},'headers':{'Cache-Control':{'schema':{'const':'no-store'}}}} for code in codes}
        for code in ['429','503']:responses[code]['headers']['Retry-After']={'schema':integer(1,3600)}
        responses[success]={'description':'Успешно; проектный контракт','content':{'application/json':{'schema':ref(response)}},'headers':{'Cache-Control':{'schema':{'const':'no-store'}}}}
        if financial:responses[success]['headers']['ETag']={'schema':s()}
        if success=='202':responses[success]['headers']['Location']={'schema':s(512),'description':'Маршрут чтения операции или revocation.'}
        v={'operationId':name,'summary':description,'description':description+' Проверка identity, прав, версии и идемпотентности выполняется сервером.','parameters':params,'responses':responses,'x-allowed-service-role':roles,'x-time-budget':deadline}
        if request:v['requestBody']={'required':True,'content':{'application/json':{'schema':ref(request)}}}
        spec['paths'].setdefault(path,{})[method]=v
    for suffix,prefix in [('', '/api/v1/applications/{applicationId}'),('Rfi','/api/v1/applications/{applicationId}/information-requests/{requestId}/draft')]:
        path=prefix+'/financial-statement'
        op(pub,path,'get','getFinancial'+suffix,None,'FinancialStatement',['client'],'Прочитать финансовую анкету',financial=True)
        op(pub,path,'put','saveFinancial'+suffix,'FinancialInput','FinancialStatement',['client'],'Сохранить финансовые сведения в разрешённом черновике',financial=True)
        op(pub,path+'/confirm','post','confirmFinancial'+suffix,'FinancialConfirmation','FinancialStatement',['client'],'Подтвердить сохранённую финансовую версию',financial=True)
    op(pub,'/api/v1/assistant/messages','post','sendAssistantMessage','AssistantInput','AssistantResponse',['client'],'Ответить по утверждённой клиентской базе',deadline='20 с')
    op(pub,'/api/v1/assistant/conversations/{conversationId}','get','getAssistantConversation',None,'Conversation',['client'],'История с повторной проверкой доступа и отзыва')
    op(pub,'/api/v1/assistant/feedback','post','recordAssistantFeedback','AssistantFeedback','Receipt',['client'],'Сохранить UX-оценку без превращения в эталон')
    op(pub,'/api/v1/recommendation-feedback','post','recordRecommendationFeedback','RecommendationFeedback','Receipt',['client'],'Подтвердить показ/клик ранее выданного itemId')
    op(pub,'/api/v1/knowledge/{documentId}/versions/{documentVersion}','get','getPublishedKnowledge',None,'KnowledgeDocument',['client'],'Прочитать доступную опубликованную версию источника')
    op(internal,'/internal/v2/feature-snapshots','post','createFeatureSnapshot','FeatureSnapshotInput','FeatureSnapshot',['bank-adapter','feature-builder'],'Подготовить признаки точной отправки')
    op(internal,'/internal/v2/risk/evaluations','post','evaluateRiskV2','RiskRequest','RiskResult',['bank-adapter'],'Получить вспомогательный прогноз; proxy только DEMO_RESEARCH','1 с')
    op(internal,'/internal/v2/rankings','post','rankEligibleCandidates','RankingRequest','RankingResult',['workspace','catalog'],'Ранжировать только разрешённый набор; fallback RULES','150 мс')
    op(internal,'/internal/v1/kb/documents/{documentId}/publish','post','publishKnowledge','KBPublish','Receipt',['content-owner'],'Опубликовать утверждённый CLIENT документ',success='202')
    op(internal,'/internal/v1/kb/documents/{documentId}/revoke','post','revokeKnowledge','KBRevoke','Revocation',['content-owner','security'],'Зафиксировать deny и начать fencing; 202 ещё не ENFORCED',success='202')
    op(internal,'/internal/v1/kb/revocations/{revocationId}','get','getRevocation',None,'Revocation',['content-owner','security'],'Проверить enforcement и очистку отдельно')
    op(internal,'/internal/v1/ml/update-requests','post','requestMLUpdate','UpdateInput','UpdateRequest',['monitor','ml-operator','kb-controller'],'Долговечно принять дедуплицированный запрос',success='202')
    op(internal,'/internal/v1/ml/update-requests/{updateRequestId}','get','getMLUpdate',None,'UpdateRequest',['ml-operator','training-controller'],'Прочитать состояние обновления')
    op(internal,'/internal/v1/ml/update-requests/{updateRequestId}/claim','post','claimMLUpdate','ClaimInput','Lease',['training-controller'],'Получить CAS lease/generation для задания')
    op(internal,'/internal/v1/ml/update-requests/{updateRequestId}/lease/renew','post','renewMLLease','LeaseProof','Lease',['training-controller'],'Продлить своё поколение аренды')
    op(internal,'/internal/v1/ml/update-requests/{updateRequestId}/result','post','submitMLWorkResult','WorkResult','UpdateRequest',['training-controller'],'Принять результат текущей lease; не выдаёт approval')
    op(internal,'/internal/v1/ml/releases/{releaseId}/approvals','post','approveMLRelease','ApprovalInput','ApprovalRecord',['validator','risk-owner','product-owner','document-owner','content-owner'],'Утвердить/отклонить точные bundle/evaluation/policy digests')
    op(internal,'/internal/v1/ml/releases/{releaseId}/rollouts','post','startMLRollout','RolloutInput','Receipt',['deployment-controller'],'Продвинуть допущенный bundle при CAS routingVersion',success='202')
    op(internal,'/internal/v1/ml/releases/{releaseId}/rollback','post','rollbackMLRelease','RollbackInput','Receipt',['deployment-controller','oncall'],'Вернуть совместимый допущенный bundle без отмены tombstones',success='202')
    op(internal,'/internal/v1/ml/operations/{operationId}','get','getMLOperation',None,'Receipt',['ml-operator','deployment-controller','content-owner'],'Прочитать результат служебной операции')
    # Only reachable components are included in each contract.
    def prune(spec):
        found=set()
        def visit(x):
            if isinstance(x,dict):
                if '$ref' in x and x['$ref'].startswith('#/components/schemas/'):
                    n=x['$ref'].split('/')[-1]
                    if n not in found:found.add(n);visit(c[n])
                for k,v in x.items():
                    if k!='$ref':visit(v)
            elif isinstance(x,list):
                for v in x:visit(v)
        visit(spec['paths']);spec['components']['schemas']={n:c[n] for n in sorted(found)}
    prune(pub);prune(internal)
    save('api/public-extensions.openapi.json',pub);save('api/internal.openapi.json',internal)
    return pub,internal

EVENTS={
 'MLUpdateRequested':obj({'updateRequestId':s(),'family':{'type':'string','enum':FAMILIES},'triggerPolicyVersion':s()}),
 'MLReleaseValidated':obj({'releaseId':s(),'bundleDigest':sha(),'evaluationDigest':sha(),'policyVersion':s()}),
 'MLReleaseApprovalRecorded':obj({'releaseId':s(),'approvalId':s(),'decision':enum('APPROVE','REJECT'),'bundleDigest':sha()}),
 'MLReleaseActivated':obj({'releaseId':s(),'bundleDigest':sha(),'routingVersion':version(),'stage':enum('SHADOW','CANARY_5','CANARY_25','CHAMPION')}),
 'MLRollbackCompleted':obj({'releaseId':s(),'previousReleaseId':s(),'routingVersion':version(),'reasonCode':s()}),
 'KBDocumentPublished':obj({'corpusId':s(),'documentId':s(),'documentVersion':version(),'objectDigest':sha()}),
 'KBDocumentRevoked':obj({'corpusId':s(),'documentId':s(),'documentVersion':version(),'epoch':version(),'revocationId':s()}),
 'RecommendationExposureRecorded':obj({'exposureId':s(),'scope':enum('PRODUCT','FEED'),'candidateSetDigest':sha(),'releaseId':s()}),
 'RecommendationFeedbackRecorded':obj({'exposureId':s(),'clientEventId':s(),'itemId':s(),'action':enum('VIEW','CLICK')})}

def write_events():
    defs={}
    for n,p in EVENTS.items():
        defs[n]=obj({'eventId':s(),'eventType':{'const':n},'schemaVersion':{'const':1},'aggregateId':s(),'aggregateVersion':version(),'occurredAt':dt(),'correlationId':s(),'payload':p})
    save('schemas/events-v1.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','oneOf':[{'$ref':'#/$defs/'+n} for n in defs],'$defs':defs})
    save('schemas/topics.json',[{'topic':'credit.ml-control.v1','key':'updateRequestId or releaseId within its aggregate','events':list(EVENTS)[:5]},{'topic':'credit.kb.v1','key':'corpusId','events':list(EVENTS)[5:7]},{'topic':'credit.recommendations.v1','key':'exposureId','events':list(EVENTS)[7:]}])

def write_policy():
    p={'policyVersion':'dev-demo-1','status':'DEVELOPMENT_DEFAULT_NOT_PRODUCTION_APPROVED','environment':'DEV_DEMO','productionRequires':['approved-data-target','approved-policy-signature','approved-retention-security','measured-capacity-ha','two-independent-reviewers'],'manualApproval':{'allFamilies':True,'independentValidator':True,'ownerRequired':True,'authorCannotApprove':True,'binds':['bundleDigest','evaluationDigest','policyVersion'],'ttlHours':168},'prohibitedLiveScoreKinds':['BANKRUPTCY_PROXY'],'canary':{'stagesPercent':[5,25,100],'minMinutesPerStage':30,'minCandidateRequests':1000,'ragMinCandidateAnswers':200,'ragHumanReviewedAnswers':25,'errorRateMax':0.01,'p95RatioToChampionMax':1.2,'minGuardrailRequests':100,'noDataAction':'HOLD'},'hardInvariants':{'unauthorizedDisclosures':0,'revokedSourceExposures':0,'ineligibleRecommendations':0,'invalidFinancialSignUnits':0},'quality':{'risk':{'rocAucMin':0.70,'prAucMustBeatPrevalence':True,'brierMaxIncrease':0.01,'rocAucNonInferiorityMargin':0.02,'bootstrapRepeats':1000,'minTestPositives':30},'ranking':{'ndcgAt5MaxRelativeDrop':0.02,'minLabeledExposures':1000,'minPositiveActions':100},'ocr':{'financialFieldExactMatchMin':0.95,'minVerifiedDocuments':200,'signUnitErrorsMax':0},'rag':{'recallAt10Min':0.85,'faithfulnessMin':0.90,'responseRelevancyMin':0.80,'correctRefusalMin':0.95,'citationValidityMin':1.0,'minGoldenQuestions':100,'minAdversarialCases':50}},'update':{'kbUniqueDocumentsN':10,'kbMaxWaitHours':24,'deletionBypassesBatch':True,'singleBuildPerCorpus':True,'cooldownHours':24,'minNewMatureRiskRows':1000,'minNewMatureRiskPositives':100,'minRagVerifiedPairs':500,'leaseMinutes':10,'heartbeatSeconds':60,'technicalRetryMinutes':[1,5,15]},'drift':{'psiThreshold':0.2,'successiveDailyWindows':2,'minRowsPerWindow':1000,'action':'DIAGNOSE_BEFORE_RETRAIN'},'reproduction':{'featureAbsoluteTolerance':1e-8,'tabularPredictionAbsoluteTolerance':1e-6,'trainingMetricTolerance':0.005,'publicSplit':[0.6,0.2,0.2],'seed':42},'deadlinesMs':{'risk':1000,'ranking':150,'retrieval':1000,'reranking':300,'ragTotal':20000},'rag':{'denseTopK':20,'sparseTopK':20,'rrfK':60,'rerankTopK':20,'contextChunksMax':5,'chunkTokensApprox':450,'overlapTokens':60,'streaming':False,'responseCacheEnabled':False,'revocationTargetSeconds':5}}
    save('policies/release-policy.json',p)
    return p

def examples(c):
    D='a'*64;now='2026-10-20T10:00:00Z'
    objref={'bucket':'ml-design-fixtures','key':'synthetic/artifact.bin','objectVersion':'fixture-1','sha256':D}
    fin={'periodStart':'2025-01-01','periodEnd':'2025-12-31','reportingStandard':'DEMO','currency':'RUB','values':dict(zip(FIELDS,[100000000,60000000,50000000,25000000,40000000,150000000,12000000,18000000])),'sourceDocumentReferences':[]}
    fs={'featureSnapshotId':'fs-demo-1','submissionSnapshotId':'submission-demo-1','financialStatementVersion':1,'featureSchemaVersion':2,'featureCodeDigest':D,'featureAsOf':now,'latestSourceAvailableAt':'2026-10-19T10:00:00Z','features':dict(zip(FEATURES,[.12,.6,.25,2.,.18,2/3,1.5,.4])),'missingFeatures':[],'snapshotDigest':D}
    snapbytes={k:v for k,v in fs.items() if k not in ['featureSnapshotId','snapshotDigest']};fs['snapshotDigest']=digest(snapbytes)
    risk={'inferenceId':'inference-demo-1','requestId':'risk-demo-1','score':.12,'scoreKind':'BANKRUPTCY_PROXY','calibrationStatus':'DEMONSTRATION','releaseId':'risk-demo-release-1','bundleDigest':D,'modelVersion':'1','featureSnapshotId':fs['featureSnapshotId'],'featureSnapshotDigest':fs['snapshotDigest'],'internalReasonCodes':['DEMO_PROXY_ONLY']}
    candidates=['working-capital','credit-line','overdraft'];candidate_digest=digest({'scope':'PRODUCT','candidateIds':sorted(candidates),'catalogVersion':1,'eligibilityVersion':1})
    rank={'requestId':'ranking-demo-1','scope':'PRODUCT','candidateIds':candidates,'candidateSetDigest':candidate_digest,'catalogVersion':1,'eligibilityVersion':1,'stage':'DRAFT','contextCategory':'SME_GENERAL','fundingPurpose':'WORKING_CAPITAL'}
    rresult={'requestId':rank['requestId'],'scope':'PRODUCT','rankedIds':['credit-line','working-capital','overdraft'],'candidateSetDigest':candidate_digest,'exposureId':'exposure-demo-1','releaseId':'rules-products-1','mode':'RULES','reasonCategory':'FIT_TO_PURPOSE'}
    answer={'conversationId':'conversation-demo-1','messageId':'message-demo-1','status':'ANSWER','answer':'В демонстрационном кабинете сведения можно сохранить в черновике.','citations':[{'documentId':'faq-draft','documentVersion':1,'chunkId':'faq-draft-v1-1','title':'Сохранение черновика','locator':'Раздел 1','sourcePath':'/api/v1/knowledge/faq-draft/versions/1'}],'releaseId':'rag-demo-release-1','bundleDigest':D,'kbEpoch':1}
    rel={'releaseId':'risk-demo-release-1','family':'RISK','createdBy':'author-demo','createdAt':now,'imageDigest':'sha256:'+D,'datasetDigest':D,'evaluationDigest':D,'policyVersion':'dev-demo-1','assets':{n:objref for n in ['model','preprocessor','featureRegistry']},'featureSchemaVersion':2,'scoreKind':'BANKRUPTCY_PROXY'}
    risk['bundleDigest']=digest(rel)
    dataset={'datasetId':'public-proxy-design-fixture','kind':'PUBLIC_PROXY','createdAt':now,'objects':[objref],'sourceLicense':'CC BY 4.0','attribution':'Tomczak, S. (2016). Polish Companies Bankruptcy. UCI, doi:10.24432/C5F600.','targetVersion':'bankruptcy-1y-proxy-v1','availabilityRule':'Public benchmark: reliable decision and publication dates unavailable; no historical bank validation claimed.','splitMembership':objref,'splitSeed':42,'rowCount':5910,'positiveCount':410}
    experiment={'runId':'design-not-trained','datasetDigest':D,'gitCommit':'b'*40,'imageDigest':'sha256:'+D,'dependencyLock':objref,'featureCodeDigest':D,'featureSchemaVersion':2,'targetVersion':'bankruptcy-1y-proxy-v1','seed':42,'hardwareFingerprint':'DESIGN_FIXTURE_NOT_EXECUTED','hyperparameters':{'modelFamily':'logistic-regression','classWeight':'balanced'},'evaluationReport':objref,'reproductionTolerance':.005}
    samples={'financial-input':('FinancialInput',fin),'financial-confirmation':('FinancialConfirmation',{'expectedStatementVersion':1,'confirmedFieldNames':FIELDS,'documentReferences':[]}), 'feature-snapshot':('FeatureSnapshot',fs),'risk-request':('RiskRequest',{'requestId':'risk-demo-1','featureSnapshotId':fs['featureSnapshotId'],'featureSnapshotDigest':fs['snapshotDigest'],'featureSchemaVersion':2,'purpose':'DEMO_RESEARCH'}),'risk-result':('RiskResult',risk),'ranking-request':('RankingRequest',rank),'ranking-result':('RankingResult',rresult),'assistant-answer':('AssistantResponse',answer),'release-manifest':('ReleaseManifest',rel),'dataset-manifest':('DatasetManifest',dataset),'experiment-manifest':('ExperimentManifest',experiment),'approval':('ApprovalInput',{'decision':'APPROVE','reviewRole':'VALIDATOR','bundleDigest':D,'evaluationDigest':D,'policyVersion':'dev-demo-1','expiresAt':'2026-10-27T10:00:00Z','comment':'Synthetic schema fixture; no release is actually approved.'})}
    fixtures=[]
    samples['approval'][1]['bundleDigest']=digest(rel)
    for slug,(name,value) in samples.items():
        save('examples/'+slug+'.json',value)
        fixtures.append({'id':'valid-'+slug,'schema':name,'valid':True,'value':value,'kind':'schema'})
    def invalid(slug,name,val):fixtures.append({'id':slug,'schema':name,'valid':False,'value':val,'kind':'schema'})
    bad=copy.deepcopy(fin);bad['confirmed']=True;invalid('forged-confirmation','FinancialInput',bad)
    invalid('confirmed-without-provenance','FinancialStatement',{'statementVersion':1,'containerVersion':1,'confirmed':True,'statement':fin,'provenance':[]})
    bad=copy.deepcopy(fin);bad['values']['revenueMinor']=1.25;invalid('fractional-minor-units','FinancialInput',bad)
    bad=copy.deepcopy(fin);bad['values']['totalLiabilitiesMinor']=-1;invalid('negative-liabilities','FinancialInput',bad)
    bad=copy.deepcopy(risk);bad['calibrationStatus']='VALIDATED';invalid('proxy-as-validated-pd','RiskResult',bad)
    bad=copy.deepcopy(risk);bad['score']=1.2;invalid('score-out-of-range','RiskResult',bad)
    bad=copy.deepcopy(rank);bad.pop('eligibilityVersion');invalid('product-without-eligibility','RankingRequest',bad)
    bad=copy.deepcopy(rresult);bad['rankedIds']=['overdraft','overdraft'];invalid('duplicate-ranked-id','RankingResult',bad)
    bad=copy.deepcopy(answer);bad['citations']=[];invalid('answer-without-source','AssistantResponse',bad)
    bad=copy.deepcopy(answer);bad['status']='SEARCH_ONLY';invalid('search-only-generated-answer','AssistantResponse',bad)
    bad=copy.deepcopy(answer);bad['citations'][0]['sourcePath']='https://untrusted.example/';invalid('external-citation-url','AssistantResponse',bad)
    bad=copy.deepcopy(samples['approval'][1]);bad['actorId']='risk-owner';invalid('forged-approval-actor','ApprovalInput',bad)
    bad=copy.deepcopy(rel);bad['assets'].pop('featureRegistry');invalid('risk-without-feature-registry','ReleaseManifest',bad)
    rag=copy.deepcopy(rel);rag.update(releaseId='rag-demo-release-1',family='RAG_INDEX',collectionName='kb_fixture_1',corpusCutoff=now,kbEpoch=1)
    rag.pop('scoreKind');rag.pop('featureSchemaVersion');rag['assets']={n:objref for n in ['corpus','embedding','sparseConfig','reranker','tokenizer','prompt','retrievalConfig','generator']}
    save('examples/rag-release-manifest.json',rag);fixtures.append({'id':'valid-rag-manifest','schema':'ReleaseManifest','valid':True,'value':rag,'kind':'schema'})
    answer['bundleDigest']=digest(rag);save('examples/assistant-answer.json',answer)
    bad=copy.deepcopy(rag);bad['assets'].pop('embedding');invalid('rag-without-embedding','ReleaseManifest',bad)
    for n,p in EVENTS.items():
        val={}
        for key,ss in p['properties'].items():
            val[key]=ss.get('const',ss.get('enum',[None])[0])
            if val[key] is None:val[key]=1 if ss.get('type')=='integer' else D if 'pattern' in ss else key+'-demo'
        aggregate=val['updateRequestId'] if n=='MLUpdateRequested' else val['releaseId'] if n.startswith('ML') else val['corpusId'] if n.startswith('KB') else val['exposureId']
        event={'eventId':'event-'+n,'eventType':n,'schemaVersion':1,'aggregateId':aggregate,'aggregateVersion':1,'occurredAt':now,'correlationId':'corr-demo','payload':val}
        fixtures.append({'id':'valid-event-'+n,'schema':'EVENT','valid':True,'value':event,'kind':'schema'});save('examples/event-'+n+'.json',event)
        bad=copy.deepcopy(event);bad['payload']['rawCustomerText']='forbidden';fixtures.append({'id':'invalid-event-extra-'+n,'schema':'EVENT','valid':False,'value':bad,'kind':'schema'})
    save('contract-fixtures.json',fixtures)
    save('examples/README.json',{'notice':'All values are synthetic design fixtures. No artifacts, models, performance scores or approvals were produced by a training/deployment system. Repeated checksums/object refs are illustrative only; no dataset/model files are bundled.','featureSnapshotHashScope':'Canonical sorted JSON, UTF-8, ensure_ascii=false, separators=(comma,colon), exclude featureSnapshotId and snapshotDigest. BundleDigest hashes canonical ReleaseManifest without an embedded self-hash.'})

def write_all():
    c=schemas();contracts(c);write_events();write_policy();examples(c)
    for n,slug in [('DatasetManifest','dataset-manifest'),('ExperimentManifest','experiment-manifest'),('ReleaseManifest','release-manifest'),('FeatureSnapshot','feature-snapshot')]:save('schemas/'+slug+'.schema.json',standalone(c,n))
    return c
if __name__=='__main__':write_all()
