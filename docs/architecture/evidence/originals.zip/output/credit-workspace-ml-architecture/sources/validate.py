"""Validate artifacts and design oracles; this does not exercise an application."""
from pathlib import Path
import sys,os,json,hashlib,re,math,xml.etree.ElementTree as ET,copy
deps=os.environ.get('ML_ARCH_DEPS','/tmp/credit-architecture-validation')
if Path(deps).exists():sys.path.insert(0,deps)
from jsonschema import Draft202012Validator,FormatChecker
from openapi_spec_validator import validate as validate_openapi
from pypdf import PdfReader
from specification import OUT,schemas,standalone,digest,FIELDS,FEATURES

ROOT=OUT.parent.parent
def load(p):return json.loads((OUT/p).read_text())

def main():
    checks=[]
    def check(name,ok,detail=''):
        checks.append({'check':name,'passed':bool(ok),'detail':detail})
    def guard(name,fn):
        try:fn();check(name,True)
        except Exception as e:check(name,False,type(e).__name__+': '+str(e)[:700])
    c=schemas();fmt=FormatChecker()
    for f in sorted(OUT.rglob('*.json')):
        if '__pycache__' in f.parts:continue
        guard('json:'+str(f.relative_to(OUT)),lambda f=f:json.loads(f.read_text(),parse_constant=lambda x:(_ for _ in ()).throw(ValueError('Non-finite JSON '+x))))
    opnames=[]
    for f in sorted((OUT/'api').glob('*.openapi.json')):
        x=json.loads(f.read_text());guard('openapi:'+f.name,lambda x=x:validate_openapi(x))
        if f.name=='integration-preview.openapi.json':continue
        for path,methods in x['paths'].items():
            for method,o in methods.items():
                if method not in ['get','put','post','patch','delete']:continue
                opnames.append(o['operationId']);params={p['name']:p for p in o['parameters']}
                check('operation-security:'+o['operationId'],bool(o.get('x-allowed-service-role')) and bool(o.get('x-time-budget')))
                if path.startswith('/api/'):
                    check('company-context:'+o['operationId'],'X-Company-Context' in params and params['X-Company-Context']['required'])
                    if method!='get':check('csrf:'+o['operationId'],'X-CSRF-Token' in params and params['X-CSRF-Token']['required'])
                if method!='get':check('idempotency:'+o['operationId'],'Idempotency-Key' in params and params['Idempotency-Key']['required'])
                if 'financial-statement' in path and method!='get':check('financial-etag:'+o['operationId'],'If-Match' in params)
                for code,r in o['responses'].items():check('no-store:'+o['operationId']+':'+code,r.get('headers',{}).get('Cache-Control',{}).get('schema',{}).get('const')=='no-store')
    check('unique-operation-ids',len(opnames)==len(set(opnames)))
    from extensions import apply_patch
    baseline_public=json.loads((ROOT/'output/credit-workspace-backend-architecture/api/openapi.json').read_text())
    preview=load('api/integration-preview.openapi.json')
    check('integration-patch-reproduces-preview',apply_patch(baseline_public,load('api/baseline-integration.patch.json'))==preview)
    check('baseline-paths-preserved-in-preview',all(preview['paths'].get(k)==v for k,v in baseline_public['paths'].items()))
    check('public-cookie-compatible',load('api/public-extensions.openapi.json')['components']['securitySchemes']['SessionCookie']==baseline_public['components']['securitySchemes']['SessionCookie'])
    check('preview-sixty-operations',sum(len(v) for v in preview['paths'].values())==60)
    check('no-client-assigned-financial-snapshot','financialSnapshotId' not in preview['components']['schemas']['Submit']['properties'])
    for n,s in c.items():guard('schema-definition:'+n,lambda s=s:Draft202012Validator.check_schema(s))
    for f in (OUT/'schemas').glob('*.schema.json'):guard('schema-file:'+f.name,lambda f=f:Draft202012Validator.check_schema(json.loads(f.read_text())))
    fixture_results=[]
    for t in load('contract-fixtures.json'):
        sc=load('schemas/events-v1.schema.json') if t['schema']=='EVENT' else standalone(c,t['schema'])
        errs=list(Draft202012Validator(sc,format_checker=fmt).iter_errors(t['value']))
        actual=not errs;check('fixture:'+t['id'],actual==t['valid'],('; '.join(e.message for e in errs))[:300] if actual!=t['valid'] else '')
        if t['schema']=='EVENT' and t['valid']:
            payload=t['value']['payload'];name=t['value']['eventType']
            key='updateRequestId' if name=='MLUpdateRequested' else 'releaseId' if name.startswith('ML') else 'corpusId' if name.startswith('KB') else 'exposureId'
            check('event-aggregate:'+name,t['value']['aggregateId']==payload[key])
        fixture_results.append({'id':t['id'],'expectedValid':t['valid'],'actualValid':actual,'passed':actual==t['valid']})
    save=lambda p,x:(OUT/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
    save('fixture-validation.json',fixture_results)
    task=load('tasks.json');tests=load('acceptance-cases.json');reqs=load('traceability.json');findings=load('findings.json')
    tasks={t['id']:t for t in task};testids={t['id'] for t in tests};diagrams={d['id'] for d in load('diagram-manifest.json')}
    check('unique-task-ids',len(tasks)==len(task));check('unique-acceptance-ids',len(testids)==len(tests))
    visited=set();active=set()
    def visit(k):
        if k in active:raise ValueError('Task cycle at '+k)
        if k in visited:return
        active.add(k)
        for d in tasks[k]['dependsOn']:visit(d)
        active.remove(k);visited.add(k)
    guard('task-acyclic',lambda:[visit(k) for k in tasks])
    for t in task:
        check('task-tests:'+t['id'],bool(t['acceptance']) and set(t['acceptance'])<=testids)
        check('task-doc:'+t['id'],t['id']+'.' in (OUT/'docs/09-workplan.md').read_text())
    for r in reqs:check('traceability:'+r['id'],bool(r['tasks']) and set(r['tasks'])<=tasks.keys() and bool(r['acceptance']) and set(r['acceptance'])<=testids and (OUT/r['document']).exists() and r['diagram'] in diagrams)
    covered=set(v for t in task for v in t['acceptance'])
    check('application-tests-covered',set('C%02d'%i for i in range(1,47))|{'C50'}<=covered)
    for f in findings:
        ev=f['evidence'];p=ROOT/ev['path'];lines=p.read_text().splitlines()
        check('finding-evidence:'+f['id'],hashlib.sha256(p.read_bytes()).hexdigest()==ev['sha256'] and lines[ev['line']-1].startswith(ev['quote']))
        check('finding-links:'+f['id'],set(f['tasks'])<=tasks.keys() and set(f['acceptance'])<=testids)
    for i in load('integration-matrix.json'):check('integration-links:'+i['id'],set(i['tasks'])<=tasks.keys() and set(i['tests'])<=testids)
    catalog=load('observability/metrics-catalog.json');names={m['name'] for m in catalog['metrics']}
    for m in catalog['metrics']:
        check('metric-bounded-labels:'+m['name'],not set(m['labels'])&{'actorId','companyId','documentId','applicationId','question','userId'})
    dashboard=load('observability/dashboard-specs.json')
    expressions=[q for p in dashboard['panels'] for q in p['queries'].values()]+[a['expr'] for a in dashboard['alerts']]
    for i,expr in enumerate(expressions):
        found=set(re.findall(r'\bcredit_[a-zA-Z0-9_]+',expr));check('metric-query-references:'+str(i),all(n in names or n.endswith('_bucket') and n[:-7] in names for n in found))
    for g in load('external-gates.json'):check('production-gate:'+g['id'],bool(g['owner']) and bool(g['acceptance']) and g['status']=='REQUIRES_EXTERNAL_VALIDATION')
    # Hash and inventory protection of all supplied architecture packages.
    baseline=load('sources/baseline-sha256.json')
    for name,h in baseline.items():
        p=ROOT/name;check('baseline:'+name,p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==h)
    for item in load('source-manifest.json')['local']:
        p=Path(item['path']);check('source:'+p.name,p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'])
    # Relative file links in Markdown must resolve. URLs and fragments are not filesystem paths.
    for f in list((OUT/'docs').glob('*.md'))+[OUT/'README.md']:
        for target in re.findall(r'\]\(([^)]+)\)',f.read_text()):
            if target.startswith(('http:','https:','#','mailto:')):continue
            check('markdown-link:'+f.name+':'+target,(f.parent/target.split('#')[0]).exists())
    # Drawing geometry and actual connected draw.io cells (not screenshot-only diagrams).
    tree=ET.parse(OUT/'ml-architecture.drawio');pages=tree.findall('diagram')
    check('seven-editable-diagrams',len(pages)==7)
    for page in pages:
        cells=page.findall('./mxGraphModel/root/mxCell');ids=[e.attrib['id'] for e in cells];check('drawing-ids:'+page.attrib['id'],len(ids)==len(set(ids)))
        for e in cells:
            if e.get('edge')=='1':check('connected-edge:'+page.attrib['id']+':'+e.get('id'),e.get('source') in ids and e.get('target') in ids)
    for scene in load('sources/scenes.json'):
        nodes=[s for s in scene['shapes'] if s['kind']=='node']
        check('svg:'+scene['id'],(OUT/'svg'/str(scene['id']+'.svg')).exists())
        guard('svg-xml:'+scene['id'],lambda scene=scene:ET.parse(OUT/'svg'/str(scene['id']+'.svg')))
        for i,n in enumerate(nodes):
            check('node-bounds:'+scene['id']+':'+n['id'],n['x']>=0 and n['y']>=180 and n['x']+n['w']<=scene['width'] and n['y']+n['h']<=1240)
            for m in nodes[i+1:]:
                overlap=min(n['x']+n['w'],m['x']+m['w'])-max(n['x'],m['x'])>0 and min(n['y']+n['h'],m['y']+m['h'])-max(n['y'],m['y'])>0
                if overlap:check('node-overlap:'+scene['id']+':'+n['id']+':'+m['id'],False)
        from diagram_engine import pdfmetrics
        crossings=[]
        for edge in [s for s in scene['shapes'] if s['kind']=='edge']:
            for text in [s for s in scene['shapes'] if s['kind']=='text']:
                x0=text['x'];x1=x0+max(pdfmetrics.stringWidth(line,'DV-B' if text['bold'] else 'DV',text['size']) for line in text['lines'])
                y0=text['y'];y1=y0+len(text['lines'])*text['size']*1.35
                for (ax,ay),(bx,by) in zip(edge['points'],edge['points'][1:]):
                    hit=ax==bx and x0<ax<x1 and max(min(ay,by),y0)<min(max(ay,by),y1) or ay==by and y0<ay<y1 and max(min(ax,bx),x0)<min(max(ax,bx),x1)
                    if hit:crossings.append(edge['id']+' -> '+text['lines'][0])
        check('no-edge-free-text-crossing:'+scene['id'],not crossings,', '.join(crossings))
    # Design oracles: arithmetic and forbidden state transitions. These are not production code tests.
    semantic=[]
    def oracle(name,ok,expected):
        semantic.append({'id':name,'passed':bool(ok),'expected':expected,'scope':'DESIGN_ORACLE_NOT_RUNTIME'});check('design-oracle:'+name,ok)
    fin=load('examples/financial-input.json')['values'];f=load('examples/feature-snapshot.json')
    expected=[fin['netProfitMinor']/fin['totalAssetsMinor'],fin['totalLiabilitiesMinor']/fin['totalAssetsMinor'],(fin['currentAssetsMinor']-fin['currentLiabilitiesMinor'])/fin['totalAssetsMinor'],fin['currentAssetsMinor']/fin['currentLiabilitiesMinor'],fin['ebitMinor']/fin['totalAssetsMinor'],fin['equityMinor']/fin['totalLiabilitiesMinor'],fin['revenueMinor']/fin['totalAssetsMinor'],fin['equityMinor']/fin['totalAssetsMinor']]
    oracle('eight-financial-coefficients',all(abs(f['features'][n]-v)<=1e-8 for n,v in zip(FEATURES,expected)),'All formulas match the eight financial inputs.')
    actual_digest=digest({k:v for k,v in f.items() if k not in ['snapshotDigest','featureSnapshotId']})
    oracle('snapshot-content-digest',f['snapshotDigest']==actual_digest,'Digest hashes immutable content, no self-hash.')
    eligible=lambda event,available,decision:event<=decision and available<=decision
    oracle('future-availability-excluded',not eligible('2025-12-31','2026-10-21','2026-10-20'),'Old event time with future availableAt must not enter train.')
    req=load('examples/ranking-request.json');res=load('examples/ranking-result.json')
    perm=lambda cand,rank:len(rank)==len(cand) and len(set(rank))==len(rank) and set(rank)==set(cand)
    oracle('ranking-permutation',perm(req['candidateIds'],res['rankedIds']),'Result is the eligible candidate permutation.')
    oracle('ranking-ineligible-rejected',not perm(req['candidateIds'],['unapproved-product']),'Unknown item is not eligible by model decision.')
    oracle('ranking-missing-rejected',not perm(req['candidateIds'],req['candidateIds'][:-1]),'Dropping an eligible candidate violates this ranking contract.')
    policy=load('policies/release-policy.json')
    oracle('all-release-families-manual',policy['manualApproval']['allFamilies'] and policy['manualApproval']['authorCannotApprove'],'Every release requires independent human approval.')
    oracle('live-proxy-forbidden','BANKRUPTCY_PROXY' in policy['prohibitedLiveScoreKinds'],'Proxy cannot be promoted to live credit.')
    allowed=lambda doc,epoch,live,deny:epoch==live and doc not in deny
    oracle('revocation-survives-rollback',not allowed('removed-doc',1,2,{'removed-doc'}),'Restoring collection epoch 1 cannot bypass epoch 2 deny.')
    oracle('denied-current-epoch',not allowed('removed-doc',2,2,{'removed-doc'}),'Current epoch cannot authorize a denied source.')
    oracle('same-epoch-unrevoked',allowed('published-doc',2,2,{'removed-doc'}),'An unrevoked published source with current authority may pass.')
    oracle('deletion-bypasses-n',policy['update']['deletionBypassesBatch'] and policy['update']['kbUniqueDocumentsN']==10 and policy['update']['kbMaxWaitHours']==24,'Revoke is immediate, add/change use N/time batching.')
    oracle('no-stream-before-revoke-check',policy['rag']['streaming'] is False and policy['rag']['responseCacheEnabled'] is False,'MVP buffers responses and has no response cache.')
    approval=load('examples/approval.json');release=load('examples/release-manifest.json')
    oracle('approval-digest-match',approval['bundleDigest']==digest(release) and approval['evaluationDigest']==release['evaluationDigest'] and approval['policyVersion']==release['policyVersion'],'Matching bundle, evaluation and policy required.')
    oracle('risk-result-bundle-digest',load('examples/risk-result.json')['bundleDigest']==digest(release),'Inference pins the exact bundle.')
    oracle('rag-answer-bundle-digest',load('examples/assistant-answer.json')['bundleDigest']==digest(load('examples/rag-release-manifest.json')),'RAG output pins the exact corpus/model bundle.')
    altered=copy.deepcopy(release);altered['evaluationDigest']='c'*64
    oracle('changed-evaluation-invalidates-approval',approval['evaluationDigest']!=altered['evaluationDigest'],'New evaluation requires new human decision.')
    oracle('insufficient-canary-holds',policy['canary']['noDataAction']=='HOLD','No automatic promotion with insufficient traffic.')
    oracle('production-default-not-approved',policy['environment']=='DEV_DEMO' and 'NOT_PRODUCTION_APPROVED' in policy['status'],'Development defaults do not authorize production.')
    save('semantic-fixtures.json',semantic)
    for name,count in [('ml-architecture-atlas.pdf',7),('ml-system-guide.pdf',None)]:
        p=PdfReader(OUT/name);check('pdf-pages:'+name,len(p.pages)==count if count else len(p.pages)>=20)
        for i,page in enumerate(p.pages):check('pdf-text:'+name+':'+str(i+1),len((page.extract_text() or '').strip())>80)
    report={'status':'PASS' if all(x['passed'] for x in checks) else 'FAIL','checkedAtDesignDate':'2026-10-20','scope':'Static architecture package, schemas, synthetic fixtures, design oracles, baseline preservation. No application/model/load/security/DR tests executed.','totalChecks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'baselineFiles':len(baseline),'schemaFixtures':len(fixture_results),'designOracles':len(semantic),'publicOperations':sum(len(v) for v in load('api/public-extensions.openapi.json')['paths'].values()),'internalOperations':sum(len(v) for v in load('api/internal.openapi.json')['paths'].values()),'checks':checks}
    save('validation-report.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False))
    for x in checks:
        if not x['passed']:print(json.dumps(x,ensure_ascii=False))
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
