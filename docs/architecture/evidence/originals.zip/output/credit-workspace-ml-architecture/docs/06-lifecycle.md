# 6. Автоматизация обучения и безопасный выпуск

## Источники сигналов

Плановый запуск, новые созревшие метки, достаточная проверенная разметка, изменение опубликованных знаний и устойчивое падение метрик могут создать UpdateRequest. Ошибка данных создаёт DATA_INCIDENT, а не слепой retrain. Статистический дрейф - основание расследовать, а не доказательство concept drift.

Начальная частота мониторинга: DQ/свежесть каждые 15 минут, суточный drift, недельный анализ качества RecSys/OCR и месячный анализ созревших риск-когорт. RAG sampled evaluation выполняется ежедневно и перед каждым релизом. Для MVP расписание работает на replay/synthetic fixtures; оно не создаёт отсутствующие реальные метки.

Сигнал содержит model family/corpus, reference/current window, metric version, report digest и deduplication key. Сигнал сохраняется в control PostgreSQL с outbox. Airflow забирает долговечную работу по служебной роли; Grafana webhook сам по себе не является реестром и не гарантирует доставку.

## Реестр обновления

Состояния UpdateRequest: REQUESTED, DIAGNOSING, BLOCKED_DATA, PREPARING, RUNNING, VALIDATING, AWAITING_APPROVAL, REJECTED, RELEASED, FAILED. Отсутствие меток переводит запрос в BLOCKED_DATA с причиной и владельцем; после появления данных разрешён явный resume. Исключения и retry не теряют исходный requestId.

Уникальность: family + sourceWindow/corpusCutoff + triggerPolicyVersion. На family/corpus действует одна активная сборка. Lease 10 минут с heartbeat раз в минуту; истечение допускает новое generation. Результат прежнего generation отвергается CAS. Для технической ошибки до трёх повторов с backoff 1/5/15 минут; ошибка схемы/лицензии/утечки не повторяется автоматически.

Cooldown после автоматического retrain - 24 часа. Удаление KB и критическая ошибка источника обходят обычный cooldown, но не конкурируют с активной сборкой: ставят высокоприоритетную ревизию и аннулируют несовместимый кандидат. Рост очереди не создаёт бесконечно новые эксперименты.

## DAG и артефакты

| DAG | Основные шаги | Результат |
| --- | --- | --- |
| data_quality_materialize | Снимок -> DQ/availability -> признаки -> parity -> публикация | Dataset/feature manifest |
| risk_train | Созревшие labels -> split -> baseline/candidate -> calibration -> evaluation | Модель + model card |
| ranking_train | Подтверждённые exposures -> attribution -> temporal split -> ranking eval | Отдельный PRODUCT или FEED bundle |
| ocr_train | Проверенная разметка -> document grouped split -> field evaluation | OCR + parser bundle |
| kb_build | Published cutoff -> parse/chunk -> embed -> index -> retrieval/RAG eval | Corpus + RAG bundle |
| rag_component_train | Размеченные пары -> embedding/reranker candidate -> rebuild -> eval | Новый RAG bundle |
| monitor_report | Выбор окон -> Evidently/RAGAS -> report -> UpdateRequest/incident | Версионированный отчёт |
| release_validate | Schemas -> compatibility -> smoke -> performance -> approval readiness | Подписанный набор доказательств |

Airflow передаёт только ссылки/digests; большие наборы остаются в governed S3. Ручное ожидание не занимает worker slot: approval живёт в control store, DAG завершается в AWAITING_APPROVAL. Deployment controller начинает выпуск после отдельного подтверждённого перехода.

## Воспроизводимый эксперимент

Manifest фиксирует dataset snapshot, SHA-256 объектов, split membership, targetVersion, feature code/schema, Git commit, image digest, полный dependency lock, hardware/CUDA/driver fingerprint, seed, hyperparameters и допуск сравнения. Сохраняются pipeline и preprocessing вместе с моделью, а не только estimator weights. Изменение схемы, калибратора и postprocessing считается новым bundle.

Требуется повтор CPU inference с max absolute difference <=1e-6 для табличных результатов при одинаковых байтах и образе. Повтор обучения на фиксированном CPU-профиле проверяет ROC-AUC/PR-AUC в пределах 0.005; это проектный допуск, не обещание bitwise equality. Для GPU фиксируются недетерминированные операции и численные отклонения. Для LLM/RAG проверяются источники и распределение оценок, а не побайтовое равенство текста. Параметры генерации и seed сохраняются, даже если backend не гарантирует полную детерминированность.

В MLflow сохраняются runs, datasets, tags, метрики, отчёты и зарегистрированные числовые версии. Aliases champion/candidate удобны операторам, но actual routing закрепляет bundleDigest и модельную версию. Promotion прав на MLflow не заменяет permission deployment controller.

Digest проверяется по точным сохранённым байтам артефакта. Для JSON producer использует фиксированную сериализацию, описанную в examples/README.json; получатель не пересериализует числа другой библиотекой перед сверкой SHA-256.

## Ручная валидация

Все кандидаты требуют человека, включая новый corpus RAG без смены весов. Reviewer получает model card, отличие от champion, происхождение данных, DQ/качество, ограничения, нагрузочный отчёт, план отката и evaluation digest. Автор релиза не утверждает собственный кандидат.

Скоринг: независимый validator и risk owner. RecSys: ML validator и product owner. OCR: ML validator и document owner. RAG: ML validator и content owner. В MVP это две различные тестовые identity с аудитом; в production - роли IAM. Approval связывает actor identity из аутентификации, bundle/evaluation/policy digests, действие, комментарий и срок. Клиент не передаёт произвольное имя утверждающего.

Риск-policy development-default запрещает live использование BANKRUPTCY_PROXY. Допуск банковского PD требует отдельно утверждённых данных, таргета, калибровки, сегментов и эксплуатации. Ложное повышение calibrationStatus не проходит проверку подписанного release manifest.

## Shadow и canary

Состояния релиза: CANDIDATE, VALIDATED, APPROVED, SHADOW, CANARY_5, CANARY_25, CHAMPION, REJECTED, ROLLED_BACK. Shadow не влияет на решение/порядок, не пишет второй бизнес-эффект и имеет отдельный ресурсный бюджет. Shadow RAG с пользователями применяется только после разрешения на обработку тех же данных; прежде используется replay evaluation.

Назначение canary стабильно по companyId и family на стороне router; OCR закрепляется по documentId, RAG по беседе в текущей компании. Для скоринга первый успешный inference по requestId закрепляется навсегда, повтор не мигрирует между группами. На этапе 100% CHAMPION заменяется атомарная routing revision, предыдущий bundle остаётся готов к откату.

Начальные технические окна: каждая ступень не менее 30 минут и 1 000 успешных candidate-запросов для RISK/PRODUCT/FEED/OCR; для RAG - 200 ответов. Если трафика мало, продвижение ждёт данных; синтетический replay не считается production traffic. RAG дополнительно требует 25 проверенных человеком ответов canary без критических нарушений. Эти настройки проходят отдельное утверждение для банковского запуска.

Автоматическое продвижение после предварительного ручного approval допустимо только внутри подписанной политики и её срока. Ошибка схемы, доступа, несовместимость признаков, использование отозванного источника или превышение error/latency guardrails останавливают canary. Срабатывание критической проверки вызывает немедленный rollback; чистая статистическая флуктуация учитывает минимум наблюдений и сравнимость cohort.

Технический canary риска проверяет эксплуатацию и распределение score. Качество по 12-месячному исходу подтверждается offline mature cohorts и последующим долгим мониторингом; 30 минут не подтверждают снижение дефолтов.

## Политики допуска и откат

`policies/release-policy.json` содержит исходные численные настройки только для DEV_DEMO. В bank-target отсутствие утверждённой политики, её digest или внешнего gate даёт запрет deployment. Порог нельзя ослабить конфигурацией сервисного аккаунта в обход approval.

Скоринг: оценка и интервалы ROC/PR-AUC, калибровка/Brier, критичные сегменты. RecSys: NDCG/MRR, coverage и пригодность. OCR: exact financial fields и ошибки знаков. RAG: recall, faithfulness, refusal и полная валидность ссылок. Hard invariants доступа, удаления и пригодности не компенсируются средним хорошим качеством.

Провал validation отклоняет кандидата, не меняя champion. При регрессии canary controller атомарно возвращает предыдущий совместимый bundle, проверяя веса, feature schema, коллекцию и живой deny. Если безопасного bundle нет, применяется fallback. Откат не меняет кредитное решение, заявки и tombstones KB.
