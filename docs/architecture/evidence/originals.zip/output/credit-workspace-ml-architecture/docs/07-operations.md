# 7. Эксплуатация, отчётность и ёмкость

## Профили развёртывания

MVP-NVIDIA: Linux, фиксированные OCI images, Compose с профилями core, ml-control и batch. Java/backend, PostgreSQL, Redis feature store, Qdrant, S3-compatible storage, FastAPI и vLLM имеют те же границы, что целевой контур. MLflow, Airflow и отчёты доступны отдельным профилем; offline jobs могут запускаться последовательно, не меняя форматов manifests. Часть сервисов может работать на CPU. Это стенд разработки, не HA production.

Bank-target: Kubernetes банка, отдельные CPU/GPU pools, platform-managed PostgreSQL/Kafka/Redis/S3, service identity, network policies, controlled egress, внутренний registry и проверенные резервные копии. GPU training/evaluation и GPU online serving размещаются в разных пулах; если физически доступна одна GPU, training выполняется только в отдельном окне без обещания непрерывного production serving.

Конкретные веса LLM/embedding/reranker не фиксируются. Поставка до runtime включает approved model references, licences, hashes, CUDA/driver compatibility и максимальные token budgets. Во время работы скачивание весов и пакетов из интернета запрещено. RTX 2060 рассматривается только как возможный стенд; объём VRAM, precision и поддерживаемые kernels проверяются отдельно. 32 GB системной RAM не заменяют VRAM.

## Проектные SLI и бюджеты

| Функция | Deadline | Начальная цель / поведение |
| --- | --- | --- |
| Risk API, включая чтение snapshot | 1 с | p95 <=500 мс; timeout -> manual/совместимый fallback |
| PRODUCT/FEED ranking | 150 мс | p95 <=100 мс; без сетевого retry, правила |
| KB retrieval | 1 с | p95 <=300 мс; нет источников -> отказ |
| Reranker внутри RAG | 300 мс | Проверенный режим без rerank при отказе |
| Полный RAG ответ | 20 с | p95 <=10 с после выбора модели; SEARCH_ONLY при vLLM fail |
| OCR | Асинхронное задание | Начальный job deadline 120 с; renew lease, ограничение страниц |
| Свежесть новых KB | 24 ч до старта сборки | Затем build/approval lag измеряется отдельно |
| Применение отзыва KB | Приоритетно, цель <=5 с | ENFORCED только после fencing; при задержке fail-closed |

Это гипотезы для тестов. Начальная availability risk endpoint - 99.9% успешных допустимых inference; availability основного кабинета остаётся прежней целью 99.95% при работе fallback. Отдельно считается доля полезных автоматических прогнозов: manual response не маскирует падение модели. Для RAG и ranking дополнительно показываются fallback rate, отказ и wait time. Длительное ожидание approval не прячется в метрике свежести.

Внешние SLO кабинета 300/500 мс и 2 секунды не распространяются молча на генерацию. Скоринг вызывается банковским асинхронным процессом, а не блокирует подтверждение submit. Чат имеет отдельный upstream timeout и endpoint pool. OCR и индексация не держат клиентские HTTP-соединения.

## Панели и отчёты

| Панель | Метрики | Ответственность |
| --- | --- | --- |
| Online health | RPS, p50/p95/p99, 5xx/429, deadlines, in-flight, fallback | SRE + ML serving |
| Data health | schema failures, nulls, availableAt lag, materialization age, parity | Data owner |
| Risk quality | ROC/PR-AUC, Brier, cohort maturity, calibration, score drift, manual rate | Risk owner + validator |
| RecSys/OCR | NDCG, exposure coverage, action rates, financial field exact match | Product/document owner |
| RAG | retrieval recall, no-answer, faithfulness, citations, revoked-source violations | Content + ML owner |
| Releases | active bundle, approvals, canary cohort, rollback, DAG/update age | ML platform |
| Capacity | CPU/RAM/IOPS, GPU VRAM/utilization, KV pressure, queue age | Platform |

Evidently reports хранятся в governed S3 с reference/current manifests; RAGAS - с judge/evaluation versions. Prometheus получает агрегаты через exporter и scrape endpoints. Grafana показывает временные ряды и ссылки на отчёты. Идентификаторы пользователей, компаний, заявок, произвольные тексты и documentId не используются как labels. Для расследований - защищённые inference records и correlationId в traces.

Каталог имён, типов и bounded labels находится в observability/metrics-catalog.json; observability/dashboard-specs.json содержит шесть проектов панелей, PromQL и пять реакций на алерты. Это спецификация instrumentation, а не импортированный dashboard; выражения требуют проверки на реальном Prometheus. Отдельный DCGM exporter подключается только после проверки совместимости конкретной NVIDIA GPU.

Ежедневный технический отчёт: доступность, latency, fallback, свежесть, очередь и инциденты. Еженедельный ML-отчёт: RecSys/OCR/RAG качество и ограничения выборки. Месячный риск-отчёт: только созревшие cohorts, изменения score/калибровки и selection bias. Каждый отчёт указывает период, выборку, версии и владельца; отсутствие меток отображается как NOT_AVAILABLE, а не нулевое качество.

## Сигналы и реакции

Начальные алерты: 5xx >1% в 5-минутном окне при >=100 запросах; превышение p95 budget два окна подряд; fallback >10% за 15 минут при >=100 запросах; oldest job >5 минут; отсутствие свежего monitor report >2 ожидаемых интервалов. Недостаток наблюдений не подавляет абсолютные инварианты безопасности и schema corruption.

Drift: PSI >0.2 по ключевому признаку в двух суточных окнах при >=1 000 наблюдений создаёт диагностику. PSI - эвристика, не универсальная граница; reference bins и сезонное окно фиксируются. Проверка качества выполняется только при наличии созревших/проверенных labels. Распределение нарушений по сегментам и доля пропусков могут создать DATA_INCIDENT раньше drift report.

Alertmanager отправляет уведомления назначенным ролям; автоматический webhook дополнительно сохраняет идемпотентный сигнал в control store. Ручная отправка сообщений людям не является действием данного архитектурного пакета. При потере мониторинга срабатывает независимый heartbeat alert, а не молчаливое «всё зелёное».

## Масштабирование сверх реплик

Для CPU API сначала устраняются повторные вычисления, fan-out и широкие запросы; используются batch inference, предвычисленные feature snapshots, bounded connection pools и вертикальный рост RAM/CPU. Для OCR и embeddings - batch по профилю страниц/длины, ограничение concurrency, отдельные очереди и приоритет онлайн-пути.

Для vLLM применяются continuous batching, ограничения max sequence/context/output, KV-cache capacity, контролируемая квантизация после проверки качества и prefix reuse только внутри разрешённого контекста. Если веса и KV cache помещаются на одной GPU, распределённый inference не добавляется автоматически. При необходимости - tensor parallel внутри узла, затем pipeline parallel при подходящей сети/модели; межузловые расходы измеряются.

Qdrant масштабируется индексами payload, уменьшением нерелевантных кандидатов, shard partitioning и capacity RAM/диска; перестройка индекса не конкурирует бесконтрольно с search. Offline Parquet partitioning выполняется по дате/семейству, а не по бесконечному числу companyId каталогов. PostgreSQL tuning и archive предшествуют произвольному шардированию.

HPA API использует in-flight/CPU, workers - oldest age и drain time, vLLM - waiting requests/token load/VRAM в пределах доступных GPU. Exporter -> Prometheus -> metrics adapter -> один autoscaler на workload. При потере метрик не уменьшать ниже last-safe minimum. Автоскейлер не создаёт физические GPU без подтверждённого резерва.

Ёмкость: slots >=ceil(arrivalRate * serviceTime / targetUtilization). Для GPU измерять token throughput отдельно для prefill/decode и реальных длин контекста; requests/second без длины запроса недостаточно. Backlog=max(0, arrival-completion)*burstDuration; drain=backlog/(capacity-normalArrival). Резерв на canary, rebuild и отказ узла учитывается отдельно.

Прежние гипотезы 1k/5k RPS всего кабинета не являются RPS RAG. Нагрузочный план отдельно задаёт долю чата, risk submissions, ranking cache misses, OCR pages и индексируемые документы. До измерений VRAM/throughput итоговая численность GPU остаётся внешним capacity gate.

## Fallback и runbooks

Risk timeout: открыть circuit breaker, проверить snapshot/version и наличие предыдущего совместимого релиза. При исправных входах допускается ровно одна попытка утверждённого fallback в оставшемся 1-секундном бюджете; если времени нет или данные неверны - manual path. Повторы не создают второй inference outcome. Автоматический отказ или score=0 запрещены.

Ranking fail: немедленно вернуть правила, сохранить mode=RULES и причину. OCR fail: сохранить CLEAN-файл, показать ручной ввод, повторять только техническую работу с generation. vLLM fail: проверенный поиск без генерации; KB authority fail: безопасная недоступность. Накопление batch-очереди: ограничить вход, отложить training/evaluation и rebuild, сохранить приоритет удаления.

Model incident: отключить candidate, сверить routingRevision и bundleDigest всех serving nodes, вернуть совместимый champion, сохранить доказательства. Не откатывать пользовательские данные или банковские решения. Data incident: остановить новый materialization/retrain, изолировать batch, найти затронутые snapshots и дела через lineage, передать risk owner на сверку.

## HA, DR и защита

Bank-target наследует три реальных домена отказа и целевые RPO<=5 минут/RTO<=30 минут как проектные цели. Backup включает данные, registry/manifests, approved images/weights, Qdrant snapshots и control/audit. Redis feature cache восстанавливается из авторитетных snapshots. Результаты удалений и tombstones имеют отдельный журнал восстановления; при сомнении в полноте отзыва RAG не открывается.

Потеря площадки требует сверки внешних банковских команд и восстановленных inference records; отсутствующий локальный score не даёт права повторно принять кредитное решение. Для KB сначала восстанавливаются authority/deny, затем индексы и доступ к истории. Откат backup не снимает revoke. Восстановление не считается успешным по одному факту запуска контейнеров.

Реальные данные требуют утверждения оснований, retention, изоляции, защиты хранения и копий. Предыдущее упрощение криптографического слоя не является разрешением использовать незащищённые ПДн в production. Раздельные сервисные роли, mTLS, allowlist egress и отсутствие payload в logs обязательны для целевого контура. Начальный DEV retention: чат 7 дней, технические traces 7 дней, отчёты 30 дней; банковские сроки и legal hold задаются отдельной утверждённой политикой, release блокируется без неё.
