# 9. План реализации

Порядок задают зависимости, а не календарные обещания. Роли обозначают ответственность, не численность команды. При оценке сроков отдельно учитывать ожидание банковских данных, GPU, согласований и созревания labels. Архитектурная поставка описывает будущие M01-M30; они не считаются выполненными созданием документа.

## Контрольные точки

MVP готов после M25: открытый proxy, синтетические клиенты/продукты, ручные подтверждения, RAG, мониторинг, автоматические кандидаты и ручной выпуск. Банковский запуск после M30 и всех G01-G08. Обучаемые rankers и OCR/RAG tuning не включаются без достаточной проверенной разметки.

## Этап 1. Контракты и основания

### M01. Зафиксировать владельцев, цели и допуск

Ответственный: Архитектор + risk/product/content owners. Зависимости: нет.

Результат и критерий завершения: Принятые границы, score semantics и реестр внешних gates.

Приёмка: C07, C50.

### M02. Согласовать финансовый словарь и источники

Ответственный: Data engineer + бухгалтерский аналитик. Зависимости: M01.

Результат и критерий завершения: Восемь полей, стандарты, периоды, подтверждения и product requirements.

Приёмка: C05, C06.

### M03. Принять контракты и миграцию

Ответственный: Backend + frontend + ML lead. Зависимости: M02.

Результат и критерий завершения: Единый OpenAPI 1.3-design, internal v2 и стратегия event v2.

Приёмка: C46, C47.

### M04. Закрепить Linux/NVIDIA supply chain

Ответственный: ML platform + безопасность. Зависимости: M01.

Результат и критерий завершения: Images/locks/licences/SBOM, проверенный GPU matrix без выбора LLM в архитектуре.

Приёмка: C42, C50.

## Этап 2. Данные и воспроизводимый baseline

### M05. Реализовать финансовую анкету и RFI

Ответственный: Backend + frontend. Зависимости: M03.

Результат и критерий завершения: Draft/confirm/snapshot, CAS и server provenance.

Приёмка: C03, C06, C45.

### M06. Создать governed dataset storage

Ответственный: Data engineer. Зависимости: M03, M04.

Результат и критерий завершения: Снимки, hashes, owner/access/retention и dataset manifests.

Приёмка: C01, C02, C43.

### M07. Реализовать общие transforms и Feast

Ответственный: ML engineer + data engineer. Зависимости: M05, M06.

Результат и критерий завершения: Feature code, point-in-time availability, immutable snapshots, online materialization.

Приёмка: C02, C03, C04, C05.

### M08. Загрузить и проверить публичный baseline

Ответственный: ML engineer. Зависимости: M06.

Результат и критерий завершения: UCI 5year attribution, DQ/dedup, saved grouped 60/20/20 split.

Приёмка: C09, C01.

### M09. Сравнить и зарегистрировать risk кандидатов

Ответственный: ML engineer + validator. Зависимости: M07, M08, M10.

Результат и критерий завершения: Logistic/CatBoost, calibration/report/model card без обещания PD.

Приёмка: C01, C07.

### M10. Подключить MLflow manifests и registry

Ответственный: ML platform. Зависимости: M06.

Результат и критерий завершения: Runs, model versions, aliases, immutable artifact references.

Приёмка: C01, C38.

## Этап 3. Инференс и обязательные fallbacks

### M11. Реализовать Risk API и manual path

Ответственный: ML serving + bank adapter. Зависимости: M09, M10.

Результат и критерий завершения: Версионный inference, идемпотентность, audit и fallback.

Приёмка: C11, C12, C39.

### M12. Добавить три продукта и eligibility

Ответственный: Product + backend. Зависимости: M03.

Результат и критерий завершения: Синтетический каталог, версии и пригодные candidates.

Приёмка: C13, C16.

### M13. Реализовать ranking rules и интерфейс

Ответственный: ML engineer + backend. Зависимости: M12.

Результат и критерий завершения: PRODUCT/FEED permutation validation, pinned next action.

Приёмка: C13, C14, C16.

### M14. Собирать exposures и действия

Ответственный: Frontend + backend + data engineer. Зависимости: M13.

Результат и критерий завершения: Видимые показы, dedup feedback и серверная атрибуция.

Приёмка: C15, C17.

### M15. Подключить OCR финансовой формы

Ответственный: Document backend + ML engineer. Зависимости: M05, M04.

Результат и критерий завершения: CLEAN-only jobs, generation, нормализация и ручное подтверждение.

Приёмка: C18, C19, C20.

## Этап 4. Помощник и жизненный цикл знаний

### M16. Создать KB authority и content workflow

Ответственный: Backend + content owner. Зависимости: M03, M06.

Результат и критерий завершения: Published versions, audience, approval, deny epoch и журнал восстановления.

Приёмка: C23, C27, C44.

### M17. Реализовать ingestion и Qdrant candidates

Ответственный: ML/data engineer. Зависимости: M16.

Результат и критерий завершения: Parser/chunker, dense+sparse index, cutoff/dedup/single-build.

Приёмка: C24, C25.

### M18. Подключить vLLM и RAG API

Ответственный: ML serving. Зависимости: M17, M04.

Результат и критерий завершения: Configured local generator, один bundle на запрос, проверяемые sources.

Приёмка: C21, C22, C25, C29, C42.

### M19. Реализовать отзыв с publication fence

Ответственный: Backend + SRE. Зависимости: M16, M18.

Результат и критерий завершения: Immediate deny, cancellation/drain, ENFORCED, purge и защищённая history.

Приёмка: C26, C27, C28, C29.

### M20. Добавить виджет и QA-набор RAG

Ответственный: Frontend + content owner + validator. Зависимости: M18, M19.

Результат и критерий завершения: Чат, feedback, 100 golden + 50 attacks, версионированный judge.

Приёмка: C21, C23, C30, C45.

## Этап 5. Мониторинг и управляемые обновления

### M21. Создать UpdateRequest и batch DAGs

Ответственный: ML platform. Зависимости: M07, M10, M17.

Результат и критерий завершения: Durable signals, leases/generations, retry/cooldown, manifests.

Приёмка: C10, C24, C31, C32.

### M22. Настроить мониторинг и отчёты

Ответственный: SRE + ML/data engineer. Зависимости: M11, M14, M15, M20.

Результат и критерий завершения: Prometheus/Grafana, Evidently/RAGAS, reports и heartbeat.

Приёмка: C30, C32, C43.

### M23. Реализовать approvals и release controller

Ответственный: ML platform + IAM. Зависимости: M21, M22.

Результат и критерий завершения: Независимые reviewer/owner, digest binding, signed policy.

Приёмка: C33, C34, C37, C50.

### M24. Реализовать shadow/canary/rollback

Ответственный: ML serving + SRE. Зависимости: M23.

Результат и критерий завершения: Sticky routing, 5/25/100, статистические guards и совместимый rollback.

Приёмка: C12, C25, C27, C35, C36, C38.

## Этап 6. Приёмка MVP

### M25. Принять MVP end-to-end

Ответственный: QA + владельцы. Зависимости: M11, M13, M15, M20, M24.

Результат и критерий завершения: Синтетический кейс от анкеты до ответа/обновления/отката; отчёт о пределах.

Приёмка: C07, C11, C19, C29, C37, C45.

## Этап 7. Банковский контур

### M26. Подключить банковские данные и labels

Ответственный: Data owner + risk owner. Зависимости: M25.

Результат и критерий завершения: Утверждённый target, availability, maturity, OOT/entity validation.

Приёмка: C02, C08, C10, C50.

### M27. Обучить банковский риск и обучаемые rankers

Ответственный: ML engineer + независимый validator. Зависимости: M26, M14.

Результат и критерий завершения: PD на допустимых данных; PRODUCT/FEED только при достаточно меток.

Приёмка: C07, C08, C17, C33.

### M28. Подключить проверенную OCR/RAG разметку

Ответственный: Document/content owner + ML. Зависимости: M25.

Результат и критерий завершения: Verified labels/pairs и кандидаты OCR/embedding/reranker при data gate.

Приёмка: C20, C30, C34.

### M29. Выполнить capacity/security/chaos

Ответственный: SRE + безопасность + QA. Зависимости: M25, M04.

Результат и критерий завершения: Измеренные SLO, GPU budgets, admission, изоляция и runbooks.

Приёмка: C40, C41, C42, C43.

### M30. Провести HA/DR и банковский допуск

Ответственный: SRE + risk/security/product owners. Зависимости: M26, M27, M28, M29.

Результат и критерий завершения: Проверенное восстановление и утверждённые production gates.

Приёмка: C44, C50.
