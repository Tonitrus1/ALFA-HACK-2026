# 8. Контракты и интеграция с существующим проектом

## Статус контрактов

`api/public-extensions.openapi.json` и `api/internal.openapi.json` - проекты OpenAPI 3.1. Они не являются запущенным API и не изменяют исходный единый 1.2.0-design. Клиентские дополнения получают версию 1.3.0-design после интеграции; новая внутренняя оценка риска имеет путь /internal/v2. Старые пути сохраняются до явной миграции потребителей.

Проект содержит строгие JSON Schema для входов, выходов, событий, dataset/experiment/release manifests. Межполевые и ролевые инварианты описаны отдельно и проверяются semantic fixtures: одной JSON Schema недостаточно для проверки чужого документа или правильной формулы коэффициента.

Для ревью интеграции подготовлены api/integration-preview.openapi.json (60 публичных операций) и RFC 6902 baseline-integration.patch.json. Новые схемы получают префикс ML, сохраняя старые определения. Patch добавляет финансовые версии в Submit/InformationResponse и расширяет allowlist RFI; динамическая обязательность финансов определяется versioned product requirements. Он не применён к исходным пакетам.

Объединённый проект переводит описание с OpenAPI 3.0.3 на 3.1.0, необходимую новым JSON Schema. Это не смена URL прежних операций. M03 проверяет поддержку 3.1 генераторами Java/TypeScript и схемами клиента; исходная спецификация 3.0.3 остаётся нетронутой.

## Публичные дополнения

| Граница | Операции | Правила |
| --- | --- | --- |
| Финансовая анкета | GET/PUT /api/v1/applications/{applicationId}/financial-statement; POST .../confirm | Только DRAFT, If-Match, Idempotency-Key; provenance формирует сервер |
| Финансы RFI | GET/PUT /api/v1/applications/{applicationId}/information-requests/{requestId}/draft/financial-statement; POST .../confirm | Только запрошенные поля OPEN RFI, отдельный draftVersion |
| Помощник | POST /api/v1/assistant/messages; GET /api/v1/assistant/conversations/{conversationId} | Session/CSRF/company context; источники и статусы без score |
| Обратная связь | POST /api/v1/recommendation-feedback | clientEventId, exposureId/itemId; только VIEW/CLICK клиента |
| Пояснение RAG | POST /api/v1/assistant/feedback | messageId и полезность; не является эталонной разметкой |
| Источник KB | GET /api/v1/knowledge/{documentId}/versions/{documentVersion} | Проверка публикации, срока и deny; без произвольного S3 URL |

Ответ сохранения содержит statementVersion и ETag целевого черновика. Финансовое изменение увеличивает Application.version или InformationDraft.draftVersion и сбрасывает прежнее подтверждение; собственная statementVersion не заменяет optimistic locking контейнера. Confirm проверяет сохранённую statementVersion и точные documentReferences. Смена значения после подтверждения требует нового подтверждения.

Финансовый RFI draft инициализируется копией прежней отчётности. Полный PUT сравнивается с сохранённым состоянием: незапрошенные поля должны оставаться неизменными. Клиент не получает право изменять все восемь полей только потому, что подтверждает итоговую финансовую форму.

Текущий /recommendations сохраняется для диагностического подбора. После объединения его ответ дополняется ranking metadata, exposureId и eligibilityVersion, с сохранением допустимого legacy UI. Если требуется обязательный новый вход, создаётся отдельная версия, а не скрытая смена смысла старого метода. Feed получает те же exposure-связи; публичный ответ не раскрывает технические risk reason codes.

Submit и InformationResponse остаются источниками истины при отправке. Новая версия этих схем закрепляет financialStatementVersion и серверный financialSnapshotId; snapshotId создаётся из подтверждённой версии при submit, клиент не может подставить чужой снимок. Проверка обязательности зависит от versioned product requirements. Это изменение существующих строгих схем обязательно перечислено в integration-matrix.json, а не объявлено готовым сервером.

## Внутренние интерфейсы

| Операция | Вызывающая роль | Результат |
| --- | --- | --- |
| POST /internal/v2/feature-snapshots | bank-adapter / feature-builder | Immutable snapshot для конкретной отправки |
| POST /internal/v2/risk/evaluations | bank-adapter | scoreKind, score, calibrationStatus, inferenceId, bundle/snapshot digest |
| POST /internal/v2/rankings | workspace/catalog | Перестановка кандидатов, exposureId, MODEL/RULES |
| POST /internal/v1/kb/documents/{documentId}/publish | content-owner | Публикация утверждённой версии и UpdateRequest |
| POST /internal/v1/kb/documents/{documentId}/revoke | content-owner / security | 202 receipt, revocationId; отдельно проверяется ENFORCED |
| GET /internal/v1/kb/revocations/{revocationId} | content-owner / security | Enforcement и purge state отдельно |
| POST /internal/v1/ml/update-requests | monitor/controller | Долговечный запрос с dedup key |
| GET /internal/v1/ml/update-requests/{updateRequestId} | ml-operator | Состояние, lease generation, ссылка на отчёт |
| POST /internal/v1/ml/releases/{releaseId}/approvals | validator/owner | Решение только по совпадающим digests |
| POST /internal/v1/ml/releases/{releaseId}/rollouts | deployment-controller | Shadow/canary в рамках допуска |
| POST /internal/v1/ml/releases/{releaseId}/rollback | deployment-controller / oncall | CAS переключение на совместимый bundle |

Airflow получает и продлевает lease через /internal/v1/ml/update-requests/{updateRequestId}/claim и /lease/renew, публикует результат через /result. Эти маршруты доступны training-controller и сверяют worker identity, token и generation. GET /internal/v1/ml/operations/{operationId} возвращает состояние служебной операции; он не заменяет отдельный статус ENFORCED отзыва KB.

mTLS identity и IAM-роли проверяются сервером. Approval не разрешён deployment-controller и автору кандидата. Monitor не может публиковать документы, менять численные gate thresholds или переключать трафик. KB publisher не может менять базовые model weights.

RiskResult существует только при пригодном прогнозе: нет score=null/0 для ошибки. 422 обозначает непригодный снимок, 409 - несовместимость версий, 503 - техническую недоступность с machine-readable fallbackAction=MANUAL_REVIEW. Банк решает, какой процесс рассмотрения запустить; ошибка модели не отображается как отказ клиенту.

## Общие правила HTTP

Все публичные маршруты используют Secure/HttpOnly session cookie, X-Company-Context и для изменений X-CSRF-Token; контекст сравнивается с session.contextVersion до эффекта. Персональные ответы и ошибки имеют Cache-Control: no-store. PUT/confirm/feedback/assistant POST используют Idempotency-Key. Повтор того же ключа в своём scope возвращает прежний результат; изменённое тело даёт 409. Assistant retry не запускает вторую генерацию; повтор до завершения возвращает 409 REQUEST_IN_PROGRESS с Retry-After.

GET истории снова проверяет доступ и deny-реестр, а не возвращает сохранённый текст без фильтра. ConversationId не является полномочием. 404 скрывает чужой ресурс. Доступ проверяется и при работе со ссылкой на источник; браузер не получает произвольный S3 URL. Серверные локаторы источников используют allowlist маршрута KB.

Ошибки имеют code, message, correlationId и fallbackAction при наличии; без payload финансов/документа. 429/503 имеют Retry-After, 504 - превышение общего срока. Обязательные версии и деньги ограничены безопасным JSON integer; даты ISO 8601 UTC. Денежные поля не проходят через float; feature ratios передаются как конечные number.

## События и совместимость

Новое семейство credit.ml-control.v1: MLUpdateRequested, MLReleaseValidated, MLReleaseApprovalRecorded, MLReleaseActivated, MLRollbackCompleted. KB-семейство credit.kb.v1: KBDocumentPublished, KBDocumentRevoked. RecSys: credit.recommendations.v1 с RecommendationExposureRecorded/RecommendationFeedbackRecorded. События несут только IDs, версии, digests и безопасные служебные категории, без текстов беседы и финансовых значений.

Envelope: eventId, eventType, schemaVersion=1, aggregateId, aggregateVersion, occurredAt, correlationId и payload. Партиционирование: releaseId/updateRequestId для ML, corpusId для KB, exposureId для рекомендаций. Изменения конкретного aggregate сериализуются; разные aggregateVersion не сравниваются. Потребители используют inbox; пропуск версии вызывает сверку с авторитетным API.

Существующие события заявок/документов имеют additionalProperties=false. Добавление финансовых ссылок в их payload требует v2 schema/topic, параллельного consumer и измеренного периода миграции. Нельзя добавить поле и объявить старый wire формат совместимым. Транспорт MVP может быть PostgreSQL outbox; bank-target Kafka использует тот же envelope.

## Порядок объединения пакетов

Сначала принять словарь финансов и проектные контракты, затем синхронно обновить единый OpenAPI и frontend schemas. Добавить новые поля и таблицы миграцией expand, backfill только для подтверждённых данных; прежние заявки остаются без публичного baseline и идут по прежнему/ручному пути. Отсутствующие значения не заполняются фиктивной отчётностью.

После тестов включать flags последовательно: финансовая анкета новых синтетических заявок, PRODUCT ranking, RAG. Risk consumer остаётся в shadow до допуска. Старые event consumers удаляются после нулевого lag и истечения retention. Отключение flags сохраняет историю, approvals и tombstones. Владельцы, изменения и приёмка перечислены в integration-matrix.json.
