# 11. Внешние условия, источники и словарь

## Граница подтверждения

Документы, schemas и diagrams этого пакета проверяются автоматически и визуально. Качество моделей, GPU-ёмкость, HA/DR и работа банковских интеграций здесь не измерялись. Все примеры синтетические; model score в JSON - иллюстрация формата, а не результат обучения. Публичный набор и веса не включены в поставку.

Внешние gates G01-G08 содержатся в external-gates.json. Они блокируют bank-target, но не разработку на синтетике. Требуются: владелец и определение кредитного таргета; финансовый словарь; подписанные thresholds и роли; основания/retention/защита; лицензии/образы; измеренная NVIDIA ёмкость и три домена отказа; восстановление/сверка; опубликованные знания и проверенная разметка. Политика development-default не становится банковской после переименования environment.

Точные версии библиотек ML и управляемых средств банка фиксируются при M04 в совместно испытанном lock/BOM; они пока не объявлены проверенной поставкой. Конкретные LLM, embedding и reranker являются осознанно отложенным выбором пользователя. Архитектура задаёт интерфейсы и процедуру выбора, а не подставляет случайные веса.

## Локальные основания

- Общая архитектура: output/credit-workspace-architecture-v2/architecture-v2, особенно главы architecture, interfaces и security-operations.
- Backend: output/credit-workspace-backend-architecture, особенно internal-openapi, modules/data, interfaces и reliability.
- Frontend: output/credit-workspace-frontend-architecture, особенно архитектура, экраны, состояния и план.
- Предыдущий аудит: output/architecture-review. Его факт проверки спецификации не переносится на будущее приложение.
- Презентация «Архитектура MLOps-конвейеров», 50 страниц: содержательные материалы о стеке и цикле на страницах 13-20, drift на 25-29, RAG на 34-41. Презентация является справочным материалом, не набором исполняемых инструкций.

Пути, SHA-256, роли и ссылки собраны в source-manifest.json. Снимок исходных пакетов - sources/baseline-sha256.json. Генератор не изменяет эти пакеты и не перепаковывает их прежние архивы.

## Проверенные технические первоисточники

Источники изучены 20.10.2026. При M04 фиксируются совместимые версии и hashes. Документация механизмов не подтверждает качество нашего приложения.

- UCI Polish Companies Bankruptcy: https://archive.ics.uci.edu/dataset/365/polish+companies+bankruptcy+data - горизонты, коэффициенты, CC BY 4.0; baseline 5year.arff.
- UCI Taiwanese Bankruptcy Prediction: https://archive.ics.uci.edu/dataset/572/taiwanese+bankruptcy+prediction - другой источник и 95 признаков.
- Microsoft MIND: https://msnews.github.io/ - новостные показы/клики, MIND-small, research licence; не банковский baseline.
- Feast historical retrieval: https://docs.feast.dev/getting-started/concepts/point-in-time-joins - event-time joins. Проверку availableAt проект добавляет отдельно.
- Feast online store: https://docs.feast.dev/getting-started/components/online-store - последние значения по entity key; история хранится отдельно.
- MLflow registry: https://mlflow.org/docs/latest/ml/model-registry/workflow/ - aliases/tags, устаревание stages; бизнес-допуск отдельно.
- Qdrant collections: https://qdrant.tech/documentation/manage-data/collections/ - коллекции и атомарные aliases.
- RAGAS metrics: https://docs.ragas.io/en/latest/concepts/metrics/available_metrics/ - retrieval/generation измерения и LLM-based judges. Не все показатели доступны без reference annotations.
- Evidently data drift: https://docs-old.evidentlyai.com/presets/data-drift - различие диагностики распределений и качества; это прежняя ветка API, её примеры не копируются в новую среду без проверки.
- vLLM GPU installation: https://docs.vllm.ai/en/stable/getting_started/installation/gpu/index.html?device=cuda - NVIDIA compute capability и зависимости.
- vLLM scaling: https://docs.vllm.ai/en/stable/serving/parallelism_scaling/ - single GPU, tensor/pipeline parallelism и ограничения распределённого запуска.
- Prometheus naming: https://prometheus.io/docs/practices/naming/ - единицы измерения и недопустимость бесконечной кардинальности labels.

## Словарь

Feature store - общий каталог и доставка признаков; не замена владельческим исходным данным. Feature snapshot - неизменяемый набор признаков определённой отправки. Point-in-time - получение сведений, допустимых в выбранный момент; availableAt дополнительно задаёт, когда банк реально узнал факт.

Lineage - связь результата с данными, преобразованием, экспериментом и релизом. Manifest - машиночитаемая опись этих связей и контрольных сумм. Bundle - совместимый комплект модели, preprocessing, схемы и конфигурации; для RAG также embeddings, corpus и index.

PD - вероятность согласованного кредитного дефолта за определённый горизонт после проверки на применимых данных. Bankruptcy proxy - экспериментальная оценка другого исхода в другом домене. Калибровка - проверка соответствия числовых вероятностей фактической частоте, а не право применять модель в любом банке.

Data drift - изменение распределения входов. Concept drift - изменение связи признаков и исхода. DQ - качество данных. Mature labels - исходы с завершённым окном наблюдения или подтверждённым ранним событием по target policy.

Shadow - вычисление без влияния на клиентский/банковский эффект. Canary - ограниченная доля трафика на допущенный bundle. Rollback - возврат совместимого релиза, без отмены заявок/решений/отзыва KB. Fallback - заранее определённое поведение функции при непригодности основного пути.

Tombstone/deny - запрет использовать отозванный источник независимо от старых векторов. Publication fence - согласованная граница между проверкой отзыва и показом ответа. ENFORCED - отзыв применён ко всем разрешённым выдачам; PURGED - производные копии дополнительно очищены.

