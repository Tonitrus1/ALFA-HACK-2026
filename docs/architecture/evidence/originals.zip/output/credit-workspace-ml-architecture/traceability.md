# Связь требований с реализацией и приёмкой

| Требование | Задачи | Проверки | Документ / схема |
| --- | --- | --- | --- |
| R01: Консистентность и воспроизводимость | M06, M07, M08, M09, M10 | C01, C02, C03, C04, C09 | docs/03-data-risk.md / 02-data |
| R02: Понятные fallbacks | M11, M13, M15, M18, M19 | C11, C16, C19, C29, C39 | docs/07-operations.md / 03-risk |
| R03: Мониторинг и отчётность | M22 | C30, C32, C43 | docs/07-operations.md / 06-release |
| R04: Автообновление и ручная валидация | M21, M23 | C10, C31, C33, C34, C37 | docs/06-lifecycle.md / 06-release |
| R05: Canary, отклонение и rollback | M24 | C25, C27, C35, C36 | docs/06-lifecycle.md / 06-release |
| R06: RAG только клиентские знания и vLLM | M16, M17, M18, M20 | C21, C22, C23, C30 | docs/05-rag.md / 05-rag |
| R07: Обновление RAG по N/метрикам/удалению | M19, M21, M28 | C24, C26, C27, C28, C30 | docs/05-rag.md / 05-rag |
| R08: Масштабирование сверх реплик | M04, M29 | C40, C41, C42 | docs/07-operations.md / 07-deployment |
| R09: Свой скоринг, решение банка | M01, M09, M11, M26, M27 | C07, C08, C11, C12 | docs/03-data-risk.md / 03-risk |
| R10: Финансовая анкета под открытый baseline | M02, M05, M08 | C05, C06, C09 | docs/03-data-risk.md / 03-risk |
| R11: Рекомендации ленты и продуктов | M12, M13, M14, M27 | C13, C14, C15, C16, C17 | docs/04-recsys-ocr.md / 04-recsys-ocr |
| R12: OCR с подтверждением и data gate | M15, M28 | C18, C19, C20 | docs/04-recsys-ocr.md / 04-recsys-ocr |
| R13: Два этапа Linux/NVIDIA | M04, M25, M29, M30 | C38, C40, C42, C50 | docs/07-operations.md / 07-deployment |
| R14: Отдельный пакет и интеграция без порчи исходников | M03 | C46, C47, C48, C49 | docs/08-interfaces.md / 01-context |
| R15: Права, контекст, удаление и восстановление | M16, M19, M30 | C23, C26, C27, C28, C43, C44, C45 | docs/05-rag.md / 05-rag |
