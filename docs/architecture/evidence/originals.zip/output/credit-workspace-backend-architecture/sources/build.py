"""Rebuild the architecture artifacts; does not implement the banking application."""
from pathlib import Path
import sys, json, re, html, hashlib, zipfile, shutil, copy, xml.etree.ElementTree as ET
import os
extra=os.environ.get('CREDIT_RENDER_DEPS')
if extra:sys.path.insert(0,extra)
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, CondPageBreak, Table, TableStyle, KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4, A3, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader, PdfWriter, Transformation, PageObject
import pypdfium2 as pdfium
from PIL import Image, ImageOps, ImageDraw, ImageFont
from markdown_it import MarkdownIt
from openapi_spec_validator import validate
from jsonschema import Draft202012Validator, FormatChecker
from contracts import write_contracts, STATES
from workplan import write_workplan, TASKS, TESTS, REQUIREMENTS
from diagram_engine import OUT, ROOT, FONT_DIR, render_board
from diagrams import populate

TMP=ROOT/'tmp/backend-pdfs'
ORIGINAL=ROOT/'output/credit-workspace-architecture-v2/architecture-v2'
INPUT=ORIGINAL.parent
INK=colors.HexColor('#182839'); MUTED=colors.HexColor('#586a7b'); BLUE=colors.HexColor('#315b93'); RED=colors.HexColor('#cf524b')
pdfmetrics.registerFont(TTFont('DV-M',str(FONT_DIR/'DejaVuSansMono.ttf')))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-B',italic='DV',boldItalic='DV-B')
styles={
 'body':ParagraphStyle('body',fontName='DV',fontSize=9.3,leading=13.4,spaceAfter=7,textColor=INK,splitLongWords=True),
 'h1':ParagraphStyle('h1',fontName='DV-B',fontSize=20,leading=25,spaceAfter=16,textColor=BLUE,keepWithNext=True),
 'h2':ParagraphStyle('h2',fontName='DV-B',fontSize=13,leading=18,spaceBefore=11,spaceAfter=7,textColor=INK,keepWithNext=True),
 'h3':ParagraphStyle('h3',fontName='DV-B',fontSize=10.5,leading=15,spaceBefore=10,spaceAfter=6,textColor=BLUE,keepWithNext=True),
 'cell':ParagraphStyle('cell',fontName='DV',fontSize=8,leading=11,spaceAfter=0,textColor=INK,splitLongWords=True),
 'thead':ParagraphStyle('thead',fontName='DV-B',fontSize=8,leading=11,textColor=colors.white),
 'small':ParagraphStyle('small',fontName='DV',fontSize=8,leading=11,textColor=MUTED),
 'cover':ParagraphStyle('cover',fontName='DV-B',fontSize=29,leading=36,textColor=INK,spaceAfter=20),
 'subtitle':ParagraphStyle('subtitle',fontName='DV',fontSize=14,leading=21,textColor=MUTED,spaceAfter=18)}

def digest_tree(path):
    return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file() and p.name!='.DS_Store'}

def inline(token):
    result=[]
    for t in token.children or []:
        if t.type=='text':result.append(html.escape(t.content))
        elif t.type=='code_inline':result.append('<font name="DV-M">'+html.escape(t.content)+'</font>')
        elif t.type=='strong_open':result.append('<b>')
        elif t.type=='strong_close':result.append('</b>')
        elif t.type=='em_open':result.append('<i>')
        elif t.type=='em_close':result.append('</i>')
        elif t.type=='link_open':result.append('<a color="#315b93" href="'+html.escape(t.attrGet('href') or '',quote=True)+'">')
        elif t.type=='link_close':result.append('</a>')
        elif t.type in ['softbreak','hardbreak']:result.append('<br/>')
        else:result.append(html.escape(t.content))
    return ''.join(result)

def markdown_flow(text):
    tokens=MarkdownIt('commonmark').enable('table').parse(text)
    result=[];i=0;lists=[];item=False
    while i<len(tokens):
        t=tokens[i]
        if t.type=='heading_open':
            level=int(t.tag[1:]);body=inline(tokens[i+1]);p=Paragraph(body,styles.get('h'+str(level),styles['h3']))
            p.toc_level=0 if level==1 else None;p.toc_title=tokens[i+1].content
            result.append(p);i+=3;continue
        if t.type in ['bullet_list_open','ordered_list_open']:lists.append({'kind':t.type,'counter':0});i+=1;continue
        if t.type in ['bullet_list_close','ordered_list_close']:lists.pop();i+=1;continue
        if t.type=='list_item_open':
            item=True
            if lists:lists[-1]['counter']+=1
            i+=1;continue
        if t.type=='paragraph_open':
            body=inline(tokens[i+1]);style=styles['body']
            if lists:
                style=ParagraphStyle('bullet',parent=style,leftIndent=14*len(lists),firstLineIndent=-10)
                prefix=(str(lists[-1]['counter'])+'. ') if lists[-1]['kind']=='ordered_list_open' else '• '
                body=prefix+body if item else body;item=False
            result.append(Paragraph(body,style));i+=3;continue
        if t.type=='table_open':
            rows=[];row=[];heads=[];j=i+1;ishead=False
            while tokens[j].type!='table_close':
                q=tokens[j]
                if q.type=='thead_open':ishead=True
                if q.type=='thead_close':ishead=False
                if q.type=='tr_open':row=[]
                if q.type in ['th_open','td_open']:row.append(Paragraph(inline(tokens[j+1]),styles['thead'] if ishead else styles['cell']))
                if q.type=='tr_close':rows.append(row)
                j+=1
            count=len(rows[0]);width=A4[0]-88
            ratios={2:[.32,.68],3:[.27,.30,.43],4:[.31,.15,.32,.22]}.get(count,[1/count]*count)
            tbl=Table(rows,colWidths=[width*r for r in ratios],repeatRows=1,hAlign='LEFT')
            tbl.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f1f5fa'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.7,BLUE),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#dbe3eb'))]))
            result+=[tbl,Spacer(1,10)];i=j+1;continue
        if t.type=='fence':result.append(Paragraph(html.escape(t.content).replace('\n','<br/>'),styles['small']))
        i+=1
    grouped=[];i=0
    while i<len(result):
        title=getattr(result[i],'toc_title','')
        if re.match(r'^(T\d{2}\.\d+|V\d{2})\.',title):
            group=[result[i]];i+=1
            while i<len(result) and not hasattr(result[i],'toc_title'):
                group.append(result[i]);i+=1
            grouped.append(KeepTogether(group))
        else:grouped.append(result[i]);i+=1
    finished=[];i=0
    while i<len(grouped):
        if getattr(grouped[i],'toc_title','').startswith('Этап ') and i+1<len(grouped) and isinstance(grouped[i+1],KeepTogether):
            finished.append(KeepTogether([grouped[i]]+grouped[i+1]._content));i+=2
        else:finished.append(grouped[i]);i+=1
    return finished

class Guide(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(str(path),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=49,bottomMargin=43,title='Кредитный кабинет: руководство по разработке серверной части',author='Архитектурный пакет проекта')
        self.addPageTemplates(PageTemplate(id='normal',frames=[Frame(44,43,A4[0]-88,A4[1]-92,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=self.decorate))
        self.heading_counter=0
    def beforeDocument(self):
        self.heading_counter=0
    def decorate(self,canv,doc):
        canv.saveState();canv.setStrokeColor(colors.HexColor('#d9e2ec'));canv.line(44,A4[1]-31,A4[0]-44,A4[1]-31)
        canv.setFont('DV',7);canv.setFillColor(MUTED);canv.drawString(44,A4[1]-23,'КРЕДИТНЫЙ КАБИНЕТ  /  JAVA + SPRING BOOT')
        canv.drawString(44,23,'Архитектура для реализации  •  20.10.2026');canv.drawRightString(A4[0]-44,23,str(doc.page));canv.restoreState()
    def afterFlowable(self,f):
        if getattr(f,'toc_level',None) is not None:
            key='heading-'+str(self.heading_counter);self.heading_counter+=1
            self.canv.bookmarkPage(key);self.notify('TOCEntry',(f.toc_level,html.escape(f.toc_title),self.page,key))

def guide():
    story=[Spacer(1,75),Paragraph('Кредитный<br/>кабинет',styles['cover']),Paragraph('Архитектура серверной части<br/>и план разработки',styles['subtitle']),Spacer(1,18),Paragraph('<b>Java 21 · Spring Boot · PostgreSQL · Kafka</b>',styles['subtitle']),Spacer(1,20),Paragraph('Модульное ядро и отдельные обработчики. От требований и данных - к интерфейсам, задачам и промышленному запуску.',styles['body']),Spacer(1,24),Paragraph(f'{len(TASKS)} задач разработки · {len(TESTS)} сценариев приёмки · 10 схем',styles['h2']),Paragraph('Для команды разработки. 20 октября 2026 года.',styles['small']),Spacer(1,36),Paragraph('Проектное предложение на основе пакета v2. Реальные банковские подключения, ресурсы и допуск требуют подтверждения. Этот документ не подтверждает работоспособность приложения, качество моделей или нормативное соответствие.',styles['small']),PageBreak(),Paragraph('Как пользоваться руководством',styles['h1'])]
    story+=markdown_flow('''Сначала откройте атлас: листы 01-02 объясняют границы и устройство приложения. Листы 03-08 раскрывают данные, сценарии и восстановление. Листы 09-10 связывают эксплуатацию с порядком разработки.

В этом руководстве главы 1-3 задают основу, 4-6 - поведение и ограничения, глава 7 содержит задачи, глава 8 - проверки, глава 9 - решения и первоисточники. Точные машинные поля вынесены в папки api и schemas.

**Первая контрольная точка:** полный кредитный путь с имитатором банка после этапа 6. **Промышленный допуск:** реальные подключения, нагрузка, защита и восстановление после этапа 8.

Термины outbox, inbox, SSE и другие пояснены в словаре. Номера задач нужны для связей и передачи команде; на основных схемах используются понятные названия.
''')
    story +=[Spacer(1,16),Paragraph('Содержание',styles['h2'])]
    toc=TableOfContents();toc.levelStyles=[ParagraphStyle('toc0',fontName='DV-B',fontSize=10,leading=15,spaceBefore=7),ParagraphStyle('toc1',fontName='DV',fontSize=8.5,leading=12,leftIndent=13,spaceBefore=2)]
    story +=[toc]
    for p in sorted((OUT/'docs').glob('[0-9][0-9]-*.md')):
        if p.name.startswith(('01','07','08','09')):story.append(PageBreak())
        else:story += [CondPageBreak(260),Spacer(1,22)]
        story+=markdown_flow(p.read_text())
    Guide(OUT/'backend-development-guide.pdf').multiBuild(story)

def diagrams():
    boards=populate();models=[];writer=PdfWriter();manifest=[]
    for b in boards:
        model=render_board(b);models.append(model)
        raw=PdfReader(str(TMP/f'{b.slug}.pdf')).pages[0]
        w,h=landscape(A3);page=PageObject.create_blank_page(width=w,height=h)
        scale=min(w/b.w,h/b.h)
        page.merge_transformed_page(raw,Transformation().scale(scale).translate((w-b.w*scale)/2,(h-b.h*scale)/2))
        writer.add_page(page)
        manifest.append(dict(id=b.slug,title=b.title,width=b.w,height=b.h,shapes=len(b.shapes),page=len(manifest)+1))
    writer.add_metadata({'/Title':'Кредитный кабинет: атлас серверной архитектуры','/Author':'Архитектурный пакет проекта'})
    with (OUT/'backend-architecture-atlas.pdf').open('wb') as f:writer.write(f)
    mx=ET.Element('mxfile',host='app.diagrams.net',version='24.7.17',compressed='false')
    for b,model in zip(boards,models):ET.SubElement(mx,'diagram',id=b.slug,name=b.title).append(model)
    ET.ElementTree(mx).write(OUT/'backend-architecture.drawio',encoding='utf-8',xml_declaration=True)
    (OUT/'diagram-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    return boards

def previews():
    pdf=pdfium.PdfDocument(str(OUT/'backend-architecture-atlas.pdf'))
    small=[]
    for i,p in enumerate(pdf):
        img=p.render(scale=1600/p.get_width()).to_pil().convert('RGB');slug=json.loads((OUT/'diagram-manifest.json').read_text())[i]['id']
        img.save(OUT/'png'/f'{slug}.png');small.append(img)
    sheet=Image.new('RGB',(1280,5*453),'#e8edf3')
    for i,img in enumerate(small):
        thumb=ImageOps.contain(img,(620,420));sheet.paste(thumb,(10+(i%2)*640,12+(i//2)*453))
    sheet.save(OUT/'preview.png')
    guidepdf=pdfium.PdfDocument(str(OUT/'backend-development-guide.pdf'))
    pagefiles=[]
    for i,p in enumerate(guidepdf):
        img=p.render(scale=1.15).to_pil().convert('RGB');file=TMP/f'guide-{i+1:03d}.png';img.save(file);pagefiles.append(file)
    for start in range(0,len(pagefiles),12):
        sheet=Image.new('RGB',(1800,4*650),'#e5eaf0');draw=ImageDraw.Draw(sheet)
        for local,file in enumerate(pagefiles[start:start+12]):
            img=Image.open(file);thumb=ImageOps.contain(img,(560,610));x=(local%3)*600+20;y=(local//3)*650+20
            sheet.paste(thumb,(x,y));draw.text((x+3,y+610),f'Page {start+local+1}',fill='black')
        sheet.save(TMP/f'guide-contact-{start//12+1}.png')
    return len(guidepdf)

def index():
    manifest=json.loads((OUT/'diagram-manifest.json').read_text())
    cards=''.join(f'<a class="card" href="svg/{m["id"]}.svg"><img src="svg/{m["id"]}.svg" alt="{html.escape(m["title"])}"><strong>{html.escape(m["title"])}</strong></a>' for m in manifest)
    docs=''.join(f'<li><a href="{p.relative_to(OUT)}">{html.escape(p.read_text().splitlines()[0].lstrip("# "))}</a></li>' for p in sorted((OUT/'docs').glob('*.md')))
    markup=f'''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Кредитный кабинет: серверная архитектура</title><style>body{{font:16px/1.6 system-ui,sans-serif;background:#f3f6fa;color:#182839;max-width:1240px;margin:0 auto;padding:40px}}h1{{font-size:42px;line-height:1.15;max-width:900px}}.eyebrow{{color:#b94d42;font-weight:700;letter-spacing:.12em}}.links{{display:flex;gap:14px;flex-wrap:wrap;margin:26px 0}}.links a{{background:#315b93;color:white;padding:12px 18px;border-radius:8px;text-decoration:none}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:22px}}.card{{background:white;border:1px solid #dbe3ed;border-radius:10px;overflow:hidden;text-decoration:none;color:inherit;padding-bottom:16px}}.card img{{width:100%;display:block}}.card strong{{display:block;padding:10px 18px}}section{{margin-top:42px}}a{{color:#315b93}}.note{{padding:18px;background:#fff2e2;border-radius:8px}}@media(max-width:700px){{.grid{{grid-template-columns:1fr}}body{{padding:20px}}h1{{font-size:32px}}}}</style><div class="eyebrow">JAVA + SPRING BOOT / 20.10.2026</div><h1>Серверная архитектура<br>кредитного кабинета</h1><p>10 схем · 40 задач · 29 сценариев приёмки. От модулей и данных до надёжной передачи банку и промышленного запуска.</p><div class="links"><a href="backend-architecture-atlas.pdf">Открыть атлас PDF</a><a href="backend-development-guide.pdf">Руководство PDF</a><a href="backend-architecture.drawio">Редактируемые схемы</a><a href="api/openapi.json">Клиентский API</a></div><p class="note">Проектная архитектура. Реальные банковские интерфейсы требуют согласования. Защита хранилищ, нагрузочные испытания и восстановление - обязательные условия допуска, а не уже выполненные проверки приложения.</p><section><h2>Атлас архитектуры</h2><p>Нажмите на лист для увеличения. Исходные блоки и связи редактируются в draw.io.</p><div class="grid">{cards}</div></section><section><h2>Документация и рабочие материалы</h2><ul>{docs}<li><a href="api/internal-openapi.json">Внутренние интерфейсы</a></li><li><a href="schemas/events-v1.schema.json">Схемы 16 типов сообщений</a></li><li><a href="tasks.json">40 задач в JSON</a></li><li><a href="traceability.json">Связь требований, схем, задач и проверок</a></li><li><a href="validation-report.json">Результаты проверки пакета</a></li></ul></section></html>'''
    (OUT/'index.html').write_text(markup)

def validate_package(boards,client,events,internal,before):
    checks=[]
    def check(name,condition,detail=''):
        checks.append(dict(check=name,passed=bool(condition),detail=detail))
        if not condition:raise AssertionError(name+': '+detail)
    for name,spec in [('Клиентский OpenAPI',client),('Внутренний OpenAPI',internal)]:
        validate(spec);check(name+' валиден',True)
    Draft202012Validator.check_schema(events)
    validator=Draft202012Validator(events,format_checker=FormatChecker())
    for p in (OUT/'examples').glob('*.json'):validator.validate(json.loads(p.read_text()))
    check('16 примеров событий проходят JSON Schema',len(list((OUT/'examples').glob('*.json')))==16)
    bad=copy.deepcopy(json.loads((OUT/'examples/SubmissionRequested.json').read_text()));bad['payload'].pop('submissionId')
    check('Неполное событие отклоняется',not validator.is_valid(bad))
    bad['payload']['submissionId']='x';bad['payload']['rawDocument']='forbidden'
    check('Лишний payload отклоняется',not validator.is_valid(bad))
    original=json.loads((ORIGINAL/'api/openapi.json').read_text())
    check('Все исходные маршруты и методы сохранены',all(p in client['paths'] and set(methods).issubset(client['paths'][p]) for p,methods in original['paths'].items()),f"Исходных маршрутов: {len(original['paths'])}; итоговых: {len(client['paths'])}")
    check('Состояния заявки совпадают с исходником',client['components']['schemas']['Application']['properties']['status']['enum']==STATES==client['components']['schemas']['StatusView']['properties']['status']['enum'])
    check('Все 202 содержат Location',all('Location' in op['responses']['202'].get('headers',{}) for methods in client['paths'].values() for op in methods.values() if '202' in op.get('responses',{})))
    check('Все исходные файлы переданного пакета сохранены',digest_tree(INPUT)==before)
    taskids={t[0] for t in TASKS};testids={t[0] for t in TESTS}
    check('Все зависимости задач существуют',all(set(t[3]).issubset(taskids) for t in TASKS))
    visited=set();active=set();byid={t[0]:t for t in TASKS}
    def walk(id):
        if id in active:raise AssertionError('Цикл задач '+id)
        if id in visited:return
        active.add(id)
        for parent in byid[id][3]:walk(parent)
        active.remove(id);visited.add(id)
    for id in taskids:walk(id)
    check('Граф 40 задач не содержит циклов',len(visited)==40)
    check('Все ссылки матрицы существуют',all(set(r[3]).issubset(taskids) and set(r[4]).issubset(testids) and all(1<=int(d)<=10 for d in r[2]) for r in REQUIREMENTS))
    root=ET.parse(OUT/'backend-architecture.drawio').getroot()
    check('10 листов draw.io',len(root.findall('diagram'))==10)
    check('Блоки и связи редактируются отдельно',all(len(d.findall('.//mxCell[@vertex="1"]'))>=8 and len(d.findall('.//mxCell[@edge="1"]'))>=2 for d in root.findall('diagram')))
    for d in root.findall('diagram'):
        ids=[c.get('id') for c in d.findall('.//mxCell')];check('Уникальные идентификаторы '+d.get('id'),len(ids)==len(set(ids)))
    for b in boards:
        ET.parse(OUT/'svg'/f'{b.slug}.svg')
        for s in b.shapes:
            if s['kind']=='node':check('Границы блока '+b.slug+'/'+s['id'],s['x']>=0 and s['y']>=0 and s['x']+s['w']<=b.w and s['y']+s['h']<=b.h)
    sizes={}
    for name in ['backend-architecture-atlas.pdf','backend-development-guide.pdf']:
        reader=PdfReader(str(OUT/name));texts=[p.extract_text() or '' for p in reader.pages];sizes[name]=len(reader.pages)
        check('Кириллица и текст каждой страницы '+name,all(re.search('[А-Яа-я]',t) and len(t)>50 for t in texts))
        check('Нет пустых страниц '+name,all(len(t.strip())>80 for t in texts))
    check('10 страниц атласа',sizes['backend-architecture-atlas.pdf']==10)
    operation_count=sum(len(v) for v in client['paths'].values())
    check('Каталог всех клиентских операций',len(json.loads((OUT/'api/interaction-catalog.json').read_text()))==operation_count==49)
    check('Денежные поля ограничены безопасным JSON integer',client['components']['schemas']['Money']['properties']['amountMinor']['maximum']==9007199254740991)
    check('Технический реестр операций имеет владельца',client['paths']['/api/v1/operations/{operationId}']['get']['x-owner-module']=='platform')
    for href in re.findall(r'href="([^"]+)"', (OUT/'index.html').read_text()):
        if href=='validation-report.json':continue  # This report is written after the checks finish.
        if not href.startswith(('http','mailto','#')):check('Локальная ссылка '+href,(OUT/href).exists())
    report=dict(status='passed',date='2026-10-20',scope='Проверка артефактов проектирования; приложение и реальные банковские системы не испытывались',counts=dict(diagrams=10,tasks=len(TASKS),acceptanceCases=len(TESTS),eventTypes=len(events['$defs']),clientPaths=len(client['paths']),clientOperations=operation_count,internalPaths=len(internal['paths']),pdfPages=sizes),checks=checks,visualReview='pending',limitations=['Java-приложение не создавалось и не собиралось','Boot/Java проверены по документации; Modulith/Boot остаётся кандидатом T01.3, сборки приложения нет','Нагрузка, модельное качество и нормативное соответствие не проверялись'])
    (OUT/'validation-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    return report

def readme():
    (OUT/'README.md').write_text('''# Кредитный кабинет: архитектура серверной части

20 октября 2026 года. Java 21 + Spring Boot 4.1.1 (проектная основа; совместная сборка с Modulith требует T01.3). Основание: переданный архитектурный пакет v2. Это проектная документация, а не реализованное приложение и не описание действующих систем Альфа-Банка.

## Начните здесь

1. Откройте backend-architecture-atlas.pdf: 10 листов от границ системы до порядка разработки.
2. Откройте backend-development-guide.pdf: решения, технологии, данные, взаимодействия, 40 задач и 41 проверка.
3. Для просмотра без сети используйте index.html; для изменения блоков и связей - backend-architecture.drawio.

## Состав

- docs/ - девять глав руководства в Markdown.
- api/openapi.json - клиентский OpenAPI 3.0.3; 49 согласованных операций; demo-openapi.json содержит 6 изолированных demo-операций.
- api/internal-openapi.json - нормализованные внутренние границы OpenAPI 3.1; не реальный банковский интерфейс.
- api/contract-changes.md - изменения относительно исходного проектного API.
- api/interaction-catalog.json - отправитель, получатель, данные, доступ, бюджет и ошибки для каждой клиентской операции.
- schemas/ - JSON Schema Draft 2020-12 для 16 событий и каталог тем.
- examples/ - синтетический пример каждого события.
- tasks.json, acceptance-cases.json, traceability.json - рабочие задачи и связи в машинном виде.
- svg/, png/ - отдельные листы для просмотра, увеличения и размещения на доске.
- sources/ - генераторы схем, руководства и проверок пакета.
- validation-report.json - выполненные проверки; не результаты испытаний приложения.
- source-manifest.json - контрольные суммы использованных исходников и перечень первоисточников.

## Принятые границы

Основное приложение модульное; обработчики файлов, модели и банковский адаптер запускаются отдельно. Решение и подтверждение оформления принадлежат банку. Python остаётся только в модельном контуре. Защита хранилищ и резервных копий, ключи, сроки хранения и восстановление - обязательный этап допуска, без подробного криптографического проектирования на основных схемах.

Версии Java-платформы зафиксированы в главе 3. Для неизвестных управляемых средств банка конкретные версии должны быть приняты в T01.3. Производительность, соответствие нормам и качество моделей не заявляются доказанными.

## Повторная сборка материалов

Нужны Python 3, reportlab, pypdf, pypdfium2, Pillow, markdown-it-py, jsonschema и openapi-spec-validator. Установите зависимости из sources/requirements-render.txt в отдельную среду. Укажите CREDIT_FONT_DIR с DejaVuSans.ttf, DejaVuSans-Bold.ttf и DejaVuSansMono.ttf. Запустите sources/build.py из сохранённой структуры проекта. Генератор читает соседний исходный пакет v2 и не меняет его.

История контрольных сумм входного пакета проверяется до и после сборки. Это не цифровая подпись поставки. Итоговые PDF доступны без установки средств разработки.
''')
    (OUT/'sources/requirements-render.txt').write_text('reportlab\npypdf\npypdfium2\nPillow\nmarkdown-it-py\njsonschema\nopenapi-spec-validator\n')

def pack():
    # Keep transient rendering images and Python caches out of the delivered package.
    archive=OUT.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.name!='.DS_Store':z.write(p,Path(OUT.name)/p.relative_to(OUT))
    return archive

def main():
    TMP.mkdir(parents=True,exist_ok=True)
    before=digest_tree(INPUT)
    write_workplan(OUT)
    client,events,internal=write_contracts(OUT,ORIGINAL/'api/openapi.json')
    readme();boards=diagrams();guide();pages=previews();index()
    urls=re.findall(r'\[([^]]+)\]\((https://[^)]+)\)',(OUT/'docs/09-reference.md').read_text())
    sources=dict(date='2026-10-20',inputDirectory=str(INPUT),files=before,primaryPDFsReread=True,upstream='Документы v2, предоставленные пользователем; первичные PDF повторно прочитаны, контрольные суммы совпали',technicalReferences=[dict(title=title,url=url,checkedOn='2026-10-20') for title,url in urls])
    (OUT/'source-manifest.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2))
    report=validate_package(boards,client,events,internal,before);archive=pack()
    print(json.dumps(dict(output=str(OUT),archive=str(archive),guidePages=pages,checks=len(report['checks']),counts=report['counts']),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
