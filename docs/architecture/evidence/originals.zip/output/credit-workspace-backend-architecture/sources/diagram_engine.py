from pathlib import Path
from dataclasses import dataclass, field
import json, html, math, re, textwrap, os, xml.etree.ElementTree as ET
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, Color

OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parent.parent
(OUT / 'svg').mkdir(parents=True, exist_ok=True)
(OUT / 'docs').mkdir(exist_ok=True)
(OUT / 'api').mkdir(exist_ok=True)
FONT_DIR = Path(os.environ.get('CREDIT_FONT_DIR', '/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/LibreOfficeDev.app/Contents/Resources/fonts/truetype'))
pdfmetrics.registerFont(TTFont('DV', str(FONT_DIR/'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', str(FONT_DIR/'DejaVuSans-Bold.ttf')))
PALETTE = {
 'new': ('#eef3ff','#4468ad'), 'bank': ('#f0f3f5','#70808b'),
 'ml': ('#eeeafa','#7860a0'), 'data': ('#e9f5f0','#438774'),
 'security': ('#fff1e4','#b88445'), 'client': ('#fff0ef','#cf524b'),
 'note': ('#fff9e4','#c5a35f'), 'white': ('#ffffff','#d5dce3')
}
INK='#182839'; MUTED='#586a7b'; LINE='#8393a2'; RED='#d64740'

def wrap(text, width, size=17, bold=False):
    font='DV-B' if bold else 'DV'
    result=[]
    for part in str(text).split('\n'):
        line=''
        for word in part.split(' '):
            if pdfmetrics.stringWidth((line+' '+word).strip(),font,size)>width and line:
                result.append(line); line=word
            else: line=(line+' '+word).strip()
        result.append(line)
    return result

@dataclass
class Board:
    slug: str
    title: str
    subtitle: str
    w: int=2000
    h: int=1400
    shapes: list=field(default_factory=list)
    def text(self,x,y,text,size=18,color=INK,bold=False,width=None):
        lines=wrap(text,width,size,bold) if width else str(text).split('\n')
        self.shapes.append(dict(kind='text',x=x,y=y,lines=lines,size=size,color=color,bold=bold))
        return y+len(lines)*size*1.35
    def panel(self,x,y,w,h,title,kind='white'):
        self.shapes.append(dict(kind='panel',x=x,y=y,w=w,h=h,title=title,style=kind))
    def node(self,id,x,y,w,h,title,body='',kind='new'):
        self.shapes.append(dict(kind='node',id=id,x=x,y=y,w=w,h=h,title=title,body=body,style=kind))
        return id
    def edge(self,id,points,label='',async_=False,label_at=None):
        self.shapes.append(dict(kind='edge',id=id,points=points,label=label,async_=async_,label_at=label_at))
    def header(self):
        self.text(45,38,'КРЕДИТНЫЙ КАБИНЕТ     •     СЕРВЕРНАЯ ЧАСТЬ     •     20.10.2026',15,RED,True)
        self.text(45,80,self.title,32,INK,True)
        self.text(45,127,self.subtitle,18,MUTED,width=self.w-90)
    def footer(self):
        self.text(45,self.h-60,'Синий - приложение и обработчики   ·   Серый - системы банка   ·   Фиолетовый - машинное обучение   ·   Зелёный - хранимые сведения',15,MUTED)
        self.text(45,self.h-34,'Стрелки показывают направление действия или передачи данных. Пунктир - обработка в фоне; результат приходит в кабинет позже.',14,MUTED)

BOARDS=[]
def board(slug,title,sub,w=2000,h=1400):
    b=Board(slug,title,sub,w,h); b.header(); BOARDS.append(b); return b

def render_board(b):
    # The SVG, draw.io and PDF all derive from the same scene, preventing layout drift.
    svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{b.w}" height="{b.h}" viewBox="0 0 {b.w} {b.h}" role="img" aria-label="{html.escape(b.title)}">',
         '<defs><marker id="arrow" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L9,4.5 L0,9 Z" fill="#8393a2"/></marker></defs>',
         f'<rect width="{b.w}" height="{b.h}" fill="#ffffff"/>']
    model=ET.Element('mxGraphModel',dx=str(b.w),dy=str(b.h),grid='1',gridSize='10',page='1',pageScale='1',pageWidth=str(b.w),pageHeight=str(b.h),math='0',shadow='0')
    root=ET.SubElement(model,'root'); ET.SubElement(root,'mxCell',id='0'); ET.SubElement(root,'mxCell',id='1',parent='0')
    uid=0
    pdf=canvas.Canvas(str(ROOT/'tmp'/'backend-pdfs'/f'{b.slug}.pdf'),pagesize=(b.w,b.h))
    pdf.setFillColor(HexColor('#ffffff')); pdf.rect(0,0,b.w,b.h,fill=1,stroke=0)
    def rect(x,y,w,h,fill,stroke,r=10):
        svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>')
        pdf.setFillColor(HexColor(fill)); pdf.setStrokeColor(HexColor(stroke));pdf.setLineWidth(1.5);pdf.roundRect(x,b.h-y-h,w,h,r,fill=1,stroke=1)
    def txt(x,y,lines,size=18,color=INK,bold=False):
        for i,line in enumerate(lines):
            base=y+i*size*1.35
            svg.append(f'<text x="{x}" y="{base+size}" font-family="DejaVu Sans,Arial,sans-serif" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}">{html.escape(line)}</text>')
            pdf.setFillColor(HexColor(color));pdf.setFont('DV-B' if bold else 'DV',size);pdf.drawString(x,b.h-base-size,line)
    def cell(value,x,y,w,h,style,cell_id=None):
        nonlocal uid
        uid+=1;c=ET.SubElement(root,'mxCell',id=cell_id or f'c{uid}',value=value,style=style,vertex='1',parent='1');ET.SubElement(c,'mxGeometry',x=str(x),y=str(y),width=str(w),height=str(h),attrib={'as':'geometry'})
        return c
    for panel_index,panel_shape in enumerate(b.shapes):
        if panel_shape['kind']=='panel':panel_shape['anchor_id']='p-'+str(panel_index)
    def anchor(point):
        x,y=point
        for n in b.shapes:
            if n['kind']!='node':continue
            xx,yy,w,h=n['x'],n['y'],n['w'],n['h']
            if xx-1<=x<=xx+w+1 and yy-1<=y<=yy+h+1 and min(abs(x-xx),abs(x-xx-w),abs(y-yy),abs(y-yy-h))<=1:
                return ('n-'+n['id'],(x-xx)/w,(y-yy)/h)
        for panel_shape in b.shapes:
            if panel_shape['kind']!='panel':continue
            xx,yy,w,h=panel_shape['x'],panel_shape['y'],panel_shape['w'],panel_shape['h']
            if xx-1<=x<=xx+w+1 and yy-1<=y<=yy+h+1 and min(abs(x-xx),abs(x-xx-w),abs(y-yy),abs(y-yy-h))<=1:
                return (panel_shape['anchor_id'],(x-xx)/w,(y-yy)/h)
        return None
    # Panels first, connections second, cards/text last. Lines never obscure node text.
    ordered=[s for s in b.shapes if s['kind']=='panel']+[s for s in b.shapes if s['kind'] in ('edge','line')]+[s for s in b.shapes if s['kind'] in ('node','text')]
    for s in ordered:
        kind=s['kind']
        if kind=='panel':
            fill,stroke=PALETTE[s['style']]; rect(s['x'],s['y'],s['w'],s['h'],fill,stroke)
            txt(s['x']+18,s['y']+15,[s['title']],17,MUTED,True)
            cell(s['title'],s['x'],s['y'],s['w'],s['h'],f'rounded=1;arcSize=3;fillColor={fill};strokeColor={stroke};verticalAlign=top;align=left;spacingTop=15;spacingLeft=18;fontFamily=Arial;fontSize=17;fontStyle=1;fontColor={MUTED};whiteSpace=wrap;',cell_id=s['anchor_id'])
        elif kind in ('edge','line'):
            pts=s['points']; dash=s.get('async_',s.get('dash',False)); color=s.get('color',LINE)
            path=' '.join(('M' if i==0 else 'L')+f'{x},{y}' for i,(x,y) in enumerate(pts))
            svg.append(f'<path d="{path}" fill="none" stroke="{color}" stroke-width="2"'+(' stroke-dasharray="7 5"' if dash else '')+(' marker-end="url(#arrow)"' if kind=='edge' else '')+'/>')
            pdf.setStrokeColor(HexColor(color));pdf.setLineWidth(2);pdf.setDash([7,5] if dash else [])
            p=pdf.beginPath();p.moveTo(pts[0][0],b.h-pts[0][1])
            for x,y in pts[1:]:p.lineTo(x,b.h-y)
            pdf.drawPath(p);pdf.setDash([])
            if kind=='edge':
                (x0,y0),(x1,y1)=pts[-2:];ang=math.atan2(y1-y0,x1-x0)
                poly=[(x1,y1),(x1-9*math.cos(ang-.45),y1-9*math.sin(ang-.45)),(x1-9*math.cos(ang+.45),y1-9*math.sin(ang+.45))]
                pdf.setFillColor(HexColor(color));p=pdf.beginPath();p.moveTo(poly[0][0],b.h-poly[0][1]);[p.lineTo(x,b.h-y) for x,y in poly[1:]];p.close();pdf.drawPath(p,fill=1,stroke=0)
            uid+=1
            source=anchor(pts[0]);target=anchor(pts[-1]);extra=''
            if source:extra+=f'exitX={source[1]};exitY={source[2]};exitDx=0;exitDy=0;exitPerimeter=0;'
            if target:extra+=f'entryX={target[1]};entryY={target[2]};entryDx=0;entryDy=0;entryPerimeter=0;'
            c=ET.SubElement(root,'mxCell',id=f'c{uid}',value='',edge='1',parent='1',style=f'endArrow={"block" if kind=="edge" else "none"};endFill=1;strokeColor={color};strokeWidth=2;dashed={int(dash)};rounded=0;'+extra)
            if source:c.set('source',source[0])
            if target:c.set('target',target[0])
            g=ET.SubElement(c,'mxGeometry',relative='1',attrib={'as':'geometry'});ET.SubElement(g,'mxPoint',x=str(pts[0][0]),y=str(pts[0][1]),attrib={'as':'sourcePoint'});ET.SubElement(g,'mxPoint',x=str(pts[-1][0]),y=str(pts[-1][1]),attrib={'as':'targetPoint'})
            a=ET.SubElement(g,'Array',attrib={'as':'points'})
            for x,y in pts[1:-1]:ET.SubElement(a,'mxPoint',x=str(x),y=str(y))
            if s.get('label') and s.get('label_at'):
                x,y=s['label_at'];label=s['label'];txt(x,y,[label],15,MUTED)
                cell(label,x,y,max(70,pdfmetrics.stringWidth(label,'DV',15)+6),25,f'text;html=0;align=left;verticalAlign=top;spacing=0;fontFamily=Arial;fontSize=15;fontColor={MUTED};fillColor=#ffffff;')
        elif kind=='node':
            fill,stroke=PALETTE[s['style']];rect(s['x'],s['y'],s['w'],s['h'],fill,stroke)
            title=wrap(s['title'],s['w']-30,19,True); body=wrap(s['body'],s['w']-30,17)
            need=len(title)*25.65+(len(body)*22.95 if s['body'] else 0)+28
            if need>s['h']+2: raise ValueError(f'Overflow {b.slug}: {s["id"]}: {need} > {s["h"]}')
            txt(s['x']+15,s['y']+12,title,19,INK,True)
            if s['body']:txt(s['x']+15,s['y']+17+len(title)*25.65,body,17,MUTED)
            content='<b>'+html.escape(s['title'])+'</b>'+(('<br>'+html.escape(s['body']).replace('\n','<br>')) if s['body'] else '')
            cell(content,s['x'],s['y'],s['w'],s['h'],f'rounded=1;arcSize=8;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};align=left;verticalAlign=top;spacing=15;fontFamily=Arial;fontSize=17;fontColor={INK};',cell_id='n-'+s['id'])
        elif kind=='text':
            txt(s['x'],s['y'],s['lines'],s['size'],s['color'],s['bold'])
            line='\n'.join(s['lines']);ww=max(pdfmetrics.stringWidth(v,'DV-B' if s['bold'] else 'DV',s['size']) for v in s['lines'])+8
            cell(line,s['x'],s['y'],ww,len(s['lines'])*s['size']*1.35+4,f'text;whiteSpace=wrap;html=0;align=left;verticalAlign=top;spacing=0;fontFamily=Arial;fontSize={s["size"]};fontStyle={1 if s["bold"] else 0};fontColor={s["color"]};')
    svg.append('</svg>');(OUT/'svg'/f'{b.slug}.svg').write_text('\n'.join(svg),encoding='utf-8')
    pdf.showPage();pdf.save()
    return model
