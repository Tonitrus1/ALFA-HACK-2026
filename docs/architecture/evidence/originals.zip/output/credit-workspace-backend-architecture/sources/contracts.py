import json, copy, hashlib
from pathlib import Path

STATES=['DRAFT','SUBMITTED','REVIEW','MANUAL','NEEDS_INFO','APPROVED','ALTERNATIVE','DECLINED','ACCEPTED','COMPLETED','CANCELLED','EXPIRED']
S={'type':'string','minLength':1,'maxLength':256}
ID={'type':'string','format':'uuid'}
V={'type':'integer','minimum':1,'maximum':9007199254740991}
DT={'type':'string','format':'date-time'}
def arr(item):return {'type':'array','items':copy.deepcopy(item),'maxItems':100}
def obj(props,required=None):return {'type':'object','properties':copy.deepcopy(props),'required':required if required is not None else list(props),'additionalProperties':False}
def ref(n):return {'$ref':'#/components/schemas/'+n}
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def build_client(out,original):
    spec=json.loads(original.read_text())
    save(out/'api/demo-openapi.json',json.loads(original.with_name('demo-openapi.json').read_text()))
    catalog=[]
    for path,methods in spec['paths'].items():
        for method,op in methods.items():
            catalog.append(dict(method=method.upper(),path=path,sender='Браузер клиента',receiver=op.get('x-owner-module','workspace'),summary=op['summary'],request=op.get('requestBody',{}).get('content',{}).get('application/json',{}).get('schema',{}).get('$ref','Нет JSON-тела'),authentication='Cookie, актуальный contextVersion, объектные права; CSRF и Idempotency-Key/If-Match по контракту',deadline=op.get('x-deadline-ms',2000),failureCodes=list(op['responses'])))
    # Metadata must not introduce drift from the canonical contract.
    save(out/'api/interaction-catalog.json',catalog)
    save(out/'api/openapi.json',spec)
    return spec

def build_events(out):
    payloads={
    'SubmissionRequested':obj({'submissionId':S,'snapshotVersion':V,'snapshotRef':S,'operationId':S,'externalRequestId':S}),
    'CaseAccepted':obj({'caseId':S,'caseVersion':V,'externalRequestId':S,'clientStage':{'const':'REVIEW'}}),
    'CaseStateChanged':obj({'caseId':S,'caseVersion':V,'clientStage':{'type':'string','enum':['REVIEW','MANUAL','NEEDS_INFO']}}),
    'InformationRequested':obj({'caseId':S,'caseVersion':V,'requestId':S,'requestVersion':V,'requestedItemIds':arr(S)}),
    'InformationResponseSubmitted':obj({'requestId':S,'requestVersion':V,'amendmentId':S,'amendmentVersion':V,'operationId':S,'externalRequestId':S}),
    'DocumentProcessingRequested':obj({'jobId':S,'documentId':S,'objectVersion':S,'jobType':{'type':'string','enum':['SCAN','EXTRACT']}}),
    'DocumentScanCompleted':obj({'documentId':S,'objectVersion':S,'verdict':{'type':'string','enum':['CLEAN','REJECTED','ERROR']},'engineVersion':S}),
    'DocumentExtractionReady':obj({'documentId':S,'objectVersion':S,'extractionId':S,'engineVersion':S}),
    'DecisionRecorded':obj({'caseId':S,'caseVersion':V,'decisionId':S,'outcome':{'type':'string','enum':['APPROVED','ALTERNATIVE','DECLINED']},'offerIds':arr(S)}),
    'OfferAcceptanceRequested':obj({'offerId':S,'offerVersion':V,'operationId':S,'externalRequestId':S}),
    'OfferAccepted':obj({'caseId':S,'caseVersion':V,'offerId':S,'offerVersion':V,'externalRequestId':S}),
    'OfferExpired':obj({'caseId':S,'caseVersion':V,'offerId':S,'offerVersion':V}),
    'WithdrawalRequested':obj({'operationId':S,'externalRequestId':S,'expectedCaseVersion':V},['operationId','externalRequestId']),
    'ApplicationWithdrawn':obj({'caseId':S,'caseVersion':V,'externalRequestId':S}),
    'FulfillmentCompleted':obj({'caseId':S,'caseVersion':V,'operationId':S,'resultReference':S}),
    'ConsentRevoked':obj({'consentId':S,'consentVersion':V,'effectiveAt':DT,'purpose':S})}
    defs={}
    for name,payload in payloads.items():
        defs[name]=obj({'eventId':ID,'eventType':{'const':name},'schemaVersion':{'const':1},'aggregateId':S,'aggregateVersion':V,'applicationId':S,'occurredAt':DT,'correlationId':S,'causationId':S,'payload':payload})
    schema={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'https://schemas.credit.bank.example/events/v1','title':'События кредитного кабинета, версия 1','description':'Минимальные ссылки без анкет, файлов и прямых персональных данных. Доступ задаётся на тему и потребителя. Каждый тип проверяет собственный payload.','$defs':defs,'oneOf':[{'$ref':'#/$defs/'+name} for name in defs]}
    save(out/'schemas/events-v1.schema.json',schema)
    topics=[]
    mapping={
      'credit.submission.v1':['SubmissionRequested','InformationResponseSubmitted','WithdrawalRequested'],
      'credit.bank-results.v1':['CaseAccepted','CaseStateChanged','InformationRequested','DecisionRecorded','OfferAccepted','OfferExpired','ApplicationWithdrawn','FulfillmentCompleted'],
      'credit.offer-commands.v1':['OfferAcceptanceRequested'],
      'credit.documents.v1':['DocumentProcessingRequested','DocumentScanCompleted','DocumentExtractionReady'],
      'credit.consents.v1':['ConsentRevoked']}
    for name,types in mapping.items():
        topics.append(dict(topic=name,eventTypes=types,key='documentId' if 'documents' in name else 'applicationId',retention='Утверждается банком по типу данных; техническая история не заменяет бизнес-хранение',producer='Модуль-владелец через outbox',consumers='Только согласованные служебные роли',delivery='at-least-once',errorTopic=name+'.errors',retry='Исходный eventId и внешний ключ сохраняются; до 8 попыток с задержкой, затем оператор'))
    for topic in topics:
        topic['allowedProducers']=['integration'] if topic['topic']=='credit.bank-results.v1' else (['documents'] if 'documents' in topic['topic'] else ['consents'] if 'consents' in topic['topic'] else ['offers'] if 'offer-commands' in topic['topic'] else ['applications','journey'])
        topic['consumerModules']=['journey','workspace','offers'] if topic['topic']=='credit.bank-results.v1' else ['scanner','ocr-worker','workspace'] if 'documents' in topic['topic'] else ['journey','integration']
        topic['consumerRule']='Для bank-results каждый потребитель читает все типы и продвигает caseVersion; ACL не фильтрует отдельные типы внутри этой темы.'
    save(out/'schemas/topics.json',topics)
    for i,(name,p) in enumerate(payloads.items()):
        def sample(x,key=''):
            if 'const' in x:return x['const']
            if 'enum' in x:return x['enum'][0]
            if x.get('type')=='object':return {k:sample(v,k) for k,v in x['properties'].items() if k in x['required']}
            if x.get('type')=='array':return [sample(x['items'])]
            if x.get('type')=='integer':return 1
            if x.get('format')=='date-time':return '2026-10-20T06:00:00Z'
            if x.get('format')=='uuid':return '00000000-0000-4000-8000-000000000001'
            return 'synthetic-'+(key or 'reference')
        example=sample(defs[name]);example['eventId']=f'00000000-0000-4000-8000-{i+1:012d}'
        save(out/'examples'/f'{name}.json',example)
    return schema

def build_internal(out,event_schema):
    C={}
    for name,sch in event_schema['$defs'].items():C['Event_'+name]=copy.deepcopy(sch)
    C['BankEvent']={'oneOf':[ref('Event_'+n) for n in ['CaseAccepted','CaseStateChanged','InformationRequested','DecisionRecorded','OfferAccepted','OfferExpired','ApplicationWithdrawn','FulfillmentCompleted']]}
    C['Receipt']=obj({'receiptId':S,'recordedAt':DT})
    C['Error']=obj({'code':S,'message':S,'correlationId':S})
    C['BankCommand']=obj({'commandType':{'type':'string','enum':['SUBMIT','RESPOND','WITHDRAW','ACCEPT']},'externalRequestId':S,'applicationId':S,'operationId':S,'payloadRef':S,'expectedVersion':V})
    C['CommandResult']=obj({'externalRequestId':S,'state':{'type':'string','enum':['PENDING','RECONCILING','SUCCEEDED','FAILED','NOT_FOUND']},'caseId':S,'caseVersion':V,'resultCode':S},['externalRequestId','state'])
    C['UploadCompleted']=obj({'uploadId':S,'objectKey':S,'objectVersion':S,'sizeBytes':{'type':'integer','minimum':1,'maximum':10485760},'sha256':{'type':'string','pattern':'^[a-f0-9]{64}$'}})
    C['TransferCheck']=obj({'grant':S,'sessionReference':S,'action':{'type':'string','enum':['UPLOAD','DOWNLOAD']}})
    C['TransferAuthorization']=obj({'transferId':S,'objectRef':S,'objectVersion':S,'expiresAt':DT,'maxBytes':{'type':'integer','minimum':1,'maximum':10485760},'contentType':S},['transferId','objectRef','expiresAt','maxBytes','contentType'])
    C['CreditPackage']=obj({'packageId':S,'packageType':{'type':'string','enum':['SUBMISSION','AMENDMENT','ACCEPTANCE','WITHDRAWAL']},'applicationId':S,'companyId':S,'version':V,'createdAt':DT,'data':{'type':'object','description':'Продуктовый снимок с проверенной схемой конкретной версии продукта; состав полей согласуется T01.2/T01.4. В этой архитектуре банковская продуктовая анкета не выдумывается.'}})
    C['JobClaim']=obj({'workerId':S,'jobType':{'type':'string','enum':['SCAN','EXTRACT']}})
    C['JobLease']=obj({'jobId':S,'generation':V,'leaseUntil':DT,'documentId':S,'objectVersion':S,'objectRef':S,'jobType':{'type':'string','enum':['SCAN','EXTRACT']}})
    C['LeaseRenewal']=obj({'workerId':S,'generation':V})
    C['ScanResult']=obj({'generation':V,'objectVersion':S,'verdict':{'type':'string','enum':['CLEAN','REJECTED','ERROR']},'engineVersion':S,'cleanObjectRef':S},['generation','objectVersion','verdict','engineVersion'])
    C['ExtractionResult']=obj({'generation':V,'objectVersion':S,'engineVersion':S,'status':{'type':'string','enum':['READY','FAILED']},'fields':arr(obj({'name':S,'value':{'type':'string','maxLength':2000},'confidence':{'type':'number','minimum':0,'maximum':1},'page':V}))})
    C['RiskRequest']=obj({'applicationId':S,'requestId':S,'featureSchemaVersion':V,'featureAsOf':DT,'purpose':S,'features':obj({'annualRevenueMinor':{'type':'integer','minimum':0,'maximum':9007199254740991},'currentDebtMinor':{'type':'integer','minimum':0,'maximum':9007199254740991},'businessAgeMonths':{'type':'integer','minimum':0},'requestedAmountMinor':{'type':'integer','minimum':1,'maximum':9007199254740991},'currency':{'const':'RUB'}})})
    C['RiskResult']=obj({'inferenceId':S,'modelVersion':S,'featureSchemaVersion':V,'score':{'type':'number','minimum':0,'maximum':1},'calibrationStatus':{'type':'string','enum':['DEMONSTRATION','VALIDATED']},'internalReasonCodes':arr(S)})
    C['RankingRequest']=obj({'candidateContentIds':arr(S),'stage':{'type':'string','enum':STATES},'contextCategory':S})
    C['RankingResult']=obj({'rankedIds':arr(S),'modelVersion':S,'reasonCategory':S})
    paths={}
    def op(path,method,title,req=None,res=None,status='200',role='',budget='2 с'):
        o={'operationId':method+'_'+path.replace('/','_').replace('{','').replace('}','').replace('-','_'),'summary':title,'description':f'Разрешённая служебная роль: {role}. Начальный бюджет: {budget}. Проверять назначение и версии объекта. Не является реальным банковским API.', 'x-allowed-service-role':role,'x-time-budget':budget,'responses':{status:{'description':'Долговечно принято' if status=='202' else 'Успешно'}}}
        import re
        o['parameters']=[{'name':k,'in':'path','required':True,'schema':S} for k in re.findall(r'\{(\w+)\}',path)]
        if req:o['requestBody']={'required':True,'content':{'application/json':{'schema':ref(req)}}}
        if res:o['responses'][status]['content']={'application/json':{'schema':ref(res)}}
        for error,description in [('400','Неверный формат'),('403','Служебная роль не разрешена'),('409','Конфликт версии или поколения'),('503','Зависимость временно недоступна')]:o['responses'][error]={'description':description,'content':{'application/json':{'schema':ref('Error')}}}
        paths.setdefault(path,{})[method]=o
    op('/internal/v1/commands','post','Долговечно принять команду банковским адаптером','BankCommand','Receipt','202','journey/offer-dispatcher')
    op('/internal/v1/commands/{externalRequestId}','get','Сверить результат по прежнему внешнему номеру',res='CommandResult',role='reconciler',budget='10 с; не держать транзакцию')
    op('/internal/v1/bank-events','post','Принять нормализованное событие после проверки банковского отправителя','BankEvent','Receipt','202','bank-inbound-adapter')
    op('/internal/v1/uploads/{uploadId}/complete','post','Подтвердить сохранение точной версии объекта','UploadCompleted','Receipt','200','file-gateway')
    op('/internal/v1/transfers/{transferId}/authorize','post','Проверить сеанс, разрешение и актуальное право на файл','TransferCheck','TransferAuthorization','200','file-gateway')
    op('/internal/v1/packages/{packageId}','get','Прочитать неизменяемый пакет по разрешённой ссылке',res='CreditPackage',role='bank-adapter')
    op('/internal/v1/document-jobs/claim','post','Получить аренду ожидающего задания','JobClaim','JobLease','200','scanner/ocr-worker')
    paths['/internal/v1/document-jobs/claim']['post']['responses']['204']={'description':'Нет доступных заданий; ограниченный повтор с разбросом'}
    op('/internal/v1/document-jobs/{jobId}/renew','post','Продлить аренду текущего поколения','LeaseRenewal','JobLease','200','scanner/ocr-worker')
    op('/internal/v1/document-jobs/{jobId}/scan-result','post','Записать результат проверки текущей версии','ScanResult','Receipt','200','scanner')
    op('/internal/v1/document-jobs/{jobId}/extraction-result','post','Записать поля-кандидаты текущего поколения','ExtractionResult','Receipt','200','ocr-worker')
    op('/internal/v1/risk/evaluations','post','Получить вспомогательную оценку риска','RiskRequest','RiskResult','200','bank-adapter',budget='1 с; без скрытого кредитного решения')
    op('/internal/v1/feed/ranking','post','Упорядочить утверждённые материалы','RankingRequest','RankingResult','200','workspace',budget='150 мс; без повтора, запасной путь по правилам')
    spec={'openapi':'3.1.0','info':{'title':'Внутренние интерфейсы кредитного кабинета','version':'1.0.0-design','description':'Проект нормализованных границ. Реальные банковские протоколы согласуются отдельно. Доставка команд между владельцами по Kafka; HTTP commands - служебный вход адаптера/имитатора с той же защитой от повторов, не второй независимый путь создания операции.'},'servers':[{'url':'https://internal.credit.bank.example'}],'security':[{'ServiceCertificate':[]}],'paths':paths,'components':{'securitySchemes':{'ServiceCertificate':{'type':'mutualTLS','description':'Взаимная проверка сертификатов плюс разрешённые служебные роли. Заголовки клиента не заменяют служебную идентичность.'}},'schemas':C}}
    client=json.loads((out/'api/openapi.json').read_text())['components']['schemas']
    for name,schema in client.items():
        C.setdefault(name,copy.deepcopy(schema))
    C['CaseSnapshot']=obj({'caseId':S,'applicationId':S,'companyId':S,'caseVersion':V,'status':{'type':'string','enum':STATES[2:]},'informationRequests':arr(ref('InformationRequest')),'decision':ref('Decision'),'offers':arr(ref('Offer')),'recordedAt':DT},['caseId','applicationId','companyId','caseVersion','status','informationRequests','offers','recordedAt'])
    op('/internal/v1/cases/{caseId}/snapshot','get','Прочитать полный нормализованный банковский снимок для сверки и ссылочных событий',res='CaseSnapshot',role='reconciler/journey/offers/workspace',budget='2 с на локальный нормализованный снимок; получение реального банковского снимка согласуется отдельно')
    C['JobLease']['properties']['leaseToken']=copy.deepcopy(S);C['JobLease']['required'].append('leaseToken')
    for name in ['LeaseRenewal','ScanResult','ExtractionResult']:
        C[name]['properties'].update(workerId=copy.deepcopy(S),leaseToken=copy.deepcopy(S))
        C[name]['required']=list(dict.fromkeys(C[name]['required']+['workerId','leaseToken']))
    C['ScanResult']['oneOf']=[{'properties':{'verdict':{'enum':['CLEAN']}},'required':['cleanObjectRef']},{'properties':{'verdict':{'enum':['REJECTED','ERROR']}},'not':{'required':['cleanObjectRef']}}]
    C['TransferCheck']['properties'].update(contextVersion=copy.deepcopy(V),csrfToken=copy.deepcopy(S),origin=copy.deepcopy(S))
    C['TransferCheck']['required']+=['contextVersion','origin']
    C['TransferCheck']['description']='Для UPLOAD csrfToken обязателен; сессия и версия контекста проверяются при открытии и финализации. Источник identity берётся из доверенной сессии, не тела браузера.'
    C['TransferCheck']['oneOf']=[{'properties':{'action':{'enum':['UPLOAD']}},'required':['csrfToken']},{'properties':{'action':{'enum':['DOWNLOAD']}}}]
    C['UploadCompleted']['properties'].update(sessionReference=copy.deepcopy(S),contextVersion=copy.deepcopy(V),grant=copy.deepcopy(S))
    C['UploadCompleted']['required']+=['sessionReference','contextVersion','grant']
    C['UploadCompleted']['description']='CAS UPLOADING->QUARANTINED атомарен с проверкой отмены, точного размера/хеша, версии контекста, срока grant и созданием SCAN job. Повтор с тем же объектом возвращает прежний receipt; иные байты дают 409.'
    C['BankCommand']['description']='expectedVersion относится к payloadRef/package.version; версия банковского дела передаётся отдельно как expectedCaseVersion и проверяется адаптером. Служебный вход и Kafka используют один реестр externalRequestId, не две команды.'
    C['BankCommand']['properties']['expectedCaseVersion']=copy.deepcopy(V)
    C['CreditPackage']['properties']['data']={'oneOf':[ref('SubmissionPackage'),ref('AmendmentPackage'),ref('AcceptancePackage'),ref('WithdrawalPackage')]}
    C['SubmissionPackage']=obj({'kind':{'const':'SUBMISSION'},'productId':S,'productVersion':V,'terms':ref('Need'),'business':ref('Business'),'documentReferences':arr(ref('DocumentReference')),'consentRecordIds':arr(S),'requirementsVersion':V})
    C['AmendmentPackage']=obj({'kind':{'const':'AMENDMENT'},'requestId':S,'requestVersion':V,'draftVersion':V,'requirementsVersion':V,'amendment':ref('DraftPatch'),'documentReferences':arr(ref('DocumentReference')),'explanation':{'type':'string','maxLength':2000}},['kind','requestId','requestVersion','draftVersion','requirementsVersion','documentReferences'])
    C['AcceptancePackage']=obj({'kind':{'const':'ACCEPTANCE'},'offerId':S,'offerVersion':V,'actorRef':S})
    C['WithdrawalPackage']=obj({'kind':{'const':'WITHDRAWAL'},'expectedApplicationVersion':V,'expectedCaseVersion':V,'reason':S},['kind','expectedApplicationVersion'])
    C['CreditPackage']['description']='Синтетический MVP имеет явные схемы четырёх пакетов. packageType равен data.kind; несоответствие — 422. Банковский продукт использует отдельную согласованную схему и новую версию, а не произвольный JSON.'
    C['CreditPackage']['oneOf']=[{'properties':{'packageType':{'const':kind},'data':ref(name)}} for kind,name in [('SUBMISSION','SubmissionPackage'),('AMENDMENT','AmendmentPackage'),('ACCEPTANCE','AcceptancePackage'),('WITHDRAWAL','WithdrawalPackage')]]
    for operation in paths['/internal/v1/document-jobs/{jobId}/scan-result'].values():
        operation['description']+=' Проверять workerId и leaseToken, назначенную identity/роль SCAN, непросроченную аренду, generation и objectVersion; при CLEAN подтвердить чистый объект.'
    save(out/'api/internal-openapi.json',spec)
    return spec

def write_contracts(out,original):
    client=build_client(out,original)
    events=build_events(out)
    internal=build_internal(out,events)
    (out/'api/contract-changes.md').write_text("""# Согласованный контракт после аудита

Версия 1.2.0-design: 49 публичных операций; 6 demo-операций вынесены в demo-openapi.json. Общая архитектура и frontend baseline совпадают с клиентским контрактом. История исходных контрактов сохранена в architecture-review/originals.zip.

Приняты G01-G10: сессии демонстрации, черновик уточнения, требования к файлам, отмена/замена, capabilities, операторский контур, история, восстановление операций и адресуемые SSE. Дополнительно определено подтверждение OCR в черновике уточнения. Добавлены contextVersion, явная очистка полей, точные ссылки и версии требований, полные условия имитатора, типизированные пакеты MVP, привязка аренды к worker и нормализованный банковский снимок.

Это изменение проектной спецификации до реализации; совместимость несуществующего сервера не заявляется. Подробное обоснование: architecture-review/findings.json и отчёт аудита.
""")
    return client,events,internal
