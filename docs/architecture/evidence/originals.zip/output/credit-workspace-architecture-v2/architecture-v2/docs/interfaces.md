# Каталог взаимодействий и контрактов

## 1. Общие правила

Это архитектурные контракты v1. api/openapi.json описывает основной клиентский REST API с минимальными схемами; он не является API уже работающего приложения и не описывает реальные интерфейсы Альфа-Банка. Нормализованные внутренние ML и банковские интерфейсы описаны в backend api/internal-openapi.json; бинарные и demo-маршруты определены явно. Реальные банковские протоколы требуют подтверждения.

Внешний REST: JSON over HTTPS через BFF, /api/v1. Сессия - cookie, для изменяющих запросов - CSRF token. На каждый объект сервер проверяет связь actor → company → application/document/offer. Тело не может переопределить companyId ресурса. Внутри - mTLS workload identity + scoped actor context; сервис проверяет и identity вызывающего workload, и права пользователя.

Деньги - amountMinor как int64 и currency; даты/время - ISO 8601 UTC; ID - UUID либо непрозрачный банковский ID. Не использовать ФИО/ИНН как URL ID. Ошибки: code, безопасное message, correlationId, fieldErrors; без stack trace. Общие коды: 400 формат, 401 сессия, 403 действие запрещено, 404 недоступный объект, 409 версия/состояние, 413 размер, 415 тип, 422 бизнес-валидация, 429 квота, 503 зависимость. Для чужого объекта допускается 404 без раскрытия существования.

PATCH черновика требует If-Match с версией. Критичные POST требуют Idempotency-Key; ключ scoped по actor + company + operation + resource. В хранилище сохраняются canonical request hash и ответ. Повтор того же ключа с другим телом - 409. Проектный срок хранения результата команды - не менее 24 часов; для принятия/создания договора внешняя уникальная ссылка живёт не меньше срока бизнес-операции. Предел подтверждается владельцем данных.

Вызовы чтения: бюджет 1 с на зависимость, общий BFF deadline 2 с. Записи: бюджет синхронного подтверждения 2 с, длительная операция возвращает 202. На автоматическом синхронном пути нет вложенных бесконтрольных retries. GET допускает один повтор только в оставшемся бюджете. Команды повторяются с тем же ключом после проверки результата. Фоновые retries: exponential backoff с jitter, 1 с → 5 мин, максимум 8 попыток, затем DLQ/оператор; это проектная стартовая настройка. Внешние SLA могут потребовать иные значения.

## 2. Связи F01–F33

Стрелка «A → B» обозначает инициатора и обработчика; ответ идёт по тому же соединению. Группы на схемах раскрыты здесь; общая группа хранилищ не разрешает каждому сервису произвольный доступ ко всем данным.

| ID / маршрут | Протокол и данные | Доступ / ошибка |
| --- | --- | --- |
| F01 C01 → E01 | HTTPS: web, API, SSE, файл через выделенный маршрут | TLS, WAF; 413/429 до дорогой обработки |
| F02 E01 → E02 | Внутренний TLS: API; статика обслуживается отдельным origin | Только доверенный ingress; нельзя обходить WAF |
| F03 E02 → B01 | HTTPS REST/SSE; cookie, CSRF, correlationId | Проверенная сессия; bounded deadline |
| F04 B01 ↔ X01 через доверенный маршрут E02 | OIDC code/token/JWKS; серверные токены | state/nonce, проверка issuer/audience; при отказе новый вход |
| F05 B01/B04/B06/B09 → B02 | REST: memberships, role, authority version | Проверка по actor/company; deny при неизвестных полномочиях |
| F06 B01 → B03 | REST: diagnostics, catalog/version, comparison | Каталог допускает общий кеш; рекомендации без обещания кредита |
| F07 B01 → B04 | REST: draft, snapshot, amendment, expectedVersion | Авторизация объекта, If-Match; 409 при конфликте |
| F08 B01/B04/I01 → B05 | REST: purpose, subject, textVersion, validity | Consent actor и субъект проверяются; fail closed для обязательного основания |
| F09 B01 → B06 | REST metadata, upload intent, extraction, download intent | application scope; файл идёт отдельным file gateway; TTL разрешения |
| F10 B01 → B07 → B04 | REST: submit/RFI/cancel commands | B04 атомарно пишет snapshot + submission + outbox; B07 доставляет |
| F11 B01 → B08 | REST/SSE: status snapshot, history, next action | Авторизация подписки; version/cursor; resync вместо потери события |
| F12 B01 → B09 | REST: offer read/accept, operation state | Версия и idempotency; актуальность подтверждает X03 |
| F13 B01 → B08 | REST: feed, утверждённая статья, inbox, read marker, UX-feedback | Только контекст выбранной компании; без загрузки всей анкеты |
| F14 owner module → D01 | TLS SQL: собственная схема, snapshot, outbox/inbox | Отдельные credentials и pool limits; нет cross-owner SQL |
| F15 B01/B03/B08 → D02 | TLS Redis: сессия, каталог, короткий вычислимый кеш | Namespace/TTL; потеря кеша → источник истины/повтор входа |
| F16 B06/file gateway → D03 | S3 TLS: stream quarantine; AV copy to clean; authorized download | Scoped role, длина/тип/квота; чистый объект только после AV |
| F17 B06 → AV worker → B06 | Queue job + S3; scan verdict + engineVersion | Изолированный worker; ERROR остаётся в карантине, не CLEAN |
| F18 владельцы B04/B05/B06/B07/B09/I01 → D04 | Kafka TLS: domain events из outbox; applicationId partition key | ACK, publisher checkpoint; дубликаты нормальны |
| F19 B07/B09 → I01 | mTLS REST: case creation, RFI response, withdrawal, acceptance | Stable externalRequestId; uncertain result → reconcile |
| F20 I01 ↔ X03 | Bank API + callback/inbound adapter: case, decision, offer | Проверка sender; caseVersion; callback сначала durable inbox |
| F21 I01 → X02/X04/X05/X06 | Bank API: company, fraud, signing/core; BKI/registry через egress | Отдельные scopes/consents, quotas и бюджеты по адаптеру |
| F22 X03 → I01 → M01 → M02 → I01 → X03 | Risk REST: approved features, applicationId, versions → score | mTLS + purpose; без прямых идентификаторов; ошибка → pending/manual |
| F23 B06 → M03 | OCR job: documentId, scoped object reference, task version | Только CLEAN; raw PII доступен только OCR-сегменту |
| F24 B08 → M04 → B08 | REST: stage, approved context, candidate IDs | 150 мс budget; без retries, fallback rules; next action закрепляет B08 |
| F25 M03 → D03 | Scoped S3 read CLEAN, temp file внутри worker | Короткий scope, удаление временного файла после job |
| F26 M03 → D04 → B06/B08 | OCRReady: refs, fields+confidence | B06 сохраняет результат, B08 уведомляет; B04 меняется только после подтверждения клиентом |
| F27 I01/B07 + D04 → B08 → B01 → C01 | Case/decision/RFI events → projection → SSE | Inbox/version check; клиент получает только разрешённые данные |
| F28 C02 ↔ X03 | Внутреннее рабочее место банковская система рассмотрения и штатный staff API | RBAC/ABAC + аудит; клиентский BFF не даёт staff-права |
| F29 все state owners → S02 | Audit outbox → защищённый журнал/SIEM | Долговечная локальная запись; backlog контролируется; нельзя молча терять аудит |
| F30 сервис → служебные учётные данные | Получение конфигурации и credentials по правам сервиса | Криптографический слой отложен; пароли не помещаются в события/образы |
| F31 сервисы → O01 → metrics adapter/HPA | OTel/metrics/log pipeline; custom metrics API для HPA | Allowlist полей, sampling; перегрузка telemetry не блокирует заявку |
| F32 D01/D03/D04 → DR | Репликация/backup по владельцам и технологии | Контроль задержки копирования; отключение прежнего узла перед переключением |
| F33 X03/M01 → governed dataset → M05 → M02/M04 | Управляемый offline export, training, registry, approved rollout | Purpose/retention/lineage; dataset не равен выгрузке всех сырых документов |

## 3. События и обратный путь

Обязательная оболочка: eventId, eventType, schemaVersion, aggregateId, aggregateVersion, applicationId при наличии, occurredAt, correlationId, causationId. Для событий банковская система рассмотрения дополнительно caseId и caseVersion. Время доставки хранится отдельно от времени бизнес-события.

| Событие | Производитель → потребители | Обязательный payload |
| --- | --- | --- |
| SubmissionRequested | B04 → B07/I01 | submissionId, snapshotVersion, snapshotRef, operationId, externalRequestId |
| CaseAccepted | I01 из банка → B07/B08/B09; все читают полную caseVersion | caseId, caseVersion, externalRequestId, clientStage |
| CaseStateChanged | I01 из банка → B07/B08/B09; все читают полную caseVersion | caseId, caseVersion, clientStage |
| InformationRequested | I01 из банка → B07/B08/B09; все читают полную caseVersion | caseId, caseVersion, requestId, requestVersion, requestedItemIds |
| InformationResponseSubmitted | B07 → I01 | requestId, requestVersion, amendmentId, amendmentVersion, operationId, externalRequestId |
| DocumentProcessingRequested | B06 → обработчики | jobId, documentId, objectVersion, jobType |
| DocumentScanCompleted | B06 → B08 | documentId, objectVersion, verdict, engineVersion |
| DocumentExtractionReady | B06 → B08 | documentId, objectVersion, extractionId, engineVersion |
| DecisionRecorded | I01 из банка → B07/B08/B09; все читают полную caseVersion | caseId, caseVersion, decisionId, outcome, offerIds |
| OfferAcceptanceRequested | B09 → I01 | offerId, offerVersion, operationId, externalRequestId |
| OfferAccepted | I01 из банка → B07/B08/B09; все читают полную caseVersion | caseId, caseVersion, offerId, offerVersion, externalRequestId |
| OfferExpired | I01 из банка → B07/B08/B09; все читают полную caseVersion | caseId, caseVersion, offerId, offerVersion |
| WithdrawalRequested | B07 → I01 | operationId, externalRequestId |
| ApplicationWithdrawn | I01 из банка → B07/B08/B09; все читают полную caseVersion | caseId, caseVersion, externalRequestId |
| FulfillmentCompleted | I01 из банка → B07/B08/B09; все читают полную caseVersion | caseId, caseVersion, operationId, resultReference |
| ConsentRevoked | B05 → B07/I01 | consentId, consentVersion, effectiveAt, purpose |

События с полями OCR ограничены ACL документного топика; общий статусный топик содержит только refs и безопасные признаки готовности. Ошибка projection не повторяет кредитную команду. При восстановлении B08 может перечитать события и сверить snapshot банковская система рассмотрения.

SSE: stream авторизуется серверной сессией. Сообщение содержит resourceId, viewVersion, eventType и безопасный nextAction или признак необходимости перечитать snapshot. Last-Event-ID действует только в пределах доступной истории; если cursor устарел - resync. Ограничить численность соединений по сессии/IP, heartbeat около 25 с, jitter reconnect и отключение при logout/смене компании. Нельзя использовать SSE как единственное хранилище события.

## 4. Переходы заявки

| Из | В | Инициатор / условие |
| --- | --- | --- |
| DRAFT | SUBMITTED | Клиент; валидный immutable submission сохранён B04 |
| SUBMITTED | REVIEW | X03 подтвердил создание case; duplicate external ID даёт прежний case |
| REVIEW | MANUAL | X03 требует экспертного рассмотрения |
| REVIEW / MANUAL | NEEDS_INFO | X03 создал версионированный запрос |
| NEEDS_INFO | REVIEW | X03 принял ответ; та же applicationId/caseId |
| REVIEW / MANUAL | APPROVED | X03 записал положительный исход и предложение |
| REVIEW / MANUAL | ALTERNATIVE | X03 предложил другие условия/продукт |
| REVIEW / MANUAL | DECLINED | X03 записал отрицательный исход |
| APPROVED / ALTERNATIVE | ACCEPTED | X03 атомарно принял актуальную неистёкшую offerVersion |
| APPROVED / ALTERNATIVE | EXPIRED | X03 сообщил об истечении, не часы браузера |
| SUBMITTED / REVIEW / MANUAL / NEEDS_INFO / APPROVED / ALTERNATIVE | CANCELLED | Клиент запросил отзыв; владелец состояния подтвердил допустимость |
| ACCEPTED | COMPLETED | X05/X03 подтвердил оформление/предоставление по выбранному сценарию |

DRAFT можно удалить до отправки; это операция жизненного цикла черновика, не решение банка. Обновление истёкшего предложения создаёт новую offerVersion и новое разрешённое состояние по банковская система рассмотрения; в MVP предлагается начать новый процесс по явному действию клиента. Интеграционные PENDING/RETRY/DLQ и file states не смешиваются с этим автоматом.

У документа независимые scanState (UPLOADING, QUARANTINED, CLEAN, REJECTED, DELETED) и extractionState (NOT_REQUESTED, PENDING, READY, FAILED, CONFIRMED). Готовность OCR не отменяет требования CLEAN; ошибка OCR не отменяет успешный AV. Подтверждение полей не даёт права менять документ после отправки заявки без amendment.

## 5. Минимальные интерфейсы ML

Risk request: applicationId, applicationRef, featureSchemaVersion, featureVector, featureAsOf, purpose, requestId. Risk response: inferenceId, modelVersion, schemaVersion, score, calibrationStatus, internalReasonCodes, elapsedMs. Значимые финансовые признаки - числа; прямые ПДн не нужны. При пропуске/устаревании обязательных признаков - явная ошибка, не подстановка нулей.

OCR job: documentId, documentVersion, objectRef, allowedType, pageLimit, extractionSchemaVersion, jobId. Result: extractionId, status, fields[value, confidence, page], engine/modelVersion. Текст оригинала не становится частью общего telemetry payload.

Feed request: candidateContentIds, stage, permitted coarse context, modelVersion preference. Response: rankedIds, safe reasonCategory, modelVersion. Нельзя добавлять неутверждённый контент или менять обязательное next action.

## 6. Версии, миграции и сверка

Строгие события расширяются новой schemaVersion и темой с параллельным потребителем. Новое необязательное поле в прежней wire-версии также отвергается старой схемой. Для миграции БД действует expand → migrate → switch → contract; HTTP-ответы допускают добавочные необязательные поля при проверке используемой части.

I01 хранит mapping applicationId ↔ externalRequestId ↔ caseId, последний подтверждённый caseVersion и состояние доставки. Периодическая сверка проверяет застрявшие команды, пропуски и расхождения. После timeout команды нельзя решать по отсутствию ответа, была ли она выполнена. Ручной replay из DLQ требует scope, аудита и сохранения исходного idempotency ID.
## 5. Согласование интерфейсов после аудита

Согласованный клиентский контракт: версия 1.2.0-design, 49 операций /api/v1. api/demo-openapi.json содержит 6 отдельных demo-операций. Это спецификация реализации, не действующий банковский API. Frontend baseline является точной копией backend; прежний файл proposed-additions.openapi.json сохранён как совместимый указатель на объединённую согласованную спецификацию, его статус больше не proposal.

G01-G10 приняты как проектные решения и включены в серверный план. Демонстрационные вход, список аккаунтов, отдельная операторская сессия, список дел, действия и reset отключаются вне demo-профиля; клиентская cookie не даёт операторских прав. Операторские команды используют свой CSRF и Idempotency-Key; login требует точный Origin, JSON Content-Type и фиксированную синтетическую учётную запись. Demo работает на loopback/изолированном стенде, не на доступном извне промышленном адресе.

Все персональные ответы, ошибки и бинарные маршруты используют Cache-Control: no-store. Ошибка имеет Error; при обрыве/ошибке периметра возможен не-JSON ответ, который клиент обрабатывает безопасно. 201 повтор создания возвращает тот же ресурс/результат; 202 возвращает CommandReceipt с Location и долговечной operationId. При повторе 202-команды — прежняя операция и её текущее состояние, а не новая. Idempotency-Key нужен также для upload-intents и confirm-extraction; If-Match нужен при подтверждении извлечения и сохранении обоих видов черновика. ETag передаётся дословно.

GET /operations по умолчанию возвращает активные и завершённые за последние 24 часа операции текущего actor+company+application с пагинацией; active=true предназначен только для фонового наблюдения. После перезагрузки читать без этого фильтра: ответ мог потеряться уже после SUCCEEDED. GET /operations/lookup не раскрывает чужие ключи; его 404 не доказывает, что первая попытка не выполняется. Внешний банковский externalRequestId не выдаётся браузеру.

Обязательные версии, счётчики и суммы ограничены безопасным целым JSON; версии начинаются с 1. Деньги не преобразуются через float. Одинаковое имя version не означает общую последовательность: Application.version, draftVersion, caseVersion, offerVersion, contextVersion и версия представления независимы.

Выбранная компания принадлежит серверной cookie-сессии и общая для всех вкладок. Session.contextVersion начинается с 1 и атомарно увеличивается при смене компании. Все операции выбранной компании, включая файлы и SSE, передают X-Company-Context. Сервер сравнивает его с сессией до эффекта; при несовпадении возвращает 409 COMPANY_CONTEXT_CHANGED. POST /session/company также сравнивает контекст и возвращает новую Session; два параллельных переключения не перезаписывают друг друга молча. companyId из тела, пути, query и ресурса должен соответствовать выбранной компании; заголовок не выдаёт полномочий.

При смене компании одна вкладка сообщает другим лишь об изменении поколения через BroadcastChannel. Остальные отменяют запросы, очередь сохранения и загрузки, очищают старые данные и перечитывают Session; изменённый ввод не отправляется автоматически в новый контекст. Запрос, уже зафиксированный до переключения, остаётся действительным для прежней компании, его ответ не применяется к новому экрану. При 409 контекста UI требует повторного выбора/осознанного продолжения. Критичная серверная транзакция повторно проверяет контекст или блокирует запись контекста до commit; одной проверки HTTP-фильтром недостаточно. Долгий файловый поток проверяет контекст при открытии и финализации. Открытые SSE закрываются при смене контекста, истечении и отзыве прав; периодическая перепроверка остаётся резервным контролем.

InformationItem.kind=FIELD содержит fieldPath из разрешённого перечня; DOCUMENT содержит requirementId; EXPLANATION использует explanation. Имитатор и реальный адаптер не принимают произвольный путь записи. Изменения вне запрошенного набора отклоняются. В MVP одновременно открыт один запрос уточнений на заявку; новый запрос закрывает/заменяет прежний с новой версией и требует пересмотра ответа.

InformationDraft имеет собственные draftVersion/ETag, requestVersion и requirementsVersion. Очередь автосохранения ответа работает по тем же правилам, что очередь заявки. Перед /responses она завершается; команда содержит draftVersion, requestVersion, requirementsVersion, documentIds и точные documentReferences, а содержимое сверяется с сохранённым черновиком. Конкурентное сохранение или замена запроса даёт конфликт без потери локального ввода. Повтор исходного ключа проверяется до проверок уже изменившегося состояния.

POST /applications/{applicationId}/confirm-extraction изменяет только DRAFT и после отправки возвращает APPLICATION_IMMUTABLE. Для уточнения определён POST /applications/{applicationId}/information-requests/{requestId}/draft/confirm-extraction: If-Match относится к InformationDraft, результат — InformationDraft. Подтверждение проверяет extractionId, objectVersion, версию источника и allowlist полей. Клиент отправляет только имя и подтверждённое значение, не управляет confidence, page или modelVersion. Исходный submission остаётся неизменным.

Обычный PATCH не принимает confirmedExtractionIds. Сервер формирует происхождение подтверждения только через разрешённый сценарий. Частичный business сливается по полям; отсутствующее поле не очищается. Для очистки необязательных бизнес-полей используется clearFields с фиксированными путями. Одновременное присваивание и очистка одного пути даёт 422; цель, сумма и срок обязательны.

Submit и InformationResponse требуют requirementsVersion и точные documentReferences. Набор documentIds совпадает с ними без дублей; расхождение даёт DOCUMENT_REFERENCES_MISMATCH. Требования читаются через единый /document-requirements: в DRAFT по продукту, после отправки — по текущему OPEN-запросу; закрытый запрос не открывает загрузку. Для RFI UploadInput содержит requestId и requestVersion парой.

Document.version — версия метаданных; objectVersion — неизменяемые байты. Смена scanState/extractionState может менять метаданные, но не создаёт новые байты. Extraction фиксирует objectVersion и версию источника при старте; подтверждение проверяет именно этот источник, актуальное extractionId и отсутствие замены. Снимок отправки хранит наблюдённую documentVersion и objectVersion; поздние изменения метаданных не меняют снимок.

Замена создаёт новый documentId с replacesDocumentId. Новая запись удовлетворяет требование только после CLEAN; до этого старый допустимый документ не исключается. Конкурентные замены одного документа сериализуются через reservation/expectedDocumentVersion; проигравшая получает 409. Финализация и отмена используют одну CAS-проверку состояния upload: отменённое разрешение не может стать завершённым, завершённое даёт UPLOAD_ALREADY_COMPLETED. Объект, записанный проигравшим потоком, изолирован и удаляется сверкой. Разрешение привязано к сессии, компании, заявке, действию, точным байтам и сроку; при приёме проверяются длина и заявленный размер, а не только общий максимум.

JobLease выдаёт leaseToken и generation; renew/result передают workerId, leaseToken и generation, которые сверяются со служебной identity, типом задания, сроком аренды и objectVersion. CLEAN-результат требует cleanObjectRef и подтверждение наличия/контрольной суммы чистого объекта. ERROR остаётся карантином. Просроченное поколение не может записать результат после выдачи новой аренды.

GET /events/snapshot возвращает курсор-барьер, companyId, contextVersion и complete=false. applications — лишь ограниченный предварительный список до 100 элементов; его нельзя считать полной компанией. Клиент сохраняет курсор, перечитывает все активные ресурсы (заявки, документы, операции, inbox, feed), затем подключается с этим курсором. Полученные повторно уведомления безопасно инвалидируют чтения. При resync_required процедура повторяется целиком, поэтому изменение документа/операции не теряется из-за восстановления только статусов заявок.

Изменение исходных данных документа/операции и outbox фиксируются вместе; workspace обрабатывает сигнал и записывает stream_event в своей транзакции со счётчиком компании. Redis только пробуждает читателей. viewVersion сравнивается внутри resourceType+resourceId, а не между ресурсами. companyId/contextVersion сообщения сверяются с текущим поколением браузера.

Каждый потребитель банковской caseVersion получает весь поток credit.bank-results.v1 по applicationId и продвигает курсор даже для типов, не меняющих его собственную проекцию. Нельзя подписать offers только на DecisionRecorded/OfferAccepted и трактовать промежуточное CaseStateChanged как потерю версии. Один банковский caseVersion соответствует одному нормализованному изменению; если банк присылает несколько частей, адаптер собирает их в один нормализованный результат/снимок. Пропуск блокирует только соответствующее дело и вызывает сверку; полный нормализованный снимок доступен через GET /internal/v1/cases/{caseId}/snapshot и содержит безопасные детали запросов, решения и предложений.

В MVP событие документа относится к той же applicationId; общая история не содержит OCR-полей. Строгие JSON Schema запрещают неизвестные поля в событии schemaVersion=1. Поэтому расширение такого wire-формата требует новой schemaVersion/темы и параллельного потребителя. Добавление необязательных полей HTTP-ответа допускается, если клиент проверяет только используемые поля. Проверка V29 различает эти два случая.
