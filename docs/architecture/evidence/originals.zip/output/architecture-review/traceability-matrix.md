# Сквозная матрица требований



В строках указаны нормативные связи спецификации; наличие теста означает требование будущей приёмки, а не выполненное испытание. Полные операции и события — в traceability-matrix.json.



## R01. Границы и ответственность банка



**Компоненты:** B01-B09, I01, X01-X06.

**Экраны:** U01, U02, U03, U04, U05, U06, U07, U08, U09, U10, U11, U12, U13, U14, U15.

**Данные:** ownership-registry.

**Задачи backend:** T01.1, T01.2. **Задачи frontend:** F07, F08, F09, F10, F11, F12, F13, F14, F15, F16, F17, F18, F19, F20, F21, F22, F23.

**Приёмка backend:** V01. **Приёмка frontend:** V02, V03, V04, V05, V06, V07, V08, V09, V10, V11, V12, V13, V14, V15, V16, V17, V18, V19, V20, V21, V22, V24.



## R02. Изоляция компаний и полномочия



**Компоненты:** B01, B02, B05, file-gateway.

**Экраны:** U01, U02, U08, U09, U10, U14, U15.

**Данные:** Session, Company, ConsentRequirement, Capabilities.

**Задачи backend:** T03.1, T03.2. **Задачи frontend:** F07, F08, F13, F14, F15, F19, F21, F22.

**Приёмка backend:** V02, V03, V04. **Приёмка frontend:** V02, V03, V06, V07, V08, V10, V11, V12, V13, V14, V19, V21, V22.



## R03. Версии, деньги и снимок



**Компоненты:** B03, B04.

**Экраны:** U04, U05, U06, U07, U10.

**Данные:** Application, DraftPatch, Submit, Money.

**Задачи backend:** T02.3, T03.4, T05.1. **Задачи frontend:** F09, F10, F11, F12, F15.

**Приёмка backend:** V05, V06, V07. **Приёмка frontend:** V04, V05, V06, V07, V08, V09, V12, V13, V14.



## R04. Документы и согласия



**Компоненты:** B04, B05, B06.

**Экраны:** U08, U09, U10, U12.

**Данные:** Document, DocumentReference, ConsentRecord, UploadInput.

**Задачи backend:** T04.1, T04.2, T04.3, T04.4, T04.5, T04.6. **Задачи frontend:** F13, F14, F15, F17.

**Приёмка backend:** V08, V09, V10, V11. **Приёмка frontend:** V07, V08, V10, V11, V12, V13, V14, V18, V22.



## R05. Надёжная передача и сверка



**Компоненты:** B04, B07, I01, platform.

**Экраны:** U10, U11, U12, U14.

**Данные:** Operation, CommandReceipt, BankCommand, outbox/inbox.

**Задачи backend:** T02.4, T05.2, T05.3, T05.5. **Задачи frontend:** F15, F16, F17, F19.

**Приёмка backend:** V12, V13, V14, V15, V16. **Приёмка frontend:** V07, V08, V13, V14, V15, V16, V17, V18, V19, V20.



## R06. Уточнения и все исходы



**Компоненты:** B07, B08, X03.

**Экраны:** U11, U12, U13.

**Данные:** InformationItem, InformationDraft, InformationResponse, Decision, CaseSnapshot.

**Задачи backend:** T06.1, T06.2, T06.5. **Задачи frontend:** F16, F17, F18.

**Приёмка backend:** V17, V18. **Приёмка frontend:** V07, V15, V16, V17, V18, V19, V20.



## R07. Принятие и оформление



**Компоненты:** B09, I01, X03, X05.

**Экраны:** U11, U13, U14.

**Данные:** Offer, AcceptOffer, Withdrawal, Operation.

**Задачи backend:** T06.3, T06.4. **Задачи frontend:** F16, F18, F19.

**Приёмка backend:** V19, V20. **Приёмка frontend:** V08, V15, V16, V17, V19, V20.



## R08. Клиентские обновления



**Компоненты:** B08, B01.

**Экраны:** U03, U11, U15.

**Данные:** StatusView, ClientStreamMessage, StreamSnapshot, HistoryPage, InboxItem.

**Задачи backend:** T05.4, T07.3. **Задачи frontend:** F16, F20, F21, F22, F23.

**Приёмка backend:** V21, V22. **Приёмка frontend:** V11, V15, V16, V17, V20, V21, V22, V24.



## R09. Распознавание и модели



**Компоненты:** B06, M01-M05.

**Экраны:** U03, U07, U08, U12.

**Данные:** RiskRequest, RiskResult, Extraction, JobLease, RankingRequest.

**Задачи backend:** T07.1, T07.2, T07.4. **Задачи frontend:** F12, F13, F17, F20, F23.

**Приёмка backend:** V11, V23. **Приёмка frontend:** V04, V06, V07, V10, V11, V12, V13, V18, V20, V24.



## R10. Нагрузка и деградация



**Компоненты:** E01, E02, B01, workers, D01-D03.

**Экраны:** U03, U08, U11.

**Данные:** capacity-model, SLI, queue-age.

**Задачи backend:** T08.2, T02.5. **Задачи frontend:** F13, F16, F20, F23.

**Приёмка backend:** V24, V25. **Приёмка frontend:** V10, V11, V12, V13, V15, V16, V17, V20, V24.



## R11. Защита и восстановление



**Компоненты:** B01, B02, S02, bank-platform.

**Экраны:** U01, U02, U08, U09, U14, U15.

**Данные:** retention-matrix, audit, backup, bank-command-journal.

**Задачи backend:** T08.3, T08.4. **Задачи frontend:** F07, F08, F13, F14, F19, F21, F22.

**Приёмка backend:** V26, V27. **Приёмка frontend:** V02, V03, V06, V08, V10, V11, V12, V13, V14, V19, V21, V22.



## R12. Поставка и последовательность



**Компоненты:** all-package-builders.

**Экраны:** U01, U02, U03, U04, U05, U06, U07, U08, U09, U10, U11, U12, U13, U14, U15.

**Данные:** source-manifest, validation-report, SBOM.

**Задачи backend:** T01.3, T02.1, T02.6, T08.5. **Задачи frontend:** F07, F08, F09, F10, F11, F12, F13, F14, F15, F16, F17, F18, F19, F20, F21, F22, F23.

**Приёмка backend:** V28, V29. **Приёмка frontend:** V02, V03, V04, V05, V06, V07, V08, V09, V10, V11, V12, V13, V14, V15, V16, V17, V18, V19, V20, V21, V22, V24.



## R13. Контекст, протокол и восстановление



**Компоненты:** B01, B02, B04, platform.

**Экраны:** U01, U02, U06, U10, U11, U14.

**Данные:** Session.contextVersion, clearFields, OperationList.

**Задачи backend:** T03.1, T02.3, T02.4. **Задачи frontend:** F07, F08, F11, F15, F16, F19.

**Приёмка backend:** V30, V35, V38. **Приёмка frontend:** V02, V03, V04, V05, V06, V07, V08, V13, V14, V15, V16, V17, V19, V20, V22.



## R14. Версионированные уточнения и файлы



**Компоненты:** B04, B06, B07.

**Экраны:** U07, U08, U10, U12.

**Данные:** InformationDraft, DocumentReference, ConfirmExtraction, ScanResult.

**Задачи backend:** T06.1, T04.3, T04.4, T07.1. **Задачи frontend:** F12, F13, F15, F17.

**Приёмка backend:** V31, V32, V33, V34. **Приёмка frontend:** V04, V06, V07, V08, V10, V11, V12, V13, V14, V18.



## R15. Полный поток и профили



**Компоненты:** B08, I01, Kafka/PostgreSQL transports.

**Экраны:** U03, U08, U11, U15.

**Данные:** CaseSnapshot, stream_event, outbox/inbox.

**Задачи backend:** T05.4, T05.5, T02.6. **Задачи frontend:** F13, F16, F20, F21, F22, F23.

**Приёмка backend:** V36, V37, V39. **Приёмка frontend:** V10, V11, V12, V13, V15, V16, V17, V20, V21, V22, V24.



## R16. Демонстрация и промышленный допуск



**Компоненты:** demo-simulator, bank-platform.

**Экраны:** U01, U11, U14.

**Данные:** DemoAction, DemoOperatorSession, DR-journal.

**Задачи backend:** T06.5, T08.4. **Задачи frontend:** F07, F16, F19.

**Приёмка backend:** V40, V41. **Приёмка frontend:** V02, V08, V15, V16, V17, V19, V20, V22.

