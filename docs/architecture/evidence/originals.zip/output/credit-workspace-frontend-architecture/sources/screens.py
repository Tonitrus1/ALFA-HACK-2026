from pathlib import Path
import json, re
OUT=Path(__file__).resolve().parents[1]
# Each interaction row carries every field required by the implementation matrix.
SCREENS=[
('U01','Вход','/login','Войти тестовым представителем и вернуться к разрешённой странице.','Тестовые аккаунты, текущая сессия и безопасный адрес возврата.','Выбрать аккаунт; войти; повторить после сбоя.','F07','B02','V02 V22',[
('Войти','POST /demo/api/v1/session','Согласованное расширение G01: accountId; Session и cookie; csrfToken только в памяти','401/403: вход не выполнен'),
('Проверить сессию / выйти','GET /api/v1/session; POST /api/v1/logout','Session.expiresAt, companyId; CSRF для выхода','401: окончание сессии')],
'Во время входа кнопка занята. На публичном экране нет сведений о заявках. Объявлена демонстрация; реальный банковский вход не имитируется скрытно.','После входа → U02 или разрешённая сохранённая страница.','Отмена и истечение сессии не оставляют данных прежнего пользователя.'),
('U02','Компания и полномочия','/companies','Явно выбрать организацию, от имени которой работает пользователь.','Разрешённые компании, роли, дата сведений, контекст формы.','Выбрать компанию; просмотреть основание недоступности действия.','F08','B03','V03 V06',[
('Показать компании','GET /api/v1/companies; GET /api/v1/companies/{companyId}','Company.roles, sourceUpdatedAt; cursor/limit','401/403/404; пустой список'),
('Переключить','POST /api/v1/session/company','companyId; новая Session; поколение контекста','403: право отсутствует; 503: перечитать сессию'),
('Объяснить действия','GET /api/v1/companies/{companyId}/capabilities','Согласованное расширение G06: разрешения и безопасные причины','403/404: недоступная компания')],
'Сначала сохранить правки или получить явный отказ от них. Отменить старые запросы и поток; удалить прежний кеш.','→ U03; для сохранённой заявки сначала проверить принадлежность.','Запоздавшие ответы и события прежней компании не видны.'),
('U03','Главная и лента','/home','Показать действующие заявки и важнейшее следующее действие.','Выбранная компания, краткий список заявок, лента, уведомления.','Продолжить заявку; начать диагностику; открыть материал; оценить понятность.','F20 F23','Существующие методы сервера','V20 V24',[
('Показать кабинет','GET /api/v1/applications; GET /api/v1/feed; GET /api/v1/inbox','companyId, cursor; минимум данных; NextAction','401; 503 отдельно для каждого блока'),
('Открыть материал / оценить','GET /api/v1/content/{contentId}; POST /api/v1/feedback','Утверждённый текст и необязательная оценка','404 материала; 422 оценки')],
'Обязательное действие расположено выше материалов. Нет заявок - понятное приглашение начать. Недоступная лента не блокирует кредитный путь.','→ U04, U06-U10 по черновику, U11-U14 по разрешённому действию; статья /content/:id.','Сбой подбора материалов не скрывает заявку и запрос уточнений.'),
('U04','Диагностика потребности','/needs','Собрать минимум данных для подбора.','Цель, сумма, срок и контекст бизнеса; не более пяти основных вопросов.','Ответить; подобрать; изменить; перейти ко всем продуктам.','F09','Существующие методы сервера','V04 V09',[
('Подобрать','POST /api/v1/recommendations','RecommendationInput; суммы Money; версия правил','422 поля; пустой результат; 503 каталог')],
'Значения проверяются в браузере и сервером. Состояния: запрос, нет подходящего варианта, технический сбой. Диагностика ещё не заявка.','→ U05; назад → U03. До создания черновика значения только в памяти текущей сессии.','Пустой подбор отличается от кредитного отказа; нет обещания одобрения.'),
('U05','Продукт и предварительные параметры','/products','Показать подходящий продукт и создать один черновик.','Каталог, версия продукта, результат диагностики.','Изучить; изменить потребность; выбрать продукт и начать заявку.','F10','Существующие методы сервера','V07 V09',[
('Показать продукт','GET /api/v1/products','Product и версия; один синтетический продукт','503; отсутствие подходящего продукта'),
('Создать черновик','POST /api/v1/applications','CreateApplication + Idempotency-Key; Application.applicationId','409 изменён продукт/ключ; 422 параметры')],
'Подпись «Предварительные параметры». Калькулятор не вычисляет обещанную ставку. При изменении каталога требуется подтверждение.','→ U06; изменить потребность → U04.','Двойной клик создаёт один черновик; сравнение нескольких продуктов отложено.'),
('U06','Параметры заявки','/applications/:id/terms','Уточнить цель, сумму и срок с надёжным сохранением.','Application.terms, productVersion, ETag.','Изменить; далее; сохранить и выйти; сравнить конфликт.','F11','Существующие методы сервера','V04 V05 V06',[
('Прочитать / сохранить','GET /api/v1/applications/{applicationId}; PATCH /api/v1/applications/{applicationId}','DraftPatch; If-Match сильного ETag; новый ETag','409 конфликт; 428 нет версии; 422 поля')],
'Автосохранение 800 мс и очередь; неизвестное значение не ноль; рубли преобразуются в целые копейки. После отправки - просмотр.','→ U07 после подтверждения сохранения; выход → U03.','Ввод во время PATCH сохраняется следующим запросом; конфликт не затирает поля.'),
('U07','Сведения о бизнесе','/applications/:id/business','Заполнить сведения и подтвердить перенесённые значения.','Business, Company.sourceUpdatedAt, извлечённые поля с источником.','Исправить; подтвердить; далее; сохранить и выйти.','F12','Существующие методы сервера','V04 V06 V12',[
('Прочитать / сохранить','GET /api/v1/companies/{companyId}; GET /api/v1/applications/{applicationId}; PATCH /api/v1/applications/{applicationId}','Business в DraftPatch; sourceConfirmationVersion; If-Match; clearFields для явной очистки','409; 422 межполевая ошибка'),
('Подтвердить извлечение','POST /api/v1/applications/{applicationId}/confirm-extraction','extractionId, documentVersion, objectVersion, confirmedFields; If-Match и Idempotency-Key','409 устаревшее извлечение; 422')],
'Источник недоступен - показать дату старых сведений и допустимый ручной путь. Пользовательские исправления не переписывают банковский реестр.','→ U08; назад → U06 с сохранением.','Неподтверждённая распознанная сумма не подменяет введённую.'),
('U08','Документы','/applications/:id/documents','Загрузить требуемые документы и увидеть отдельные стадии обработки.','Перечень требований, Document, UploadIntent, Extraction.','Добавить; отменить; заменить; повторить; подтвердить извлечение; скачать.','F13','B04 B05','V10 V11 V12 V13',[
('Требования и список','GET /api/v1/applications/{applicationId}/document-requirements; GET /api/v1/applications/{applicationId}/documents','Согласованное расширение G03 для требований; requirementId и версия','404; 503; пустой список'),
('Разрешить / передать','POST /api/v1/applications/{applicationId}/documents/upload-intents; PUT /api/v1/files/uploads/{transferId}','UploadInput; G05 для замены; X-Upload-Grant, CSRF, X-Company-Context; Idempotency-Key для intent; 204 = карантин','413/415; истёкшее разрешение; сетевой обрыв'),
('Отменить','DELETE /api/v1/uploads/{uploadId}','Согласованное расширение G04; отзыв разрешения; затем читать документ','409 завершение уже произошло'),
('Проверить обработку','GET /api/v1/documents/{documentId}; GET /api/v1/documents/{documentId}/extraction; POST /api/v1/applications/{applicationId}/confirm-extraction','Раздельные scanState/extractionState; точные версии','409 новая версия; распознавание FAILED'),
('Скачать','POST /api/v1/documents/{documentId}/download-intents; GET /api/v1/files/downloads/{transferId}','DownloadIntent; X-Download-Grant; краткоживущий Blob URL','403/404/503')],
'100% передачи не означает CLEAN. До проверки нет скачивания и отправки обязательного файла. Низкая уверенность - ручное подтверждение.','→ U09; из уточнения вернуться в U12 с тем же requestId.','Прерывание, отмена и замена согласуются с серверным состоянием.'),
('U09','Согласия','/applications/:id/consents','Отдельно подтвердить применимые цели обработки.','Требования согласий, субъект, actorMayConsent, textVersion.','Открыть текст; дать согласие; посмотреть историю; отозвать разрешённое.','F14','Существующие методы сервера','V14 V22',[
('Прочитать требования / факты','GET /api/v1/applications/{applicationId}/consent-requirements; GET /api/v1/applications/{applicationId}/consents','ConsentRequirement, ConsentRecord; цель и версия текста','403; текст изменён'),
('Дать / отозвать','POST /api/v1/applications/{applicationId}/consents; POST /api/v1/consents/{consentId}/revocation','Idempotency-Key, CSRF; субъект не назначает полномочие','409/422; нет права субъекта')],
'Маркетинг не обязателен и не предвыбран. Представительство компании не означает согласие любого физического лица.','→ U10; назад → U08.','Обновлённый текст требует нового подтверждения; отказ не теряет черновик.'),
('U10','Проверка и отправка','/applications/:id/review','Проверить пакет и безопасно передать команду.','Последняя сохранённая версия анкеты, документы и согласия.','Исправить секцию; сохранить и выйти; отправить один раз.','F15','B09','V07 V08 V13 V14',[
('Перечитать пакет','GET /api/v1/applications/{applicationId}; GET /api/v1/applications/{applicationId}/documents; GET /api/v1/applications/{applicationId}/consent-requirements','Версия заявки, CLEAN-версии документов, версии согласий','409/422; недоступность чтения'),
('Отправить','POST /api/v1/applications/{applicationId}/submit','Submit.expectedVersion по исходной схеме; Submit.documentIds, documentReferences, requirementsVersion; Idempotency-Key; 202 Location','409/428/422/429/503; неизвестный результат'),
('Найти результат','GET /api/v1/operations/lookup; GET /api/v1/operations/{operationId}','Согласованное расширение G09 для поиска по прежнему ключу; Operation','404 поиска ещё не разрешает новую команду')],
'Дождаться последней записи; зафиксировать тело команды. 202 - принятие кабинетом, не банком и не одобрение.','→ U11; ошибки ведут к конкретной секции.','Потерянный ответ не создаёт повторную заявку и ложный успех.'),
('U11','Статус и следующее действие','/applications/:id','Показать подтверждённый этап и необходимое действие.','StatusView, nextAction, stale, история и активные операции.','Обновить; перейти к уточнению/условиям; отозвать разрешённое.','F16','B07 B09','V15 V16 V17 V20',[
('Прочитать статус / поток','GET /api/v1/applications/{applicationId}/status; GET /api/v1/events/snapshot; GET /api/v1/events','viewVersion, streamCursor; Last-Event-ID; G10 вид ресурса','resync_required; 401/429/503'),
('Отозвать','POST /api/v1/applications/{applicationId}/withdrawal','Withdrawal и Idempotency-Key; 202 Operation','409 недопустим переход; неопределённый результат')],
'Задержка обновления не отказ. Показывать дату и «От вас сейчас ничего не требуется», если nextAction=WAIT.','→ U12, U13, U14, U15 по проверенному действию.','Разрыв потока восстанавливается; старое событие не откатывает состояние.'),
('U12','Ответ на запрос уточнений','/applications/:id/requests/:requestId','Дополнить прежнюю заявку только запрошенными данными.','InformationRequest.version, пункты, deadline и отдельный черновик ответа.','Сохранить; добавить документ; исправить разрешённое поле; отправить ответ.','F17','B06','V18 V07',[
('Прочитать запрос / черновик','GET /api/v1/applications/{applicationId}/information-requests; GET /api/v1/applications/{applicationId}/information-requests/{requestId}/draft','Согласованное расширение G02 для черновика; requestVersion; ETag','409 запрос заменён; 404'),
('Сохранить черновик','PATCH /api/v1/applications/{applicationId}/information-requests/{requestId}/draft','Согласованное расширение G02; If-Match; amendment и documentReferences','409/428/422'),
('Отправить ответ','POST /api/v1/applications/{applicationId}/information-requests/{requestId}/responses','requestVersion, draftVersion, requirementsVersion, documentIds, documentReferences, Idempotency-Key; 202','409 закрыт запрос; 422 пакет; потерян ответ')],
'Не открывать исходную анкету для редактирования. Новый запрос требует пересмотра. Дедлайн не создаёт локальный банковский отказ.','Документы → U08 в контексте запроса; после отправки → U11.','Перезагрузка сохраняет подтверждённый черновик; новая заявка не создаётся.'),
('U13','Решение и условия','/applications/:id/decision','Различить исходы и показать актуальные условия.','Decision, Offer, offerVersion, срок действия, запрошенные условия.','Изучить; сравнить; перейти к оформлению; изменить потребность.','F18','Существующие методы сервера','V19 V20',[
('Показать решение / предложение','GET /api/v1/applications/{applicationId}/decision; GET /api/v1/offers/{offerId}','Разрешённое объяснение; версия и validUntil','404 решения ещё нет → статус; 409 новое предложение')],
'Ветки: одобрено, другие условия, нужны сведения, отказ. Внутренние оценки риска не показывать. Срок проверяется сервером.','→ U14, U12 или U04 осознанно; ожидание → U11.','Другие условия сопоставимы с запрошенными; устаревшие не принимаются.'),
('U14','Моделирование оформления','/applications/:id/acceptance','Подтвердить условия без ложной юридической подписи.','Актуальное предложение, документы, права подписанта, Operation.','Открыть документы; принять; наблюдать результат; смоделировать завершение через панель.','F19','B09 B10','V19 V08',[
('Принять условия','GET /api/v1/offers/{offerId}; POST /api/v1/offers/{offerId}/acceptance','AcceptOffer.offerVersion, Idempotency-Key; 202','409 изменено/истекло; 403 полномочие'),
('Проверить результат','GET /api/v1/operations/{operationId}; GET /api/v1/applications/{applicationId}/status','PENDING/RECONCILING/FAILED/SUCCEEDED; COMPLETED отдельно','Неизвестный результат не разрешает повторное оформление')],
'Явная надпись о демонстрации; деньги не перечисляются. Успех операции принятия не равен завершённой выдаче.','→ U11/U15; изменение условий → U13.','COMPLETED только после события имитатора; повтор не создаёт второе оформление.'),
('U15','История, документы и уведомления','/history; /documents; /inbox','Найти заявку, доступный документ или сообщение выбранной компании.','Списки с limit/cursor, краткие карточки и доступные ссылки.','Фильтровать; открыть; скачать; отметить прочитанным.','F21 F22','B08','V21 V11 V22',[
('Список / история','GET /api/v1/applications; GET /api/v1/applications/{applicationId}/history','Согласованное расширение G08 для полной истории; cursor; удаление повторов по id','400 чужой курсор; 404; 503'),
('Документы','GET /api/v1/applications/{applicationId}/documents; POST /api/v1/documents/{documentId}/download-intents; GET /api/v1/files/downloads/{transferId}','На странице /documents сначала выбрать заявку; X-Download-Grant','403/404; удалённый документ'),
('Уведомления','GET /api/v1/inbox; POST /api/v1/inbox/{notificationId}/read','companyId/cursor; безопасный внутренний targetPath','404 устаревшая ссылка; ошибка прочтения')],
'Пустой список не ошибка. Отметка прочтения не меняет кредитное рассмотрение. Нет обещания бессрочной доступности файла.','→ U11/U12/U13 по актуальному разрешённому действию.','Архив не смешивает компании; документы всего кабинета не скачиваются заранее.')]
def write():
 # Complete manager-driven interactions as explicit screen dependencies.
 for index,row in enumerate(SCREENS):
  row=list(row);interactions=list(row[9])
  if row[0]=='U01':interactions.insert(0,('Выбрать тестовый аккаунт','GET /demo/api/v1/accounts','Только фиксированные синтетические аккаунты demo-профиля','404 вне demo'))
  if row[0]=='U08':interactions.append(('Подтвердить OCR в уточнении','POST /api/v1/applications/{applicationId}/information-requests/{requestId}/draft/confirm-extraction','If-Match черновика ответа, Idempotency-Key, ConfirmExtraction; исходная анкета неизменна','409 закрыт запрос/устарел источник; 428'))
  if row[0]=='U11':interactions.append(('Восстановить команды и доступные действия','GET /api/v1/operations; GET /api/v1/applications/{applicationId}/capabilities','Все активные и недавние завершённые операции; applicationId, limit/cursor; разрешения — только подсказка','401/403/404/409 контекст'))
  row[9]=interactions;SCREENS[index]=tuple(row)
 rows=[];doc='# 4. Экраны и критерии готовности\n\nСохраняем обозначения U01-U15 исходного пакета. Это функциональная спецификация и привязка к реализации; исходные схемы компоновки переиспользуются как ориентир, без нового полного дизайн-проекта. Расширения G01-G10 приняты в контракт 1.2.0-design; это спецификация будущей реализации. Подробные дополнения - глава 5.\n\n'
 for id,title,path,goal,inputs,actions,tasks,backend,tests,interactions,states,transitions,accept in SCREENS:
  doc+=f'## {id}. {title}\n\n**Маршрут:** `{path}`.\n\n**Назначение:** {goal}\n\n**Входные данные:** {inputs}\n\n**Действия:** {actions}\n\n**Правила и состояния:** {states}\n\n**Переходы:** {transitions}\n\n'
  for action,api,data,errors in interactions:
   doc+=f'### {action}\n\n**Методы:** `{api}`.\n\n**Данные и версии:** {data}.\n\n**Ошибки:** {errors}.\n\n'
   rows.append(dict(screen=id,action=action,api=api,dataAndVersions=data+'; обязательные заголовки и тело — по api/baseline-openapi.json (demo — api/demo-openapi.json); X-Company-Context для выбранной компании',errors=errors,frontendTasks=tasks.split(),backendDependency=backend,tests=tests.split()))
  doc+=f'**Задачи:** {tasks}. **Серверная зависимость:** {backend}. **Проверки:** {tests}.\n\n**Критерий готовности:** {accept}\n\n'
 doc+='## C02. Панель управления демонстрацией\n\nМаршрут /demo/control присутствует только в demo и demo-integrated. Это отдельная страница с выбором искусственной заявки, текущей версией банковского дела, кнопками разрешённых исходов и журналом действий. Она не входит в клиентскую навигацию. Задача F24; серверная зависимость B10; проверки V25/V28. Полные переходы и ограничения - глава 6.\n'
 (OUT/'docs/04-screens.md').write_text(doc)
 (OUT/'interaction-matrix.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 # Compact lookup in addition to the full eight-field matrix above.
 text='# Указатель взаимодействий\n\nПолная восьмиполевая матрица - interaction-matrix.json; человекочитаемая версия с теми же полями - глава 4 руководства.\n\n| Экран | Действие | Задачи | Проверки |\n| --- | --- | --- | --- |\n'
 for r in rows:text+=f"| {r['screen']} | {r['action']} | {', '.join(r['frontendTasks'])} | {', '.join(r['tests'])} |\n"
 (OUT/'docs/interaction-index.md').write_text(text)
 return rows
if __name__=='__main__':write()
