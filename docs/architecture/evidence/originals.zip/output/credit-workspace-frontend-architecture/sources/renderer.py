from pathlib import Path
import html,re
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, CondPageBreak, Table, TableStyle, KeepTogether, Preformatted
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from diagram_engine import FONT_DIR
INK=colors.HexColor('#182839'); MUTED=colors.HexColor('#586a7b'); BLUE=colors.HexColor('#315b93')
pdfmetrics.registerFont(TTFont('DV-M',str(FONT_DIR/'DejaVuSansMono.ttf')))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-B',italic='DV',boldItalic='DV-B')
from markdown_it import MarkdownIt
styles={
 'body':ParagraphStyle('body',fontName='DV',fontSize=9.3,leading=13.4,spaceAfter=7,textColor=INK,splitLongWords=True),
 'h1':ParagraphStyle('h1',fontName='DV-B',fontSize=20,leading=25,spaceAfter=16,textColor=BLUE,keepWithNext=True),
 'h2':ParagraphStyle('h2',fontName='DV-B',fontSize=13,leading=18,spaceBefore=11,spaceAfter=7,textColor=INK,keepWithNext=True),
 'h3':ParagraphStyle('h3',fontName='DV-B',fontSize=10.5,leading=15,spaceBefore=10,spaceAfter=6,textColor=BLUE,keepWithNext=True),
 'cell':ParagraphStyle('cell',fontName='DV',fontSize=8,leading=11,spaceAfter=0,textColor=INK,splitLongWords=True),
 'thead':ParagraphStyle('thead',fontName='DV-B',fontSize=8,leading=11,spaceAfter=0,textColor=colors.white),
 'small':ParagraphStyle('small',fontName='DV',fontSize=8,leading=11,textColor=MUTED),
 'cover':ParagraphStyle('cover',fontName='DV-B',fontSize=31,leading=39,textColor=INK,spaceAfter=20),
 'subtitle':ParagraphStyle('subtitle',fontName='DV',fontSize=15,leading=22,textColor=MUTED,spaceAfter=18)}

def inline(token):
    result=[]
    for t in token.children or []:
        if t.type=='text':result.append(html.escape(t.content))
        elif t.type=='code_inline':result.append('<font name="DV-M">'+html.escape(t.content)+'</font>')
        elif t.type=='strong_open':result.append('<b>')
        elif t.type=='strong_close':result.append('</b>')
        elif t.type=='em_open':result.append('<i>')
        elif t.type=='em_close':result.append('</i>')
        elif t.type=='link_open':result.append('<a color="#315b93" href="'+html.escape(t.attrGet('href') or '',quote=True)+'">')
        elif t.type=='link_close':result.append('</a>')
        elif t.type in ['softbreak','hardbreak']:result.append('<br/>')
        else:result.append(html.escape(t.content))
    return ''.join(result)

def markdown_flow(text):
    tokens=MarkdownIt('commonmark').enable('table').parse(text)
    result=[];i=0;lists=[];item=False
    while i<len(tokens):
        t=tokens[i]
        if t.type=='heading_open':
            level=int(t.tag[1:]);body=inline(tokens[i+1]);p=Paragraph(body,styles.get('h'+str(level),styles['h3']))
            p.toc_level=0 if level==1 else None;p.toc_title=tokens[i+1].content
            result.append(p);i+=3;continue
        if t.type in ['bullet_list_open','ordered_list_open']:lists.append({'kind':t.type,'counter':0});i+=1;continue
        if t.type in ['bullet_list_close','ordered_list_close']:lists.pop();i+=1;continue
        if t.type=='list_item_open':
            item=True
            if lists:lists[-1]['counter']+=1
            i+=1;continue
        if t.type=='paragraph_open':
            body=inline(tokens[i+1]);style=styles['body']
            if lists:
                style=ParagraphStyle('bullet',parent=style,leftIndent=14*len(lists),firstLineIndent=-10)
                prefix=(str(lists[-1]['counter'])+'. ') if lists[-1]['kind']=='ordered_list_open' else '• '
                body=prefix+body if item else body;item=False
            result.append(Paragraph(body,style));i+=3;continue
        if t.type=='table_open':
            rows=[];row=[];heads=[];j=i+1;ishead=False
            while tokens[j].type!='table_close':
                q=tokens[j]
                if q.type=='thead_open':ishead=True
                if q.type=='thead_close':ishead=False
                if q.type=='tr_open':row=[]
                if q.type in ['th_open','td_open']:row.append(Paragraph(inline(tokens[j+1]),styles['thead'] if ishead else styles['cell']))
                if q.type=='tr_close':rows.append(row)
                j+=1
            count=len(rows[0]);width=A4[0]-88
            ratios={2:[.32,.68],3:[.27,.30,.43],4:[.31,.15,.32,.22]}.get(count,[1/count]*count)
            tbl=Table(rows,colWidths=[width*r for r in ratios],repeatRows=1,hAlign='LEFT')
            tbl.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f1f5fa'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.7,BLUE),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#dbe3eb'))]))
            result+=[tbl,Spacer(1,10)];i=j+1;continue
        if t.type=='fence':result.append(Preformatted(t.content,ParagraphStyle('code',parent=styles['small'],fontName='DV-M',fontSize=7.5,leading=10)))
        i+=1
    grouped=[];i=0
    while i<len(result):
        title=getattr(result[i],'toc_title','')
        if re.match(r'^([FB]\d{2}|V\d{2})\.',title):
            group=[result[i]];i+=1
            while i<len(result) and not hasattr(result[i],'toc_title'):
                group.append(result[i]);i+=1
            grouped.append(KeepTogether(group))
        else:grouped.append(result[i]);i+=1
    finished=[];i=0
    while i<len(grouped):
        if getattr(grouped[i],'toc_title','').startswith('Этап ') and i+1<len(grouped) and isinstance(grouped[i+1],KeepTogether):
            finished.append(KeepTogether([grouped[i]]+grouped[i+1]._content));i+=2
        else:finished.append(grouped[i]);i+=1
    return finished

class Guide(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(str(path),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=49,bottomMargin=43,title='Кредитный кабинет: руководство по разработке фронтенда',author='Архитектурный пакет проекта')
        self.addPageTemplates(PageTemplate(id='normal',frames=[Frame(44,43,A4[0]-88,A4[1]-92,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=self.decorate))
        self.heading_counter=0
    def beforeDocument(self):
        self.heading_counter=0
    def decorate(self,canv,doc):
        canv.saveState();canv.setStrokeColor(colors.HexColor('#d9e2ec'));canv.line(44,A4[1]-31,A4[0]-44,A4[1]-31)
        canv.setFont('DV',7);canv.setFillColor(MUTED);canv.drawString(44,A4[1]-23,'КРЕДИТНЫЙ КАБИНЕТ  /  АРХИТЕКТУРА ФРОНТЕНДА')
        canv.drawString(44,23,'Архитектура для реализации  •  20.10.2026');canv.drawRightString(A4[0]-44,23,str(doc.page));canv.restoreState()
    def afterFlowable(self,f):
        if getattr(f,'toc_level',None) is not None:
            key='heading-'+str(self.heading_counter);self.heading_counter+=1
            self.canv.bookmarkPage(key);self.notify('TOCEntry',(f.toc_level,html.escape(f.toc_title),self.page,key))
