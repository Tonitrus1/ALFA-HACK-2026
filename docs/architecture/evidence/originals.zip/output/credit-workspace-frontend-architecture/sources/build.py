"""Build only architecture deliverables. Does not implement the credit application."""
from pathlib import Path
import sys,os,json,re,hashlib,xml.etree.ElementTree as ET,zipfile,copy
# Optional local dependency directory; no hard dependency on the original generators.
extra=os.environ.get('CREDIT_RENDER_DEPS')
if extra:sys.path.insert(0,extra)
from pypdf import PdfReader,PdfWriter,PageObject,Transformation
from reportlab.lib.pagesizes import A3,landscape
from reportlab.platypus import Paragraph,Spacer,PageBreak,KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus.tableofcontents import TableOfContents
from PIL import Image,ImageOps,ImageDraw
import pypdfium2 as pdfium
from openapi_spec_validator import validate as validate_openapi
from diagram_engine import OUT,ROOT,render_board
from diagrams import populate
from renderer import Guide,styles,markdown_flow
from contracts import write as write_contracts
from screens import write as write_screens,SCREENS
from workplan import write as write_tasks,TASKS,TESTS
TMP=ROOT/'tmp/frontend-pdfs'

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verify_sources():
 manifest=json.loads((OUT/'source-manifest.json').read_text())
 return all((ROOT/p).is_file() and digest(ROOT/p)==h for p,h in manifest['files'].items())
def diagrams():
 boards=populate();writer=PdfWriter();mx=ET.Element('mxfile',host='app.diagrams.net',version='24.7.17',compressed='false');manifest=[]
 for b in boards:
  b.footer();model=render_board(b);ET.SubElement(mx,'diagram',id=b.slug,name=b.title).append(model)
  raw=PdfReader(str(TMP/f'{b.slug}.pdf')).pages[0];w,h=landscape(A3)
  page=PageObject.create_blank_page(width=w,height=h);scale=min(w/b.w,h/b.h)
  page.merge_transformed_page(raw,Transformation().scale(scale).translate((w-b.w*scale)/2,(h-b.h*scale)/2));writer.add_page(page)
  manifest.append(dict(id=b.slug,title=b.title,page=len(manifest)+1,width=b.w,height=b.h,nodes=sum(s['kind']=='node' for s in b.shapes),edges=sum(s['kind']=='edge' for s in b.shapes)))
 writer.add_metadata({'/Title':'Кредитный кабинет: атлас архитектуры фронтенда','/Author':'Архитектурный комплект проекта'})
 with (OUT/'frontend-architecture-atlas.pdf').open('wb') as f:writer.write(f)
 ET.ElementTree(mx).write(OUT/'frontend-architecture.drawio',encoding='utf-8',xml_declaration=True)
 (OUT/'diagram-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 return boards

def guide():
 fcount=sum(t['owner']=='Фронтенд' for t in TASKS);bcount=len(TASKS)-fcount
 story=[Spacer(1,60),Paragraph('Кредитный<br/>кабинет',styles['cover']),Paragraph('Архитектура фронтенда<br/>и понятный план разработки',styles['subtitle']),Spacer(1,20),Paragraph('От экранов и данных<br/>к безопасным действиям и повторяемому показу',styles['h2']),Spacer(1,22),Paragraph(f'12 схем · 15 экранов · {fcount} задач фронтенда<br/>{bcount} серверных задач · {len(TESTS)} сценариев приёмки',styles['subtitle']),Spacer(1,24),Paragraph('React · TypeScript · Vite<br/>Самостоятельная демонстрация и локальный сервер',styles['body']),Spacer(1,35),Paragraph('20 октября 2026 года. Проектная документация для команды. Искусственные данные и моделируемое оформление. Приложение в рамках подготовки этого комплекта не разрабатывалось.',styles['small']),PageBreak(),Paragraph('Содержание',styles['h1'])]
 toc=TableOfContents();toc.levelStyles=[ParagraphStyle('toc0',fontName='DV-B',fontSize=10,leading=15,spaceBefore=9)]
 story+=[toc,Spacer(1,24),Paragraph('Как читать схемы',styles['h2']),Paragraph('Нумерация листов совпадает с отдельным атласом. Синий обозначает действия и модули, серый - сервер и банк, зелёный - данные, оранжевый - проверки. Сплошные стрелки показывают действия, пунктир - отложенное обновление. Смысл продублирован в подписях.',styles['body'])]
 for p in sorted((OUT/'docs').glob('[0-9][0-9]-*.md')):
  story.append(PageBreak());story+=markdown_flow(p.read_text())
 Guide(OUT/'frontend-development-guide.pdf').multiBuild(story)

def previews():
 manifest=json.loads((OUT/'diagram-manifest.json').read_text());atlas=pdfium.PdfDocument(str(OUT/'frontend-architecture-atlas.pdf'))
 imgs=[]
 for i,p in enumerate(atlas):
  img=p.render(scale=1700/p.get_width()).to_pil().convert('RGB');img.save(OUT/'png'/f'{manifest[i]["id"]}.png');imgs.append(img)
 sheet=Image.new('RGB',(1800,4*410),'#e8edf3');d=ImageDraw.Draw(sheet)
 for i,img in enumerate(imgs):
  thumb=ImageOps.contain(img,(580,370));x=10+(i%3)*600;y=10+(i//3)*410;sheet.paste(thumb,(x,y));d.text((x+5,y+375),str(i+1),fill='black')
 sheet.save(OUT/'preview.png')
 pdf=pdfium.PdfDocument(str(OUT/'frontend-development-guide.pdf'));files=[]
 for i,p in enumerate(pdf):
  img=p.render(scale=1.45).to_pil().convert('RGB');file=TMP/f'guide-{i+1:03d}.png';img.save(file);files.append(file)
 for start in range(0,len(files),6):
  sheet=Image.new('RGB',(1800,1700),'#e5eaf0');d=ImageDraw.Draw(sheet)
  for k,file in enumerate(files[start:start+6]):
   img=Image.open(file);thumb=ImageOps.contain(img,(570,805));x=15+(k%3)*600;y=12+(k//3)*850;sheet.paste(thumb,(x,y));d.text((x+6,y+810),'Page '+str(start+k+1),fill='black')
  sheet.save(TMP/f'guide-contact-{start//6+1:02d}.png')
 return len(pdf)

def metadata(matrix,proposal):
 trace=[]
 for id,title,*rest in SCREENS:
  rr=[r for r in matrix if r['screen']==id]
  trace.append(dict(screen=id,title=title,tasks=sorted(set(x for r in rr for x in r['frontendTasks'])),tests=sorted(set(x for r in rr for x in r['tests'])),interactions=len(rr),diagrams=['02-journey','03-modules','04-state']+({'U06':['05-save'],'U07':['05-save'],'U08':['07-documents'],'U10':['06-submit'],'U11':['08-updates'],'U12':['09-followups'],'U13':['09-followups'],'U14':['09-followups']}.get(id,[]))))
 (OUT/'traceability.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2))
 # Correlate every base operation with screens in the full matrix.
 cat=json.loads((OUT/'api/baseline-operation-catalog.json').read_text())
 for entry in cat:
  exact=entry['method']+' '+entry['path'];entry['screens']=sorted(set(r['screen'] for r in matrix if exact in r['api']))
  if not entry['screens']:
   entry['usage']='Общий менеджер операций/действий; детальная привязка в главе 3 и исходном серверном контракте'
 (OUT/'api/baseline-operation-catalog.json').write_text(json.dumps(cat,ensure_ascii=False,indent=2))

def validate(boards,matrix,proposal):
 checks=[]
 def ck(name,passed,detail=''):
  checks.append(dict(check=name,passed=bool(passed),detail=detail))
  if not passed:raise AssertionError(name+': '+detail)
 ck('Контрольные суммы актуальных входных файлов совпадают',verify_sources())
 ck('Копия исходного OpenAPI совпадает',digest(OUT/'api/baseline-openapi.json')==digest(ROOT/'output/credit-workspace-backend-architecture/api/openapi.json'))
 validate_openapi(json.loads((OUT/'api/baseline-openapi.json').read_text()));ck('Базовый OpenAPI проходит валидатор',True)
 validate_openapi(proposal);ck('Предложенный OpenAPI проходит валидатор',True)
 import warnings
 from jsonschema import Draft4Validator,FormatChecker
 with warnings.catch_warnings():
  warnings.simplefilter('ignore',DeprecationWarning)
  from jsonschema import RefResolver
  resolver=RefResolver.from_schema(proposal)
 examples=json.loads((OUT/'api/proposal-examples.json').read_text())
 for ex in examples:
  validator=Draft4Validator(proposal['components']['schemas'][ex['schema']],resolver=resolver,format_checker=FormatChecker())
  ck('Пример соответствует схеме '+ex['schema'],validator.is_valid(ex['value']),str(list(validator.iter_errors(ex['value']))[:1]))
 invalid={'eventType':'view_changed','cursor':'x','companyId':'company-a','contextVersion':1}
 ck('Изменение без ресурса отклонено',not Draft4Validator(proposal['components']['schemas']['ClientStreamMessage'],resolver=resolver).is_valid(invalid))
 invalid=copy.deepcopy(examples[-1]['value']);invalid.pop('expectedDocumentVersion')
 ck('Неполная пара замены файла отклонена',not Draft4Validator(proposal['components']['schemas']['UploadInput'],resolver=resolver).is_valid(invalid))

 ck('Все 15 экранов раскрыты',set(r['screen'] for r in matrix)=={f'U{i:02d}' for i in range(1,16)})
 tids={t['id'] for t in TASKS};vids={x[0] for x in TESTS}
 ck('Ссылки матрицы на задачи и проверки корректны',all(set(r['frontendTasks'])<=tids and set(r['tests'])<=vids for r in matrix))
 ck('У каждого действия восемь заполненных полей',all(len(r)==8 and all(r.values()) for r in matrix))
 visited=set();active=set();by={t['id']:t for t in TASKS}
 def walk(id):
  ck('Задача существует '+id,id in by)
  if id in active:raise AssertionError('Цикл '+id)
  if id in visited:return
  active.add(id)
  for d in by[id]['dependencies']:walk(d)
  active.remove(id);visited.add(id)
 for id in by:walk(id)
 ck('Все задачи достижимы, циклов нет',len(visited)==len(TASKS))
 ck('Проверки задач существуют',all(set(t['tests'])<=vids for t in TASKS))
 orig_tasks={t['id'] for t in json.loads((ROOT/'output/credit-workspace-backend-architecture/tasks.json').read_text())}
 ck('Ссылки на исходные серверные задачи существуют',all(set(t['existingBackendTasks'])<=orig_tasks for t in TASKS))
 ck('12 схем и 12 страниц атласа',len(boards)==12 and len(PdfReader(OUT/'frontend-architecture-atlas.pdf').pages)==12)
 draw=ET.parse(OUT/'frontend-architecture.drawio').getroot();ck('12 редактируемых листов',len(draw.findall('diagram'))==12)
 for d in draw.findall('diagram'):
  cells=d.findall('.//mxCell');ids=[c.get('id') for c in cells]
  ck('Уникальные элементы '+d.get('id'),len(ids)==len(set(ids)))
  ck('Стрелки связаны с блоками '+d.get('id'),all(c.get('source') and c.get('target') for c in d.findall('.//mxCell[@edge="1"]')))
  ck('Отдельные блоки и стрелки '+d.get('id'),len(d.findall('.//mxCell[@vertex="1"]'))>=6 and len(d.findall('.//mxCell[@edge="1"]'))>=2)
 for b in boards:
  ET.parse(OUT/'svg'/f'{b.slug}.svg')
  nodes=[s for s in b.shapes if s['kind']=='node']
  for s in nodes:ck('Блок в границах '+b.slug+'/'+s['id'],s['x']>=0 and s['y']>=0 and s['x']+s['w']<=b.w and s['y']+s['h']<=b.h)
  for i,s in enumerate(nodes):
   for t in nodes[i+1:]:
    overlap=min(s['x']+s['w'],t['x']+t['w'])>max(s['x'],t['x']) and min(s['y']+s['h'],t['y']+t['h'])>max(s['y'],t['y'])
    ck('Блоки не перекрываются '+b.slug+'/'+s['id']+'/'+t['id'],not overlap)
 sizes={}
 for name in ['frontend-development-guide.pdf','frontend-architecture-atlas.pdf']:
  pdf=PdfReader(OUT/name);sizes[name]=len(pdf.pages)
  ck('Кириллица на всех страницах '+name,all(re.search('[А-Яа-я]',p.extract_text() or '') for p in pdf.pages))
  ck('Нет пустых страниц '+name,all(len((p.extract_text() or '').strip())>100 for p in pdf.pages))
  if name.startswith('frontend-development'):ck('Нет страниц с единичными строками',all(len((p.extract_text() or '').strip())>500 for p in pdf.pages))
 guide_text='\n'.join(p.extract_text() or '' for p in PdfReader(OUT/'frontend-development-guide.pdf').pages)
 ck('Все экраны в PDF',all(id+'.' in guide_text for id,*_ in SCREENS))
 ck('Все задачи и проверки в PDF',all(t['id']+'.' in guide_text for t in TASKS) and all(v[0]+'.' in guide_text for v in TESTS))
 ck('Все 10 пробелов раскрыты',all(f'G{i:02d}.' in guide_text for i in range(1,11)))
 # Match every method/path in matrix to a real base operation or an explicit proposal.
 for r in matrix:
  for segment in r['api'].split('; '):
   method,path=segment.split(' ',1)
   ck('Метод матрицы существует '+method+' '+path,path in proposal['paths'] and method.lower() in proposal['paths'][path])
 report=dict(status='passed',date='2026-10-20',scope='Проверка проектных материалов. Приложение не реализовывалось и не испытывалось.',counts=dict(diagrams=12,screens=15,frontendTasks=sum(t['owner']=='Фронтенд' for t in TASKS),backendTasks=sum(t['owner']=='Сервер' for t in TASKS),acceptanceCases=len(TESTS),interactionRows=len(matrix),baseOperations=49,newOperations=sum(c['kind']=='new-operation' for c in json.loads((OUT/'api/changes.json').read_text())),pdfPages=sizes),checks=checks,visualReview='pending')
 (OUT/'validation-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 return report

def readme():
 (OUT/'README.md').write_text('''# Кредитный кабинет: архитектура фронтенда

20 октября 2026 года. 12 схем, 15 экранов, 30 задач фронтенда, 11 серверных задач и 38 сценариев приёмки будущего прототипа. Проектная документация: приложение не разрабатывалось.

## С чего начать

1. frontend-architecture-atlas.pdf - 12 векторных листов A3.
2. frontend-development-guide.pdf - руководство: от устройства приложения до задач и проверок.
3. frontend-architecture.drawio - исходные блоки и стрелки для редактирования.

svg/ и png/ содержат отдельные схемы; preview.png - общий обзор. docs/ - редактируемая документация Markdown. tasks.json, interaction-matrix.json, acceptance-cases.json и traceability.json связывают экраны, задачи и проверки.

api/baseline-openapi.json - неизменённая копия серверного контракта. api/demo-openapi.json - отдельный demo-контракт. api/proposed-additions.openapi.json - объединённая согласованная редакция с согласованными публичными и demo-операциями; имя файла сохранено для старых ссылок, реализация не выполнена. Отличия перечислены в api/changes.json; исходный серверный файл не изменён. api/backend-task-map.json связывает необходимые серверные работы с исходным планом.

Демонстрация предполагает искусственные данные, один продукт и два режима: имитацию в браузере и локальный сервер. Панель оператора допускается только в демонстрационной конфигурации. Промышленный банковский запуск не входит в оценку прототипа.

## Повторная сборка

В отдельной Python-среде установите sources/requirements-render.txt. Укажите CREDIT_FONT_DIR с DejaVuSans.ttf, DejaVuSans-Bold.ttf, DejaVuSansMono.ttf. При вынесенных пакетах используйте CREDIT_RENDER_DEPS. Запустите sources/build.py из любой папки, сохранив расположение соседних двух исходных архитектурных пакетов. Сборка проверяет их контрольные суммы и не меняет их.

Временные страницы проверки создаются в tmp/frontend-pdfs относительно корня рабочего проекта. После автоматической сборки визуальный статус намеренно pending: проверяющий просматривает все листы и страницы, фиксирует результат в validation-report.json и заново упаковывает комплект. Это не автоматическое подтверждение работы приложения.
''')
 (OUT/'sources/requirements-render.txt').write_text('reportlab\npypdf\npypdfium2\nPillow\nmarkdown-it-py\nopenapi-spec-validator\njsonschema\n')

def pack():
 with zipfile.ZipFile(OUT.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
  for p in sorted(OUT.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts and p.name!='.DS_Store':z.write(p,Path(OUT.name)/p.relative_to(OUT))

if __name__=='__main__':
 TMP.mkdir(parents=True,exist_ok=True)
 assert verify_sources(),'Исходные файлы изменились после фиксации'
 proposal=write_contracts();write_tasks();matrix=write_screens();metadata(matrix,proposal)
 boards=diagrams();guide();n=previews();readme();report=validate(boards,matrix,proposal);pack()
 print(json.dumps(dict(status=report['status'],guidePages=n,counts=report['counts']),ensure_ascii=False))
