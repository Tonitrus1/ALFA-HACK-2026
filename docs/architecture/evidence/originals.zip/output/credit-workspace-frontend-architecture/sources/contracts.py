from pathlib import Path
import copy,json
OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parent.parent
BASE=ROOT/'output/credit-workspace-backend-architecture/api/openapi.json'
def write():
 baseline=json.loads(BASE.read_text());demo=json.loads(BASE.with_name('demo-openapi.json').read_text())
 (OUT/'api/baseline-openapi.json').write_bytes(BASE.read_bytes())
 (OUT/'api/demo-openapi.json').write_bytes(BASE.with_name('demo-openapi.json').read_bytes())
 spec=copy.deepcopy(baseline);spec['paths'].update(demo['paths'])
 spec['info']['description']+=' Объединённый указатель для demo-инструментов; имя proposed-additions сохранено для ссылок, статус: согласовано на уровне проектирования.'
 (OUT/'api/proposed-additions.openapi.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2))
 changes=[dict(gap=f'G{i:02d}',kind='accepted-design',status='Включено в общий/backend контракт; реализация не выполнялась') for i in range(1,11)]
 changes.append(dict(kind='accepted-design',operation='POST /api/v1/applications/{applicationId}/information-requests/{requestId}/draft/confirm-extraction',reason='Неизменяемость исходного снимка'))
 (OUT/'api/changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2))
 (OUT/'api/proposal-examples.json').write_bytes((OUT/'sources/contract-examples.json').read_bytes())
 mapping={'B01':['T01.1','T01.2','T02.3'],'B02':['T03.1'],'B03':['T03.2'],'B04':['T04.2','T04.6'],'B05':['T04.2','T04.3','T04.5'],'B06':['T06.1'],'B07':['T05.4'],'B08':['T03.5','T05.4'],'B09':['T02.4','T05.1','T05.5','T06.3'],'B10':['T01.2','T06.5'],'B11':['T06.5','T02.6']}
 by={t['id']:t['title'] for t in json.loads((ROOT/'output/credit-workspace-backend-architecture/tasks.json').read_text())}
 (OUT/'api/backend-task-map.json').write_text(json.dumps([dict(frontendPackageTask=k,existingBackendTasks=[dict(id=i,title=by[i]) for i in v]) for k,v in mapping.items()],ensure_ascii=False,indent=2))
 catalog=[dict(method=m.upper(),path=p,summary=o['summary'],owner=o.get('x-owner-module'),status='Согласованная проектная спецификация 1.2.0-design') for p,methods in baseline['paths'].items() for m,o in methods.items()]
 (OUT/'api/baseline-operation-catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
 return spec
if __name__=='__main__':write()
