"""Check all glyph bounds; visual inspection remains an explicit separate step."""
from pathlib import Path
import json
import pypdfium2 as pdfium
OUT=Path(__file__).resolve().parents[1]
def check():
 result=[]
 for file in ['frontend-architecture-atlas.pdf','frontend-development-guide.pdf']:
  pdf=pdfium.PdfDocument(str(OUT/file));bad=[];chars=0
  for page_i,page in enumerate(pdf):
   text=page.get_textpage();w,h=page.get_size()
   for i in range(text.count_chars()):
    ch=text.get_text_range(i,1)
    if not ch.strip():continue
    x0,y0,x1,y1=text.get_charbox(i);chars+=1
    if min(x0,y0)<-0.5 or x1>w+0.5 or y1>h+0.5:bad.append(dict(page=page_i+1,char=ch,box=[x0,y0,x1,y1]))
  result.append(dict(file=file,pages=len(pdf),glyphsChecked=chars,outsidePage=bad))
 report=json.loads((OUT/'validation-report.json').read_text());report['pdfGeometryReview']=result
 report['checks'].append(dict(check='Границы всех непустых символов в двух PDF',passed=all(not x['outsidePage'] for x in result),detail='Проверка PDFium; не заменяет визуальную проверку'))
 (OUT/'validation-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 assert all(not x['outsidePage'] for x in result),str(result)
 print(json.dumps([{k:v for k,v in x.items() if k!='outsidePage'} for x in result],ensure_ascii=False))
if __name__=='__main__':check()
