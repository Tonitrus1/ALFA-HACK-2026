"""Seal only after all rendered contact sheets have been inspected."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
O=ROOT/'output'
R=O/'architecture-review'
G=O/'credit-workspace-architecture-v2'
B=O/'credit-workspace-backend-architecture'
F=O/'credit-workspace-frontend-architecture'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def tree(folder,relative,cache=False):return {str(p.relative_to(relative)):digest(p) for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='.DS_Store' and (cache or '__pycache__' not in p.parts)}
def pack(folder,archive,prefix=None):
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
  for p in sorted(folder.rglob('*')):
   if p.is_file() and p.name!='.DS_Store' and '__pycache__' not in p.parts:z.write(p,(Path(prefix)/p.relative_to(folder)) if prefix else p.relative_to(folder.parent))
def main():
 geometry=json.loads((R/'pdf-geometry-review.json').read_text())
 assert all(not x['outsidePage'] and digest(ROOT/x['file'])==x['sha256'] for x in geometry)
 visual=dict(status='passed',date='2026-10-20',method='Просмотр всех страниц на обзорных листах; проверка всех схем, таблиц, подписей и переходов; дополнительно проверены границы каждого непустого символа. Обновлённые страницы просмотрены повторно.',pdfs=[dict(file=x['file'],sha256=x['sha256'],pagesReviewed=list(range(1,x['pages']+1))) for x in geometry],limitations='Проверка оформления и согласованности проектных артефактов; не испытания приложения.')
 save(R/'visual-review.json',visual)
 for package in [G/'architecture-v2',B,F]:
  p=package/'validation-report.json';report=json.loads(p.read_text());local=[x for x in geometry if Path(x['file']).parent==package.relative_to(ROOT)]
  report['visualReview']=dict(status='passed',date='2026-10-20',method=visual['method'],reviewedPdfSha256={Path(x['file']).name:x['sha256'] for x in local},pagesReviewed={Path(x['file']).name:list(range(1,x['pages']+1)) for x in local})
  report['pdfGeometryReview']=local
  report['deliverableSha256']={p.name:digest(p) for p in package.glob('*.pdf')}
  save(p,report)
 shutil.copy2(G/'architecture-v2/validation-report.json',O/'architecture-v2/validation-report.json')
 # Preserve the final upstream fingerprints, including reviewed reports.
 p=B/'source-manifest.json';m=json.loads(p.read_text());m['files']=tree(G,G,cache=True);save(p,m)
 p=F/'source-manifest.json';m=json.loads(p.read_text());m['files']={**tree(G,ROOT),**tree(B,ROOT)};save(p,m)
 # Refresh the machine inventory without rerendering the already-reviewed report.
 p=R/'file-inventory.json';rows=json.loads(p.read_text())
 for row in rows:
  f=ROOT/row['path'];row['sha256']=digest(f)
  if 'lines' in row:row.update(lines=len(f.read_text().splitlines()),characters=len(f.read_text()))
 save(p,rows)
 pack(G,O/'credit-workspace-architecture-v2.zip')
 pack(B,O/'credit-workspace-backend-architecture.zip')
 pack(F,O/'credit-workspace-frontend-architecture.zip')
 save(R/'final-deliverables-sha256.json',{str(p.relative_to(ROOT)):digest(p) for p in [O/'credit-workspace-architecture-v2.zip',O/'credit-workspace-backend-architecture.zip',O/'credit-workspace-frontend-architecture.zip',R/'architecture-review.pdf',R/'architecture-review.md']})
 bundle=O/'credit-workspace-reviewed.zip'
 with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
  for folder in [G,B,F,R,ROOT/'tools']:
   for p in sorted(folder.rglob('*')):
    if p.is_file() and p.name!='.DS_Store' and '__pycache__' not in p.parts:z.write(p,p.relative_to(ROOT))
 with zipfile.ZipFile(bundle) as z:assert z.testzip() is None
 print(json.dumps(dict(bundle=str(bundle),sizeMiB=round(bundle.stat().st_size/1048576,2),pagesReviewed=sum(x['pages'] for x in geometry),staticChecks=json.loads((R/'validation-report.json').read_text())['counts']),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
