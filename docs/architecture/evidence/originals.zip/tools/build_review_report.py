"""Build the audit report, complete inventory and cross-package traceability."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import sys
import unicodedata

from pypdf import PdfReader
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/architecture-review'
G=ROOT/'output/credit-workspace-architecture-v2/architecture-v2'
B=ROOT/'output/credit-workspace-backend-architecture'
F=ROOT/'output/credit-workspace-frontend-architecture'

def read(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def coverage():
    screen_sets={
     'R01':list(range(1,16)), 'R02':[1,2,8,9,10,14,15], 'R03':[4,5,6,7,10],
     'R04':[8,9,10,12], 'R05':[10,11,12,14], 'R06':[11,12,13], 'R07':[11,13,14],
     'R08':[3,11,15], 'R09':[3,7,8,12], 'R10':[3,8,11], 'R11':[1,2,8,9,14,15],
     'R12':list(range(1,16)), 'R13':[1,2,6,10,11,14], 'R14':[7,8,10,12],
     'R15':[3,8,11,15], 'R16':[1,11,14]}
    components={
     'R01':['B01-B09','I01','X01-X06'], 'R02':['B01','B02','B05','file-gateway'],
     'R03':['B03','B04'], 'R04':['B04','B05','B06'], 'R05':['B04','B07','I01','platform'],
     'R06':['B07','B08','X03'], 'R07':['B09','I01','X03','X05'], 'R08':['B08','B01'],
     'R09':['B06','M01-M05'], 'R10':['E01','E02','B01','workers','D01-D03'],
     'R11':['B01','B02','S02','bank-platform'], 'R12':['all-package-builders'],
     'R13':['B01','B02','B04','platform'], 'R14':['B04','B06','B07'],
     'R15':['B08','I01','Kafka/PostgreSQL transports'], 'R16':['demo-simulator','bank-platform']}
    data={
     'R01':['ownership-registry'], 'R02':['Session','Company','ConsentRequirement','Capabilities'],
     'R03':['Application','DraftPatch','Submit','Money'], 'R04':['Document','DocumentReference','ConsentRecord','UploadInput'],
     'R05':['Operation','CommandReceipt','BankCommand','outbox/inbox'],
     'R06':['InformationItem','InformationDraft','InformationResponse','Decision','CaseSnapshot'],
     'R07':['Offer','AcceptOffer','Withdrawal','Operation'], 'R08':['StatusView','ClientStreamMessage','StreamSnapshot','HistoryPage','InboxItem'],
     'R09':['RiskRequest','RiskResult','Extraction','JobLease','RankingRequest'],
     'R10':['capacity-model','SLI','queue-age'], 'R11':['retention-matrix','audit','backup','bank-command-journal'],
     'R12':['source-manifest','validation-report','SBOM'], 'R13':['Session.contextVersion','clearFields','OperationList'],
     'R14':['InformationDraft','DocumentReference','ConfirmExtraction','ScanResult'],
     'R15':['CaseSnapshot','stream_event','outbox/inbox'], 'R16':['DemoAction','DemoOperatorSession','DR-journal']}
    event_map={
     'R03':['SubmissionRequested'],'R04':['ConsentRevoked','DocumentProcessingRequested','DocumentScanCompleted'],
     'R05':['SubmissionRequested','CaseAccepted','CaseStateChanged'],'R06':['InformationRequested','InformationResponseSubmitted','DecisionRecorded'],
     'R07':['OfferAcceptanceRequested','OfferAccepted','OfferExpired','WithdrawalRequested','ApplicationWithdrawn','FulfillmentCompleted'],
     'R08':['CaseStateChanged','DocumentExtractionReady'],'R09':['DocumentExtractionReady'],
     'R13':['SubmissionRequested'],'R14':['InformationRequested','InformationResponseSubmitted','DocumentScanCompleted'],
     'R15':['CaseAccepted','CaseStateChanged','DocumentExtractionReady'],'R16':['DecisionRecorded','FulfillmentCompleted']}
    matrix=read(F/'interaction-matrix.json');result=[]
    for req in read(B/'traceability.json'):
        screens=[f'U{i:02d}' for i in screen_sets[req['id']]]
        rows=[x for x in matrix if x['screen'] in screens]
        result.append(dict(requirementId=req['id'],requirement=req['requirement'],components=components[req['id']],screens=screens,
          operations=sorted({s for row in rows for s in row['api'].split('; ')}),events=event_map.get(req['id'],[]),
          data=data[req['id']],backendTasks=req['tasks'],frontendTasks=sorted({t for row in rows for t in row['frontendTasks']}),
          backendTests=req['tests'],frontendTests=sorted({t for row in rows for t in row['tests']}),
          acceptanceStatus='Specified, not executed against an application'))
    save(OUT/'traceability-matrix.json',result)
    lines=['# Сквозная матрица требований','','В строках указаны нормативные связи спецификации; наличие теста означает требование будущей приёмки, а не выполненное испытание. Полные операции и события — в traceability-matrix.json.','']
    for x in result:
        lines += [f"## {x['requirementId']}. {x['requirement']}",'',
         '**Компоненты:** '+', '.join(x['components'])+'.',
         '**Экраны:** '+', '.join(x['screens'])+'.',
         '**Данные:** '+', '.join(x['data'])+'.',
         '**Задачи backend:** '+', '.join(x['backendTasks'])+'. **Задачи frontend:** '+', '.join(x['frontendTasks'])+'.',
         '**Приёмка backend:** '+', '.join(x['backendTests'])+'. **Приёмка frontend:** '+', '.join(x['frontendTests'])+'.','']
    (OUT/'traceability-matrix.md').write_text('\n\n'.join(lines))
    return result

def inventory():
    rows=[]
    for package in [G,B,F]:
        for p in sorted(package.rglob('*')):
            if not p.is_file() or '__pycache__' in p.parts or p.name=='.DS_Store':continue
            kind=p.suffix.lower();row=dict(path=str(p.relative_to(ROOT)),kind=kind,sha256=digest(p),inspection='content/source/contract' if kind in ['.md','.json','.py','.txt','.html'] else 'structural plus rendered visual review' if kind in ['.pdf','.svg','.drawio','.png'] else 'inventory')
            if kind in ['.md','.py','.txt','.html']:
                text=p.read_text();row.update(lines=len(text.splitlines()),characters=len(text))
            if kind=='.json':json.loads(p.read_text())
            if kind=='.pdf':row['pages']=len(PdfReader(p).pages)
            rows.append(row)
    save(OUT/'file-inventory.json',rows)
    return rows

def report(coverage_rows,inventory_rows):
    findings=read(OUT/'findings.json');gates=read(OUT/'external-dependencies.json');checks=read(OUT/'validation-report.json')
    p1=sum(x['severity']=='P1' for x in findings);p2=len(findings)-p1
    text=f'''# Архитектурный аудит кредитного кабинета

20 октября 2026 года. Общая архитектура, backend и frontend проверены как единая проектная спецификация. Уровень: реализуемый MVP и целевой банковский контур. Исходные материалы сохранены в originals.zip; контрольные суммы — original-sha256.json.

## Результат и границы заключения

Выявлено и исправлено в проектных материалах {len(findings)} замечаний: {p1} уровня P1 (высокий риск несовместимости, потери данных или неверного эффекта при буквальной реализации), {p2} уровня P2 (неполная спецификация, неподтверждённые утверждения и дефекты поставки). Это оценка последствий исходного проекта, не сообщение о происшествиях в работающем банке. Противоречия, пробелы и внешние предположения разделены в реестре.

Спецификация MVP согласована для начала разработки по описанным задачам: один синтетический продукт, два представителя, автономные интеграции, клиентский web-путь, уточнения и небинарные исходы. Кандидатные версии платформы фиксируются и проверяются в T01.3/F01 до сборки приложения. Демонстрационная frontend-имитация сбрасывается после перезагрузки; сохранение и конкуренцию проверяет local-mvp с PostgreSQL.

Промышленный банковский запуск не подтверждён. Восемь внешних условий ниже блокируют соответствующие интеграции/production. Реальные IAM, банковские протоколы, правовые основания, криптографический профиль, нагрузка, восстановление и качество моделей не подменяются синтетическими результатами.

## Что изменено

- Один клиентский OpenAPI 1.2.0-design: 49 публичных операций, точные копии во всех пакетах; 6 demo-операций в отдельном контракте.
- Добавлены адресуемые RFI, отдельное подтверждение OCR в ответе, версии сохранённого ответа и требований, явная очистка полей и точные ссылки на байты.
- Определены общий контекст компании для cookie-сессии, межвкладочная защита contextVersion и восстановление завершённых команд.
- Исправлены восстановление SSE, чтение полного потока caseVersion, нормализованный снимок, привязка worker к аренде и гонка отмены файла.
- Backend наследует исходные цели 99,95%, p95 300/500 мс, RPO 5 минут/RTO 30 минут и три домена отказа. Это цели, не достигнутые результаты.
- Правки внесены в редактируемые источники, генераторы, задачи и приёмку; исторические proposal-ссылки сохранены, их статус явно изменён на согласованный проект.

## Проверка источников

Первичные PDF кейса (16 страниц) и CX-обзора (11 страниц) повторно прочитаны из путей source-manifest.json; контрольные суммы совпали. Ограничения синтетики, автономности, веб-пути и отделения скоринга от решения сохранены. Правовые и отраслевые утверждения CX-обзора не приняты как проверенные нормы. Инструкции кейса о публикации/сдаче не исполнялись.

В трёх пакетах учтено {len(inventory_rows)} файлов; инвентаризация включает исходники генераторов и все форматы представления. Контракты, примеры и ссылки проверены отдельно от оформления PDF. Матрица содержит {len(coverage_rows)} групп требований с компонентами, экранами, операциями/событиями, данными, задачами и проверками.

Boot 4.1.1 допускает Java 21 по официальным [системным требованиям Spring Boot](https://docs.spring.io/spring-boot/system-requirements.html). Страница [совместимости Spring Modulith](https://docs.spring.io/spring-modulith/reference/appendix.html) отображает 2.1.1, но её таблица не содержит строки 2.1/4.1. Поэтому совместная сборка оставлена явным условием T01.3; существование версии не выдано за испытанную совместимость. Наблюдения сохранены в technical-evidence.json.

## Фактически выполненная валидация

Общий валидатор: {checks['counts']['checks']} проверок, {checks['counts']['failed']} ошибок; {checks['counts']['contractFixtures']} положительных и отрицательных контрактных примеров. Проверены OpenAPI 3.0/3.1, внутренние ссылки, заголовки/ошибки, совпадение контрактов, JSON Schema 16 событий, маршруты всех экранов, графы задач и привязки draw.io. Доказательства — validation-report.json и contract-fixtures.json. Отдельные отчёты пакетов и визуальный протокол относятся к конкретным контрольным суммам PDF.

Нагрузочные, транзакционные, security и E2E-испытания приложения не запускались: исполняемого приложения в задании нет. Для них дополнены 41 backend- и 38 frontend-сценариев; их наличие не означает прохождения.

## Реестр замечаний и исправлений

'''
    for x in findings:
        e=x['evidence'];source=e['path'].split('architecture/')[-1] if 'architecture/' in e['path'] else e['path'].replace('output/credit-workspace-architecture-v2/architecture-v2/','general/')
        text+=f"### {x['id']} [{x['severity']}] {x['title']}\n\n"
        text+=f"**Класс:** {x['category']}. **Статус:** исправлено в спецификации.\n\n"
        text+=f"**Доказательство:** оригинал `{source}`"+(f", строка {e['originalLine']}" if e['originalLine'] else '')+f". Фрагмент: «{e['fragment']}». Полный исходный путь — findings.json; оригинал сохранён в originals.zip.\n\n"
        text+=f"**Сценарий проблемы:** {x['failureScenario']}\n\n**Исправление:** {x['correction']}\n\n**Проверка:** {x['verification']}.\n\n"
    text+='## Внешние условия допуска\n\n'
    for x in gates:text+=f"### {x['id']}. {x['subject']}\n\n**Владелец:** {x['owner']}.\n\n**Условие закрытия:** {x['acceptance']}.\n\n**Влияние:** {x['impact']}.\n\n"
    text+='''## Как пользоваться результатом

Для чтения начать с README.md этого каталога, затем открыть исправленные гайды и атласы трёх пакетов. Детальная матрица — traceability-matrix.json; замечания — findings.json; внешние зависимости — external-dependencies.json. Исходные версии не заменяют актуальную спецификацию и нужны только для сравнения.

Для повторяемой проверки установить зависимости sources/requirements-render.txt, указать каталог DejaVu-шрифтов в CREDIT_FONT_DIR; при вынесенных Python-пакетах — CREDIT_RENDER_DEPS. Из корня рабочего проекта выполнить python tools/rebuild_architecture_review.py. Последовательность: общая архитектура, backend, явная фиксация актуальных входов, frontend, общий валидатор и отчёт. Отдельная frontend-сборка не обновляет входные контрольные суммы и выявляет дрейф. После изменения PDF визуальное подтверждение сбрасывается и требуется новый просмотр; успешная автоматическая проверка не восстанавливает прежний визуальный статус.
'''
    (OUT/'architecture-review.md').write_text(text)
    return text

def pdf(text):
    sys.path.insert(0,str(F/'sources'))
    from renderer import markdown_flow,styles
    class Doc(BaseDocTemplate):
        def __init__(self,path):
            super().__init__(str(path),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=49,bottomMargin=43,title='Архитектурный аудит кредитного кабинета',author='Архитектурная проверка')
            self.addPageTemplates(PageTemplate(id='review',frames=[Frame(44,43,A4[0]-88,A4[1]-92,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=self.decorate))
        def decorate(self,canv,doc):
            canv.saveState();canv.setFont('DV',7);canv.setFillColor(colors.HexColor('#586a7b'));canv.drawString(44,A4[1]-23,'КРЕДИТНЫЙ КАБИНЕТ / АРХИТЕКТУРНЫЙ АУДИТ');canv.drawString(44,23,'Проектная спецификация / 20.10.2026');canv.drawRightString(A4[0]-44,23,str(doc.page));canv.restoreState()
    Doc(OUT/'architecture-review.pdf').build(markdown_flow(text))

def main():
    rows=coverage();inv=inventory();text=report(rows,inv);pdf(text)
    (OUT/'README.md').write_text('''# Результат архитектурного аудита

Основной отчёт: [architecture-review.md](architecture-review.md) или [PDF](architecture-review.pdf). В нём 30 замечаний, исправления и 8 внешних условий допуска. Правки уже внесены в три исходных комплекта.

- [Общая архитектура](../credit-workspace-architecture-v2/architecture-v2/README.md)
- [Backend](../credit-workspace-backend-architecture/README.md)
- [Frontend](../credit-workspace-frontend-architecture/README.md)
- [Матрица требований](traceability-matrix.md), полные связи — traceability-matrix.json
- [Фактические автоматические проверки](validation-report.json), примеры — contract-fixtures.json
- [Внешние зависимости и владельцы](external-dependencies.json)
- [Инвентаризация](file-inventory.json), исходные версии — originals.zip и original-sha256.json

Спецификация MVP согласована для разработки с указанными начальными задачами фиксации платформы. Промышленный запуск требует закрытия внешних условий. Приложение не реализовывалось, его испытания не выполнялись.

Повторная сборка всех материалов: python tools/rebuild_architecture_review.py из рабочего проекта с зависимостями рендеринга. Только проверки: python tools/validate_architecture_review.py. Визуальный протокол — visual-review.json, если просмотр уже завершён; его контрольные суммы должны совпадать с текущими PDF.
''')
    print('Audit report pages:',len(PdfReader(OUT/'architecture-review.pdf').pages))

if __name__=='__main__':main()
