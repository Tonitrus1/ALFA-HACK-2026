"""Reconcile design contracts. No banking application is implemented here."""
from pathlib import Path
import copy
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REVIEW = ROOT / 'output/architecture-review'
GENERAL = ROOT / 'output/credit-workspace-architecture-v2/architecture-v2'
BACKEND = ROOT / 'output/credit-workspace-backend-architecture'
FRONTEND = ROOT / 'output/credit-workspace-frontend-architecture'
METHODS = {'get', 'post', 'patch', 'put', 'delete'}

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def string(maximum=256):
    return dict(type='string', minLength=1, maxLength=maximum)

def version():
    return dict(type='integer', minimum=1, maximum=9007199254740991)

def ref(name):
    return {'$ref': '#/components/schemas/' + name}

def obj(properties, required=None):
    return dict(type='object', properties=properties,
                required=list(properties) if required is None else required,
                additionalProperties=False)

def array(item, minimum=0):
    return dict(type='array', items=item, minItems=minimum, maxItems=100)

def parameter(name, where='header', schema=None, required=True):
    return dict(name=name, **{'in': where}, required=required, schema=schema or string())

def require(schema, *names):
    schema['required'] = list(dict.fromkeys(schema.get('required', []) + list(names)))

def normalize(spec):
    c = spec['components']['schemas']
    spec['info'].update(title='Кредитный кабинет: согласованный проект интерфейсов', version='1.2.0-design',
        description='Согласованная спецификация после межпакетного аудита 20.10.2026. Не реализованное приложение. Публичные и demo-маршруты поставляются отдельными контрактами. Правила: docs/interfaces.md общей архитектуры и главы интерфейсов backend/frontend.')
    c['Session']['properties']['contextVersion'] = version()
    require(c['Session'], 'contextVersion')
    c['Session']['description'] = 'Выбранная компания общая для вкладок одной cookie-сессии. contextVersion меняется при смене компании/входе; устаревший X-Company-Context отклоняется до бизнес-эффекта. CSRF обновляется при ротации сессии.'
    c['DraftPatch']['properties'].pop('confirmedExtractionIds', None)
    clearable = ['business.' + n for n in c['Business']['properties']]
    c['DraftPatch']['properties']['clearFields'] = array(dict(type='string', enum=clearable), 1)
    c['DraftPatch']['description'] = 'Частичное обновление: отсутствующее поле не меняется; business сливается по полям. clearFields явно удаляет только разрешённые необязательные поля. Одновременная запись и очистка того же пути: 422 PATCH_FIELD_CONFLICT. Обязательные цель, сумма и срок не очищаются. confirmedExtractionIds устанавливаются только сервером через confirm-extraction.'
    c['Application']['properties']['confirmedExtractionIds'] = array(string())
    require(c['Application'], 'productId', 'productVersion', 'terms')
    c['Application']['description'] = 'version и ETag принадлежат редактируемым данным заявки. Банковский статус собирается через workspace; его изменение не разрешает правку снимка. После SUBMITTED PATCH и подтверждение OCR исходной анкеты запрещены.'
    for name in ['Submit', 'InformationResponse']:
        c[name]['properties']['requirementsVersion'] = version()
        require(c[name], 'documentReferences', 'requirementsVersion')
        c[name]['properties']['documentIds']['uniqueItems'] = True
        c[name]['properties']['documentReferences']['uniqueItems'] = True
        c[name]['description'] = 'Точные documentReferences обязательны; множество documentIds должно совпадать без дублей. Сервер проверяет компанию, заявку, актуальную версию требований и CLEAN-байты; версии закрепляются в неизменяемом пакете. Несовпадение: 422 DOCUMENT_REFERENCES_MISMATCH, изменённые требования: 409 DOCUMENT_REQUIREMENTS_CHANGED.'
    c['InformationResponse']['properties']['draftVersion'] = version()
    require(c['InformationResponse'], 'draftVersion')
    c['InformationResponse']['description'] += ' draftVersion проверяется атомарно с переводом черновика ответа в отправленный; requestVersion относится к запросу банка. Ответ строится из сохранённого черновика, переданные поля должны совпадать с ним; иначе 409 INFORMATION_DRAFT_CONFLICT.'
    c['InformationResponse']['properties']['explanation']['maxLength'] = 2000
    c['InformationDraft']['properties']['requirementsVersion'] = version()
    require(c['InformationDraft'], 'requirementsVersion')
    c['InformationDraftPatch']['properties']['requirementsVersion'] = version()
    require(c['InformationDraftPatch'], 'requirementsVersion')
    c['InformationItem']['properties'].update(
        fieldPath=dict(type='string', enum=['purpose', 'amount', 'termMonths'] + clearable),
        requirementId=string())
    c['InformationItem']['oneOf'] = [
        dict(properties={'kind': {'enum': ['FIELD']}}, required=['fieldPath'], **{'not': {'required': ['requirementId']}}),
        dict(properties={'kind': {'enum': ['DOCUMENT']}}, required=['requirementId'], **{'not': {'required': ['fieldPath']}}),
        dict(properties={'kind': {'enum': ['EXPLANATION']}}, **{'not': {'anyOf': [{'required': ['fieldPath']}, {'required': ['requirementId']}]}})]
    c['InformationRequest']['description'] = 'Пункты FIELD адресуют разрешённый fieldPath, DOCUMENT — requirementId. Банк задаёт допустимые изменения; сервер отклоняет amendment с незапрошенными полями. Одновременно открыт не более один запрос на заявку в MVP.'
    c['UploadInput']['properties']['requestVersion'] = version()
    c['UploadInput']['allOf'] = [{'oneOf': [
        {'not': {'anyOf': [{'required': ['requestId']}, {'required': ['requestVersion']}]}},
        {'required': ['requestId', 'requestVersion']}]}]
    c['UploadInput']['description'] = 'Для RFI requestId и requestVersion передаются парой. Замена replacesDocumentId/expectedDocumentVersion также парная. Новый documentId, первоначальные байты и ссылки снимка неизменны. requirementsVersion обязателен. После отправки загрузка допустима только для открытого RFI и запрошенного requirementId.'
    c['Document']['properties']['version']['description'] = 'Версия метаданных и ETag; изменяется при изменении состояния. documentVersion в ссылке фиксирует наблюдённую версию; неизменные байты определяет objectVersion. Извлечение хранит версию источника при старте; актуальность подтверждается по objectVersion и extractionId.'
    c['Document']['description'] = 'Замена создаёт новый documentId; пока новая запись не CLEAN, старый документ остаётся действующим. Финализация загрузки и отмена сравнивают одну upload-state/version атомарно. Отменённый transfer не финализируется; осиротевшие байты удаляются сверкой.'
    c['Extraction']['properties']['objectVersion'] = string()
    require(c['Extraction'], 'objectVersion')
    c['ConfirmExtraction']['properties']['objectVersion'] = string()
    require(c['ConfirmExtraction'], 'objectVersion')
    c['ConfirmedField'] = obj({'name': string(), 'value': dict(type='string', maxLength=2000)})
    c['ConfirmExtraction']['properties']['confirmedFields'] = array(ref('ConfirmedField'), 1)
    c['ConfirmExtraction']['description'] = 'If-Match защищает целевой черновик. Проверить принадлежность extractionId, неизменяемый objectVersion и версию источника documentVersion. Клиент не задаёт confidence/page/modelVersion. Исправленные человеком значения сохраняются с происхождением USER_CONFIRMED. Имя поля отображается в allowlist бизнес-полей; повтор не добавляет подтверждение дважды.'
    c['Operation']['properties'].pop('externalRequestId', None)
    c['Operation']['properties'].update(resourceId=string(), companyId=string(), createdAt=dict(type='string', format='date-time'))
    require(c['Operation'], 'applicationId', 'operationType', 'resourceId', 'companyId', 'createdAt')
    c['Operation']['description'] = 'Внешний банковский ключ остаётся в integration. PENDING/RECONCILING — исход не установлен, FAILED — известный неуспех. SUCCEEDED означает подтверждение именно команды, а не завершение кредита. Для RESPOND resourceId=requestId; ACCEPT=offerId; SUBMIT/WITHDRAW=applicationId. Чтение ограничено actor+company.'
    c['OperationList']['properties']['nextCursor'] = string(2048)
    c['StreamSnapshot']['properties'].update(companyId=string(), contextVersion=version(), complete=dict(type='boolean', enum=[False]))
    require(c['StreamSnapshot'], 'companyId', 'contextVersion', 'complete')
    c['StreamSnapshot']['description'] = 'Курсор — барьер подписки; applications — не более 100 предварительных статусов, не полный список компании. complete всегда false. После получения курсора перечитать все активные ресурсы (включая документы, операции, inbox/feed), затем подписаться с этого курсора. События между чтениями воспроизводятся; повторы безопасны. Полные списки читаются штатной пагинацией.'
    c['ClientStreamMessage']['properties'].update(companyId=string(), contextVersion=version())
    require(c['ClientStreamMessage'], 'companyId', 'contextVersion')
    c['ClientStreamMessage']['description'] = 'viewVersion монотонна в пределах resourceType+resourceId и не сравнивается с ETag/caseVersion/document.version. Событие лишь инвалидирует чтение. Все изменения, включая документы и операции, имеют долговечный сигнал через outbox → workspace. Запоздалый сигнал остаётся безопасным.'
    c['Withdrawal']['properties']['expectedCaseVersion'] = version()
    c['Withdrawal']['description'] = 'expectedVersion — Application.version. Если банковское дело известно, expectedCaseVersion из StatusView обязателен и сверяется сервером. При SUBMITTED без caseId journey сначала завершает/сверяет создание дела, затем отзывает его. Не отправлять отзыв с выдуманной caseVersion и не показывать CANCELLED до подтверждения.'
    c['DemoOfferTerms'] = obj({k: copy.deepcopy(c['Offer']['properties'][k]) for k in ['amount', 'termMonths', 'termsDisclosure', 'validUntil']})
    c['DemoOperatorSession'] = obj({'userId': string(), 'role': dict(type='string', enum=['DEMO_OPERATOR']), 'expiresAt': dict(type='string', format='date-time'), 'csrfToken': string()})
    c['DemoAction']['properties']['offerTerms'] = ref('DemoOfferTerms')
    c['DemoAction']['properties']['items']['minItems'] = 1
    c['DemoAction']['oneOf'] = [
        {'properties': {'action': {'enum': ['REQUEST_INFORMATION']}}, 'required': ['items'], 'not': {'required': ['offerTerms']}},
        {'properties': {'action': {'enum': ['APPROVE', 'ALTERNATIVE']}}, 'required': ['offerTerms'], 'not': {'required': ['items']}},
        {'properties': {'action': {'enum': ['MANUAL_REVIEW', 'DECLINE', 'EXPIRE_OFFER', 'COMPLETE']}}, 'not': {'anyOf': [{'required': ['items']}, {'required': ['offerTerms']}]}}]
    c['DemoAction']['description'] = 'APPROVE/ALTERNATIVE требуют полные синтетические условия, REQUEST_INFORMATION — адресуемые items. Имитатор генерирует offerId/version; actor не задаёт их. Каждая команда проверяет expectedCaseVersion и разрешённый переход.'
    for name, schema in c.items():
        if 'required' in schema:
            schema['required'] = list(dict.fromkeys(schema['required']))
        for field, value in schema.get('properties', {}).items():
            if value.get('type') == 'integer':
                value.setdefault('maximum', 9007199254740991)
                if 'version' in field.lower() or field == 'termMonths':
                    value['minimum'] = 1
    # Confirmation in an amendment must never invoke the original application's writer.
    old = spec['paths']['/api/v1/applications/{applicationId}/confirm-extraction']['post']
    path = '/api/v1/applications/{applicationId}/information-requests/{requestId}/draft/confirm-extraction'
    op = copy.deepcopy(old)
    op.update(operationId='confirm_information_draft_extraction', summary='Подтвердить извлечение в черновике ответа на уточнение', description='Изменяет только отдельный InformationDraft текущего OPEN-запроса; If-Match относится к draftVersion. Первоначальный submission не меняется.', **{'x-owner-module': 'journey'})
    op['parameters'].insert(1, parameter('requestId', 'path'))
    op['responses']['200']['content']['application/json']['schema'] = ref('InformationDraft')
    spec['paths'][path] = {'post': op}
    old['description'] = 'Применение OCR разрешено только к Application в DRAFT; после отправки вернуть 409 APPLICATION_IMMUTABLE. Для уточнения использовать отдельный /information-requests/{requestId}/draft/confirm-extraction.'
    public_exceptions = {'/api/v1/session', '/api/v1/logout', '/api/v1/companies', '/api/v1/companies/{companyId}'}
    for path, methods in spec['paths'].items():
        for method, op in methods.items():
            if method not in METHODS:
                continue
            op.pop('x-proposal', None)
            op['description'] = op.get('description', '').replace('ПРЕДЛОЖЕНИЕ', 'Согласованное расширение').replace('Не реализовано; см. главу 5.', 'Спецификация для реализации; см. главу интерфейсов.')
            op['parameters'] = [p for p in op.get('parameters', []) if p['name'] != 'X-Company-Context']
            if not path.startswith('/demo/') and (path not in public_exceptions or path == '/api/v1/session/company'):
                op['parameters'].append(parameter('X-Company-Context', schema=version()))
                op['description'] += ' X-Company-Context сравнивается с contextVersion серверной сессии; несовпадение даёт 409 COMPANY_CONTEXT_CHANGED до эффекта. companyId из пути/тела/query/ресурса должен совпадать с выбранной компанией.'
            owner = op.get('x-owner-module')
            if '/operations' in path: owner = 'platform'
            elif '/information-requests/' in path: owner = 'journey'
            elif path.endswith('/history'): owner = 'workspace'
            elif path.endswith('/document-requirements'): owner = 'applications'
            elif '/uploads/' in path and '/files/' not in path: owner = 'documents'
            elif path.endswith('/capabilities'): owner = 'access'
            if path.startswith('/demo/'): owner = 'demo-simulator'
            if owner: op['x-owner-module'] = owner
            for code in ['400', '401', '403', '404', '409', '429', '500', '503']:
                op['responses'].setdefault(code, {'description': 'Безопасная ошибка'})
                op['responses'][code]['content'] = {'application/json': {'schema': ref('Error')}}
                if code in ['429', '503']:
                    op['responses'][code].setdefault('headers', {})['Retry-After'] = {'schema': {'type': 'integer', 'minimum': 1}}
            if method != 'get':
                op['responses'].setdefault('422', {'description': 'Нарушение бизнес-правил', 'content': {'application/json': {'schema': ref('Error')}}})
            for code, response in op['responses'].items():
                if code.startswith(('4', '5')):
                    response['content'] = {'application/json': {'schema': ref('Error')}}
                response.setdefault('headers', {})['Cache-Control'] = {'schema': {'type': 'string'}, 'description': 'no-store'}
                if code == '202':
                    response['headers']['Location'] = {'schema': {'type': 'string'}, 'description': '/api/v1/operations/{operationId}'}
                if 'If-Match' in [p['name'] for p in op['parameters']]:
                    op['responses'].setdefault('428', {'description': 'Отсутствует If-Match', 'content': {'application/json': {'schema': ref('Error')}}})
            if '/files/' in path:
                op['description'] += ' Проверка Origin, CSRF загрузки и версии контекста выполняется шлюзом/внутренней авторизацией. Возвращать нормализованный Error, включая обрыв до начала ответа; оборванное бинарное тело трактуется клиентом как неполная передача.'
            if path.startswith('/demo/'):
                op['x-demo-only'] = True
                op['description'] += ' Маршрут существует только в demo-профиле на loopback/изолированном стенде с синтетикой. Вне профиля 404. Проверять точный Origin и JSON Content-Type для login; для операторских изменений — отдельные cookie и CSRF. Представитель не является оператором.'
                if method == 'post' and path.endswith('/actions'):
                    op['parameters'].append(parameter('Idempotency-Key'))
    operator = spec['paths']['/demo/api/v1/operator/session']['post']
    operator['responses']['200']['content']['application/json']['schema'] = ref('DemoOperatorSession')
    listing = spec['paths']['/api/v1/operations']['get']
    listing['parameters'] = [p for p in listing['parameters'] if p['name'] != 'active'] + [
        parameter('active', 'query', dict(type='boolean', default=False), False),
        parameter('limit', 'query', dict(type='integer', minimum=1, maximum=100, default=20), False),
        parameter('cursor', 'query', string(2048), False)]
    listing['description'] = 'По умолчанию все активные и окончательные операции за последние 24 часа (минимум срока dedup), actor+company+application. active=true — только незавершённые. Стабильный порядок createdAt+operationId и пагинация. После перезагрузки читать без active=true: иначе потеряется уже завершённая команда.'
    return spec

def main():
    with zipfile.ZipFile(REVIEW / 'originals.zip') as z:
        spec = json.loads(z.read('output/credit-workspace-frontend-architecture/api/proposed-additions.openapi.json'))
    normalize(spec)
    public, demo = copy.deepcopy(spec), copy.deepcopy(spec)
    public['paths'] = {p: o for p, o in spec['paths'].items() if not p.startswith('/demo/')}
    demo['paths'] = {p: o for p, o in spec['paths'].items() if p.startswith('/demo/')}
    demo['info']['title'] += ': только демонстрация'
    # Keep separate security contexts explicit even though schemas share a design vocabulary.
    demo['security'] = [{'DemoOperatorCookie': []}]
    for target in [GENERAL, ROOT / 'output/architecture-v2']:
        save(target / 'api/openapi.json', public)
        save(target / 'api/demo-openapi.json', demo)
        save(target / 'sources/client-contract.json', public)
        save(target / 'sources/demo-contract.json', demo)
    save(BACKEND / 'api/openapi.json', public)
    save(BACKEND / 'api/demo-openapi.json', demo)
    save(FRONTEND / 'api/baseline-openapi.json', public)
    save(FRONTEND / 'api/demo-openapi.json', demo)
    save(FRONTEND / 'api/proposed-additions.openapi.json', spec)
    print('Reconciled:', sum(len(v) for v in public['paths'].values()), 'public operations;', sum(len(v) for v in demo['paths'].values()), 'demo operations')

if __name__ == '__main__':
    main()
