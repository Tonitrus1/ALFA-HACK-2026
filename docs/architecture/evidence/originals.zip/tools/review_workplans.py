from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]
B=ROOT/'output/credit-workspace-backend-architecture'
F=ROOT/'output/credit-workspace-frontend-architecture'

# Inputs remain packaged with each generator; IDs are stable for existing links.
BACKEND_ADDITIONS={
'T01.2':' Подтвердить полный журнал принятых банковских команд за окно RPO, монотонность и полноту caseVersion, получение снимка и безопасный поиск результата.',
'T01.3':' Совместимость Modulith 2.1.1/Boot 4.1.1 является кандидатом, а не подтверждённой строкой матрицы; обязательны effective-pom и smoke-тест модулей.',
'T02.3':' Реализовать согласованный OpenAPI 1.2.0-design (49 публичных операций), no-store и унифицированные ошибки файлов; 6 demo-операций поставлять отдельно.',
'T02.4':' GET operations/lookup и пагинированный GET operations восстанавливают также недавние завершённые команды. Внешний ключ не передаётся браузеру.',
'T02.6':' Проверять local-mvp с PostgreSQL без Redis/Kafka и bank-target с Kafka/Testcontainers раздельно.',
'T03.1':' В local-mvp использовать PostgreSQL-сессии и синтетический demo-login; в bank-target — IAM/Redis. contextVersion и X-Company-Context защищают переключение общей cookie-сессии между вкладками.',
'T03.2':' Выдать capabilities компании/заявки с безопасными причинами; перепроверять право и contextVersion внутри критичной транзакции.',
'T03.4':' PATCH business сливает поля; clearFields очищает разрешённые необязательные пути. confirmedExtractionIds не принимаются от клиента напрямую.',
'T03.5':' Выдать клиентскую историю по /history с пагинацией; хранить стабильный eventId и безопасные сообщения.',
'T04.2':' Выдать document-requirements. UploadInput требует requirementId/requirementsVersion; RFI requestId/requestVersion парные. Замена создаёт новый documentId с ссылкой replacesDocumentId.',
'T04.3':' Финализация и DELETE uploads конкурируют через CAS одного состояния; проверить точный размер, grant, текущую сессию/contextVersion и срок.',
'T04.4':' Аренда привязана к workerId, leaseToken, generation и workload identity; CLEAN требует проверенного cleanObjectRef.',
'T04.5':' Отмена закрывает grant атомарно; повтор 204, завершённый upload — 409. Сверка удаляет объект проигравшей финализации.',
'T04.6':' В submit/response обязательны requirementsVersion и точные documentReferences, совпадающие с documentIds; гонки сериализованы.',
'T05.1':' Для восстановления потерянного 202 включить результат в GET operations также после SUCCEEDED.',
'T05.4':' SSE содержит resourceType, companyId, contextVersion. Снимок — курсор-барьер complete=false; после него клиент перечитывает все активные ресурсы, не только статусы.',
'T05.5':' Все проекции читают полный нормализованный поток caseVersion, включая семантически неиспользуемые события; доступен /internal/v1/cases/{caseId}/snapshot.',
'T06.1':' Реализовать GET/PATCH отдельного InformationDraft и его /draft/confirm-extraction. FIELD имеет fieldPath, DOCUMENT requirementId. Ответ проверяет requestVersion, draftVersion и requirementsVersion.',
'T06.3':' Withdrawal.expectedVersion относится к Application.version; при известном деле отдельно сверяется expectedCaseVersion. При SUBMITTED без caseId сначала сверяется создание дела.',
'T06.5':' Реализовать 6 demo-операций, отдельную операторскую cookie/CSRF и DemoOperatorSession, Origin, Idempotency-Key операторских команд, полные DemoOfferTerms; отключение вне demo даёт 404.',
'T07.1':' ConfirmExtraction требует If-Match/Idempotency-Key и точный objectVersion; переданные confidence/page не принимаются. После отправки используется только отдельный черновик RFI.',
'T08.2':' Измерять единые цели: 99,95%; p95 чтений 300 мс и команд 500 мс, свежесть 5 с. Подмена исходной цели более слабой запрещена без ADR.',
'T08.4':' Цели RPO 5 минут, RTO 30 минут; три домена отказа для целевого контура. Проверить потерю локального externalRequestId и восстановление по полному банковскому журналу.'}

BACKEND_TESTS=[
('V30','Смена компании между вкладками','Вкладка А сохраняет заявку, вкладка Б меняет компанию; задержать старый запрос до commit.','Старый контекст получает COMPANY_CONTEXT_CHANGED до эффекта либо завершился до переключения для прежней компании; UI не смешивает данные.','Интеграционная с PostgreSQL'),
('V31','Адресуемое уточнение и OCR','FIELD без fieldPath; DOCUMENT без requirementId; подтвердить OCR после отправки.','Неверные пункты отклонены; исходная анкета неизменна; отдельный /draft/confirm-extraction меняет только InformationDraft.','Контрактная и сквозная'),
('V32','Версии ответа на уточнение','Сохранить draftVersion 3, параллельно изменить черновик или requestVersion и отправить прежнее тело.','409; сверяются draftVersion/requestVersion/requirementsVersion; актуальный ответ относится к прежней заявке.','Интеграционная'),
('V33','Отмена против завершения','Отменить upload во время записи объекта и повторить complete с прежним grant.','Ровно один переход CAS; отменённые байты не CLEAN; проигравший объект обнаружен и удалён сверкой.','Файловая интеграционная'),
('V34','Полномочия аренды','Другой worker с той же сервисной ролью присылает generation с чужим leaseToken; CLEAN без cleanObjectRef.','Результат отклонён; истёкшая аренда не меняет файл; корректный CLEAN с подтверждённым объектом допустим.','Контрактная и интеграционная'),
('V35','Восстановление завершённой команды','Команда стала SUCCEEDED, ответ потерян, пользователь перезагрузил страницу.','Список без active=true возвращает завершённую команду; повторного бизнес-эффекта нет.','Сквозная'),
('V36','Полный поток caseVersion','Для offers между DecisionRecorded и OfferAccepted доставить CaseStateChanged.','Курсор продвигается по всем типам; ложной дырки нет. Реальный пропуск вызывает чтение нормализованного снимка.','Интеграционная'),
('V37','Восстановление всех ресурсов','За старым курсором изменены документ, операция и inbox; в компании более 100 заявок.','Снимок не обещает полный список; перечитаны все активные ресурсы, событие между барьером и подпиской не теряется.','Интеграционная'),
('V38','Очистка и подтверждения','Очистить annualRevenue через clearFields; подделать confirmedExtractionIds или очистить одновременно с присваиванием.','Явная очистка работает; поддельное подтверждение и конфликт путей отклонены; обязательные условия не очищены.','Контрактная и интеграционная'),
('V39','Два профиля одной семантики','Пройти submit/RFI/accept с PostgreSQL transport и с Kafka; перезапустить после commit.','Одинаковые контракт и бизнес-эффекты, сохранённые outbox/inbox и операции; локальный показ не требует Kafka/Redis.','Профильная интеграционная'),
('V40','Demo отдельно от клиента','Передать representative cookie операторскому методу, убрать CSRF; запустить вне demo.','Нет операторского эффекта; вне demo 404; корректный оператор получает отдельную сессию и не меняет клиентскую cookie.','Безопасность и сквозная'),
('V41','Потерянные локальные ключи при DR','Восстановить БД до принятой банком команды, уничтожив её локальную mapping.','Полный внешний журнал восстанавливает сопоставление; до сверки финансовые команды закрыты; измеряется RTO ≤30 минут как цель.','Репетиция аварии')]

FRONTEND_TESTS=[
('V31','Контекст общей сессии','Две вкладки с общей cookie меняют компанию при отложенном PATCH.','X-Company-Context отклоняет устаревшую запись; обе вкладки перечитывают Session, чужие данные не появляются.','С локальным сервером'),
('V32','Завершённая команда после перезагрузки','Потерять ответ уже выполненной команды и обновить страницу.','Читаются активные и недавние завершённые операции; UI не создаёт новый ключ для того же намерения.','С локальным сервером'),
('V33','OCR отдельного ответа','После отправки анкеты подтвердить извлечение для RFI.','Используется /draft/confirm-extraction с ETag ответа; исходный submission не меняется.','Контрактная и E2E'),
('V34','Явная очистка поля','Очистить необязательное финансовое поле и перейти дальше.','Уходит clearFields; после чтения поле отсутствует, не становится нулём.','Компонентная и E2E'),
('V35','Адресуемые пункты банка','Получить FIELD/DOCUMENT/EXPLANATION и попытаться передать незапрошенное изменение.','UI строит поля по allowlist, сервер отклоняет лишнее; requestVersion и draftVersion проверяются раздельно.','Контрактная и E2E'),
('V36','Resync разных ресурсов','Изменить документ/операцию/inbox и очистить историю SSE; более 100 заявок.','Перечитаны все активные ресурсы, complete=false не трактуется как полная компания; исходный ввод не стирается.','E2E'),
('V37','Обязательные заголовки файлов и OCR','Потерять X-Company-Context, Idempotency-Key intent/confirm и If-Match подтверждения.','Клиент формирует заголовки по контракту; пропуск не даёт ложного успеха; бинарная ошибка безопасно показана.','Контрактная и интеграционная'),
('V38','Полные условия имитатора','Одобрить и предложить альтернативу без termsDisclosure/validUntil; войти оператором отдельно.','Неполные условия отклонены; клиентский CSRF не подменяется операторским; вне demo нет панели.','E2E')]

def main():
    # Hook updates immediately before the existing rendering functions consume source constants.
    p=B/'sources/workplan.py';text=p.read_text()
    hook='''# Applied once on module import; source inputs are part of the package.
review=json.loads((Path(__file__).with_name('review-workplan.json')).read_text())
TASKS=[tuple(list(t[:2])+[t[2]+review['additions'].get(t[0],'')]+list(t[3:])) for t in TASKS]
TESTS=[tuple(x) for x in TESTS]
TESTS=[(i,t,s,('Старые HTTP-клиенты допускают новые необязательные поля ответа; строгие события меняются новой schemaVersion/темой с параллельным потребителем. Несовместимая версия не применяется; откат на совместимую схему возможен.' if i=='V29' else e),m) for i,t,s,e,m in TESTS]
TESTS.extend(tuple(t) for t in review['tests'])
REQUIREMENTS.extend([('R13','Контекст, протокол и восстановление',['03','04','08'],['T03.1','T02.3','T02.4'],['V30','V35','V38']),('R14','Версионированные уточнения и файлы',['05','06'],['T06.1','T04.3','T04.4','T07.1'],['V31','V32','V33','V34']),('R15','Полный поток и профили',['08','09'],['T05.4','T05.5','T02.6'],['V36','V37','V39']),('R16','Демонстрация и промышленный допуск',['09','10'],['T06.5','T08.4'],['V40','V41'])])

'''
    if '# Applied once' not in text:text=text.replace('def write_workplan(out):',hook+'def write_workplan(out):')
    # Product-platform choice is conditional on environment, not a fabricated compatibility claim.
    text=text.replace('Принять Java 21, Boot 4.1.1 и Modulith 2.1.1;', 'Проверить Java 21, Boot 4.1.1 и кандидат Modulith 2.1.1;')
    text=text.replace('замена создаёт новую версию;', 'замена создаёт новый documentId со связью replacesDocumentId;')
    text=text.replace('Первый проверяемый путь: T01 → T02 → T03 → T04 → T05 → T06.', 'Первый проверяемый путь local-mvp: T01 → T02 → T03 → T04 → T05 → T06 с принятыми расширениями G01-G10 и проверками V30-V40. Кандидатные версии закрепляются до реализации; банковский вход и Kafka относятся к целевому профилю.')
    p.write_text(text)
    (B/'sources/review-workplan.json').write_text(json.dumps(dict(additions=BACKEND_ADDITIONS,tests=BACKEND_TESTS),ensure_ascii=False,indent=2))
    p=F/'sources/workplan.py';text=p.read_text()
    # Match graph edges to the real backend work, not just copy a proposal list.
    hook='''review=json.loads(Path(__file__).with_name('review-workplan.json').read_text())
for t in TASKS:
 if t['id'] in review['mapping']:t['existingBackendTasks']=review['mapping'][t['id']]
 if t['id'] in review['additions']:t['work']+=' '+review['additions'][t['id']]
TESTS.extend(tuple(t) for t in review['tests'])

'''
    pos=text.find('def write(')
    if 'review=json.loads(' not in text:text=text[:pos]+hook+text[pos:]
    text=text.replace('Сохранить базовый контракт 1.1.0-design; дополнения версионировать отдельно.', 'Реализовать согласованный контракт 1.2.0-design и отдельный demo-контракт; сохранить историю исходной спецификации.')
    text=text.replace('из базового и утверждённого дополнительного контракта', 'из согласованного публичного и отдельного demo-контракта')
    text=text.replace('вернуть активные операции при повторном входе', 'вернуть активные и недавние завершённые операции при повторном входе')
    text=text.replace('вернуть активные операции', 'вернуть активные и недавние завершённые операции')
    mapping={'B01':['T01.1','T01.2','T02.3'],'B02':['T03.1'],'B03':['T03.2'],'B04':['T04.2','T04.6'],'B05':['T04.2','T04.3','T04.5'],'B06':['T06.1'],'B07':['T05.4'],'B08':['T03.5','T05.4'],'B09':['T02.4','T05.1','T05.5','T06.3'],'B10':['T01.2','T06.5'],'B11':['T06.5','T02.6']}
    additions={'B01':'G01-G10 уже приняты на уровне проектирования; задача — реализовать и проверить, а не повторно выбрать контракт.', 'B06':'FIELD адресует fieldPath, DOCUMENT requirementId. Реализовать отдельный /draft/confirm-extraction и проверку draftVersion при /responses.', 'F08':'Компания общая для cookie-сессии; contextVersion передаётся в X-Company-Context, BroadcastChannel сообщает только смену поколения.', 'F13':'Для upload-intents и confirm-extraction нужен Idempotency-Key; для confirm также If-Match. В RFI подтверждение направляется только в отдельный черновик.', 'F16':'При resync сначала курсор-барьер, затем перечитывание всех активных ресурсов; complete=false не означает полный список.', 'F17':'Перед ответом опустошить очередь сохранения; отправить requestVersion, draftVersion, requirementsVersion и точные ссылки.', 'B09':'После перезагрузки не фильтровать active=true: команда могла завершиться до потери ответа.', 'F11':'Удаление необязательного поля кодировать clearFields, не нулём и не отсутствующим ключом.', 'B10':'APPROVE и ALTERNATIVE требуют DemoOfferTerms, операторская сессия имеет собственный тип и CSRF.'}
    p.write_text(text)
    (F/'sources/review-workplan.json').write_text(json.dumps(dict(mapping=mapping,additions=additions,tests=FRONTEND_TESTS),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
