"""Render every final page for explicit visual review, and check glyph bounds."""
from pathlib import Path
import hashlib
import json
import pypdfium2 as pdfium
from PIL import Image, ImageOps, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/'tmp/architecture-review-pdfs'
OUT=ROOT/'output/architecture-review'
FILES=[
 ('general-guide',ROOT/'output/credit-workspace-architecture-v2/architecture-v2/architecture-guide.pdf'),
 ('general-atlas',ROOT/'output/credit-workspace-architecture-v2/architecture-v2/architecture-atlas.pdf'),
 ('backend-guide',ROOT/'output/credit-workspace-backend-architecture/backend-development-guide.pdf'),
 ('backend-atlas',ROOT/'output/credit-workspace-backend-architecture/backend-architecture-atlas.pdf'),
 ('frontend-guide',ROOT/'output/credit-workspace-frontend-architecture/frontend-development-guide.pdf'),
 ('frontend-atlas',ROOT/'output/credit-workspace-frontend-architecture/frontend-architecture-atlas.pdf'),
 ('audit-report',OUT/'architecture-review.pdf')]

def main():
 TMP.mkdir(parents=True,exist_ok=True);result=[];contacts=[]
 for name,file in FILES:
  pdf=pdfium.PdfDocument(str(file));pages=[];bad=[];glyphs=0
  for pno,page in enumerate(pdf):
   tp=page.get_textpage();w,h=page.get_size()
   for index in range(tp.count_chars()):
    ch=tp.get_text_range(index,1)
    if not ch.strip():continue
    box=tp.get_charbox(index);glyphs+=1
    if min(box[0],box[1])<-.5 or box[2]>w+.5 or box[3]>h+.5:bad.append(dict(page=pno+1,char=ch,box=box))
   scale=(1900/w) if 'atlas' in name else 1.2
   img=page.render(scale=scale).to_pil().convert('RGB');p=TMP/f'{name}-{pno+1:03d}.png';img.save(p);pages.append(p)
   tp.close();page.close()
  per=2 if 'atlas' in name else 6
  for start in range(0,len(pages),per):
   if per==2:sheet=Image.new('RGB',(2000,1500),'#e8edf3');slots=[(20,10,1960,690),(20,760,1960,690)]
   else:sheet=Image.new('RGB',(1800,1740),'#e8edf3');slots=[(10+(i%3)*600,10+(i//3)*870,580,825) for i in range(6)]
   draw=ImageDraw.Draw(sheet)
   for i,p in enumerate(pages[start:start+per]):
    x,y,mw,mh=slots[i];image=ImageOps.contain(Image.open(p),(mw,mh));sheet.paste(image,(x,y));draw.text((x+4,y+mh+4),f'{name} page {start+i+1}',fill='black')
   cp=TMP/f'contact-{name}-{start//per+1:02d}.png';sheet.save(cp);contacts.append(str(cp))
  result.append(dict(file=str(file.relative_to(ROOT)),sha256=hashlib.sha256(file.read_bytes()).hexdigest(),pages=len(pdf),glyphsChecked=glyphs,outsidePage=bad))
  pdf.close()
 (OUT/'pdf-geometry-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 (TMP/'contact-index.json').write_text(json.dumps(contacts,indent=2))
 print(json.dumps(dict(pages=sum(x['pages'] for x in result),glyphs=sum(x['glyphsChecked'] for x in result),outside=sum(len(x['outsidePage']) for x in result),contacts=len(contacts)),ensure_ascii=False))
 if any(x['outsidePage'] for x in result):raise SystemExit('PDF geometry defects; review details')

if __name__=='__main__':main()
