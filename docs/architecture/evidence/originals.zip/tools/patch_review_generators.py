from pathlib import Path
import json
import re
import shutil

ROOT=Path(__file__).resolve().parents[1]
B=ROOT/'output/credit-workspace-backend-architecture'
F=ROOT/'output/credit-workspace-frontend-architecture'
G=ROOT/'output/credit-workspace-architecture-v2/architecture-v2'

def replace(path, before, after):
    text=path.read_text()
    if before in text:
        path.write_text(text.replace(before,after))

def backend_contracts():
    path=B/'sources/contracts.py';text=path.read_text()
    start=text.index('def build_client(');end=text.index('\ndef build_events(',start)
    text=text[:start]+'''def build_client(out,original):
    spec=json.loads(original.read_text())
    save(out/'api/demo-openapi.json',json.loads(original.with_name('demo-openapi.json').read_text()))
    catalog=[]
    for path,methods in spec['paths'].items():
        for method,op in methods.items():
            op.setdefault('x-deadline-ms',2000 if '/files/' not in path and '/events' not in path else 'Отдельный срок соединения')
            catalog.append(dict(method=method.upper(),path=path,sender='Браузер клиента',receiver=op.get('x-owner-module','workspace'),summary=op['summary'],request=op.get('requestBody',{}).get('content',{}).get('application/json',{}).get('schema',{}).get('$ref','Нет JSON-тела'),authentication='Cookie, актуальный contextVersion, объектные права; CSRF и Idempotency-Key/If-Match по контракту',deadline=op['x-deadline-ms'],failureCodes=list(op['responses'])))
    # Metadata must not introduce drift from the canonical contract.
    save(out/'api/interaction-catalog.json',catalog)
    save(out/'api/openapi.json',spec)
    return spec
''' + text[end:]
    # Do not let metadata make the backend copy differ from the shared public contract.
    text=text.replace("            op.setdefault('x-deadline-ms',2000 if '/files/' not in path and '/events' not in path else 'Отдельный срок соединения')\n",'')
    text=text.replace("deadline=op['x-deadline-ms']", "deadline=op.get('x-deadline-ms',2000)")
    text=text.replace("V={'type':'integer','minimum':1}","V={'type':'integer','minimum':1,'maximum':9007199254740991}")
    text=text.replace("'WithdrawalRequested':obj({'operationId':S,'externalRequestId':S,'expectedCaseVersion':V}),", "'WithdrawalRequested':obj({'operationId':S,'externalRequestId':S,'expectedCaseVersion':V},['operationId','externalRequestId']),")
    # Ref-based event shapes need a concrete normalized snapshot endpoint.
    needle="    save(out/'api/internal-openapi.json',spec)"
    injection='''    client=json.loads((out/'api/openapi.json').read_text())['components']['schemas']
    for name,schema in client.items():
        C.setdefault(name,copy.deepcopy(schema))
    C['CaseSnapshot']=obj({'caseId':S,'applicationId':S,'companyId':S,'caseVersion':V,'status':{'type':'string','enum':STATES[2:]},'informationRequests':arr(ref('InformationRequest')),'decision':ref('Decision'),'offers':arr(ref('Offer')),'recordedAt':DT},['caseId','applicationId','companyId','caseVersion','status','informationRequests','offers','recordedAt'])
    op('/internal/v1/cases/{caseId}/snapshot','get','Прочитать полный нормализованный банковский снимок для сверки и ссылочных событий',res='CaseSnapshot',role='reconciler/journey/offers/workspace',budget='2 с на локальный нормализованный снимок; получение реального банковского снимка согласуется отдельно')
    C['JobLease']['properties']['leaseToken']=copy.deepcopy(S);C['JobLease']['required'].append('leaseToken')
    for name in ['LeaseRenewal','ScanResult','ExtractionResult']:
        C[name]['properties'].update(workerId=copy.deepcopy(S),leaseToken=copy.deepcopy(S))
        C[name]['required']=list(dict.fromkeys(C[name]['required']+['workerId','leaseToken']))
    C['ScanResult']['oneOf']=[{'properties':{'verdict':{'enum':['CLEAN']}},'required':['cleanObjectRef']},{'properties':{'verdict':{'enum':['REJECTED','ERROR']}},'not':{'required':['cleanObjectRef']}}]
    C['TransferCheck']['properties'].update(contextVersion=copy.deepcopy(V),csrfToken=copy.deepcopy(S),origin=copy.deepcopy(S))
    C['TransferCheck']['required']+=['contextVersion','origin']
    C['TransferCheck']['description']='Для UPLOAD csrfToken обязателен; сессия и версия контекста проверяются при открытии и финализации. Источник identity берётся из доверенной сессии, не тела браузера.'
    C['TransferCheck']['oneOf']=[{'properties':{'action':{'enum':['UPLOAD']}},'required':['csrfToken']},{'properties':{'action':{'enum':['DOWNLOAD']}}}]
    C['UploadCompleted']['properties'].update(sessionReference=copy.deepcopy(S),contextVersion=copy.deepcopy(V),grant=copy.deepcopy(S))
    C['UploadCompleted']['required']+=['sessionReference','contextVersion','grant']
    C['UploadCompleted']['description']='CAS UPLOADING->QUARANTINED атомарен с проверкой отмены, точного размера/хеша, версии контекста, срока grant и созданием SCAN job. Повтор с тем же объектом возвращает прежний receipt; иные байты дают 409.'
    C['BankCommand']['description']='expectedVersion относится к payloadRef/package.version; версия банковского дела передаётся отдельно как expectedCaseVersion и проверяется адаптером. Служебный вход и Kafka используют один реестр externalRequestId, не две команды.'
    C['BankCommand']['properties']['expectedCaseVersion']=copy.deepcopy(V)
    C['CreditPackage']['properties']['data']={'oneOf':[ref('SubmissionPackage'),ref('AmendmentPackage'),ref('AcceptancePackage'),ref('WithdrawalPackage')]}
    C['SubmissionPackage']=obj({'kind':{'const':'SUBMISSION'},'productId':S,'productVersion':V,'terms':ref('Need'),'business':ref('Business'),'documentReferences':arr(ref('DocumentReference')),'consentRecordIds':arr(S),'requirementsVersion':V})
    C['AmendmentPackage']=obj({'kind':{'const':'AMENDMENT'},'requestId':S,'requestVersion':V,'draftVersion':V,'requirementsVersion':V,'amendment':ref('DraftPatch'),'documentReferences':arr(ref('DocumentReference')),'explanation':{'type':'string','maxLength':2000}},['kind','requestId','requestVersion','draftVersion','requirementsVersion','documentReferences'])
    C['AcceptancePackage']=obj({'kind':{'const':'ACCEPTANCE'},'offerId':S,'offerVersion':V,'actorRef':S})
    C['WithdrawalPackage']=obj({'kind':{'const':'WITHDRAWAL'},'expectedApplicationVersion':V,'expectedCaseVersion':V,'reason':S},['kind','expectedApplicationVersion'])
    C['CreditPackage']['description']='Синтетический MVP имеет явные схемы четырёх пакетов. packageType равен data.kind; несоответствие — 422. Банковский продукт использует отдельную согласованную схему и новую версию, а не произвольный JSON.'
    C['CreditPackage']['oneOf']=[{'properties':{'packageType':{'const':kind},'data':ref(name)}} for kind,name in [('SUBMISSION','SubmissionPackage'),('AMENDMENT','AmendmentPackage'),('ACCEPTANCE','AcceptancePackage'),('WITHDRAWAL','WithdrawalPackage')]]
    for operation in paths['/internal/v1/document-jobs/{jobId}/scan-result'].values():
        operation['description']+=' Проверять workerId и leaseToken, назначенную identity/роль SCAN, непросроченную аренду, generation и objectVersion; при CLEAN подтвердить чистый объект.'
    save(out/'api/internal-openapi.json',spec)'''
    if 'C[\'CaseSnapshot\']' not in text:text=text.replace(needle,injection)
    start=text.index("    (out/'api/contract-changes.md').write_text(")
    end=text.index('    return client,events,internal',start)
    text=text[:start]+'''    (out/'api/contract-changes.md').write_text("""# Согласованный контракт после аудита

Версия 1.2.0-design: 49 публичных операций; 6 demo-операций вынесены в demo-openapi.json. Общая архитектура и frontend baseline совпадают с клиентским контрактом. История исходных контрактов сохранена в architecture-review/originals.zip.

Приняты G01-G10: сессии демонстрации, черновик уточнения, требования к файлам, отмена/замена, capabilities, операторский контур, история, восстановление операций и адресуемые SSE. Дополнительно определено подтверждение OCR в черновике уточнения. Добавлены contextVersion, явная очистка полей, точные ссылки и версии требований, полные условия имитатора, типизированные пакеты MVP, привязка аренды к worker и нормализованный банковский снимок.

Это изменение проектной спецификации до реализации; совместимость несуществующего сервера не заявляется. Подробное обоснование: architecture-review/findings.json и отчёт аудита.
""")
''' + text[end:]
    path.write_text(text)

def frontend_contracts():
    old=F/'sources/contracts.py'
    # Preserve task mapping and examples as editable build inputs.
    examples=json.loads((F/'api/proposal-examples.json').read_text())
    for ex in examples:
        name=ex['schema'];v=ex['value']
        if name=='InformationDraft':v['requirementsVersion']=1
        if name=='DemoAction':v['offerTerms'].update(termsDisclosure='Синтетические условия, без обещания выдачи',validUntil='2026-10-21T05:00:00Z')
        if name=='ClientStreamMessage':v.update(companyId='company-a',contextVersion=1)
        if name=='OperationList':
            for o in v['items']:o.update(resourceId='app-1',companyId='company-a',createdAt='2026-10-20T05:00:00Z')
    (F/'sources/contract-examples.json').write_text(json.dumps(examples,ensure_ascii=False,indent=2))
    old.write_text('''from pathlib import Path
import copy,json
OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parent.parent
BASE=ROOT/'output/credit-workspace-backend-architecture/api/openapi.json'
def write():
 baseline=json.loads(BASE.read_text());demo=json.loads(BASE.with_name('demo-openapi.json').read_text())
 (OUT/'api/baseline-openapi.json').write_bytes(BASE.read_bytes())
 (OUT/'api/demo-openapi.json').write_bytes(BASE.with_name('demo-openapi.json').read_bytes())
 spec=copy.deepcopy(baseline);spec['paths'].update(demo['paths'])
 spec['info']['description']+=' Объединённый указатель для demo-инструментов; имя proposed-additions сохранено для ссылок, статус: согласовано на уровне проектирования.'
 (OUT/'api/proposed-additions.openapi.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2))
 changes=[dict(gap=f'G{i:02d}',kind='accepted-design',status='Включено в общий/backend контракт; реализация не выполнялась') for i in range(1,11)]
 changes.append(dict(kind='accepted-design',operation='POST /api/v1/applications/{applicationId}/information-requests/{requestId}/draft/confirm-extraction',reason='Неизменяемость исходного снимка'))
 (OUT/'api/changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2))
 (OUT/'api/proposal-examples.json').write_bytes((OUT/'sources/contract-examples.json').read_bytes())
 mapping={'B01':['T01.1','T01.2','T02.3'],'B02':['T03.1'],'B03':['T03.2'],'B04':['T04.2','T04.6'],'B05':['T04.2','T04.3','T04.5'],'B06':['T06.1'],'B07':['T05.4'],'B08':['T03.5','T05.4'],'B09':['T02.4','T05.1','T05.5','T06.3'],'B10':['T01.2','T06.5'],'B11':['T06.5','T02.6']}
 by={t['id']:t['title'] for t in json.loads((ROOT/'output/credit-workspace-backend-architecture/tasks.json').read_text())}
 (OUT/'api/backend-task-map.json').write_text(json.dumps([dict(frontendPackageTask=k,existingBackendTasks=[dict(id=i,title=by[i]) for i in v]) for k,v in mapping.items()],ensure_ascii=False,indent=2))
 catalog=[dict(method=m.upper(),path=p,summary=o['summary'],owner=o.get('x-owner-module'),status='Согласованная проектная спецификация 1.2.0-design') for p,methods in baseline['paths'].items() for m,o in methods.items()]
 (OUT/'api/baseline-operation-catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
 return spec
if __name__=='__main__':write()
''')

def builds():
    path=B/'sources/build.py'
    replace(path,"sys.path.insert(0,'/private/tmp/credit-architecture-validation')", "import os\nextra=os.environ.get('CREDIT_RENDER_DEPS')\nif extra:sys.path.insert(0,extra)")
    replace(path,"operation_count==39", "operation_count==49")
    replace(path,"'40 задач разработки · 29 сценариев приёмки · 10 схем'", "f'{len(TASKS)} задач разработки · {len(TESTS)} сценариев приёмки · 10 схем'")
    replace(path,"'Совместимость версий подтверждена документацией, не интеграционной сборкой'", "'Boot/Java проверены по документации; Modulith/Boot остаётся кандидатом T01.3, сборки приложения нет'")
    replace(path,"Java 21 + Spring Boot 4.1.1.", "Java 21 + Spring Boot 4.1.1 (проектная основа; совместная сборка с Modulith требует T01.3).")
    replace(path,"40 задач и 29 проверок", "40 задач и 41 проверка")
    replace(path,"исходные маршруты сохранены и уточнены.", "49 согласованных операций; demo-openapi.json содержит 6 изолированных demo-операций.")
    path=F/'sources/build.py'
    replace(path,"'Исходные 119 файлов не изменены'", "'Контрольные суммы актуальных входных файлов совпадают'")
    replace(path,"baseOperations=39", "baseOperations=49")
    replace(path,"и 30 сценариев приёмки", "и 38 сценариев приёмки")
    replace(path,"· 30 сценариев приёмки", "· {len(TESTS)} сценариев приёмки")
    replace(path,"с 15 новыми операциями и расширениями схем, не утверждённая и не реализованная", "с согласованными публичными и demo-операциями; имя файла сохранено для старых ссылок, реализация не выполнена")
    replace(path,"api/proposed-additions.openapi.json - полная предложенная редакция", "api/demo-openapi.json - отдельный demo-контракт. api/proposed-additions.openapi.json - объединённая согласованная редакция")
    # Source manifests are refreshed explicitly by the ordered root build, never to hide drift.
    replace(path,"invalid={'eventType':'view_changed','cursor':'x'}", "invalid={'eventType':'view_changed','cursor':'x','companyId':'company-a','contextVersion':1}")

def screens():
    p=F/'sources/screens.py'
    replacements=[('ПРЕДЛОЖЕНИЕ','Согласованное расширение'),('Предложение','Согласованный контракт'),('expiresAt','validUntil'),
       ('Согласованное расширение означает отсутствующий в исходном контракте метод или поле.','Расширения G01-G10 приняты в контракт 1.2.0-design; это спецификация будущей реализации.'),
       ('sourceConfirmationVersion; If-Match','sourceConfirmationVersion; If-Match; clearFields для явной очистки'),
       ('extractionId и версии полей по ConfirmExtraction','extractionId, documentVersion, objectVersion, confirmedFields; If-Match и Idempotency-Key'),
       ('requestVersion, documentReferences, Idempotency-Key; 202','requestVersion, draftVersion, requirementsVersion, documentIds, documentReferences, Idempotency-Key; 202'),
       ('Submit.documentReferences; Idempotency-Key','Submit.documentIds, documentReferences, requirementsVersion; Idempotency-Key'),
       ('X-Upload-Grant, CSRF; 204 = карантин','X-Upload-Grant, CSRF, X-Company-Context; Idempotency-Key для intent; 204 = карантин')]
    for a,b in replacements:replace(p,a,b)
    text=p.read_text();marker='def write():\n'
    injected='''def write():
 # Complete manager-driven interactions as explicit screen dependencies.
 for index,row in enumerate(SCREENS):
  row=list(row);interactions=list(row[9])
  if row[0]=='U01':interactions.insert(0,('Выбрать тестовый аккаунт','GET /demo/api/v1/accounts','Только фиксированные синтетические аккаунты demo-профиля','404 вне demo'))
  if row[0]=='U08':interactions.append(('Подтвердить OCR в уточнении','POST /api/v1/applications/{applicationId}/information-requests/{requestId}/draft/confirm-extraction','If-Match черновика ответа, Idempotency-Key, ConfirmExtraction; исходная анкета неизменна','409 закрыт запрос/устарел источник; 428'))
  if row[0]=='U11':interactions.append(('Восстановить команды и доступные действия','GET /api/v1/operations; GET /api/v1/applications/{applicationId}/capabilities','Все активные и недавние завершённые операции; applicationId, limit/cursor; разрешения — только подсказка','401/403/404/409 контекст'))
  row[9]=interactions;SCREENS[index]=tuple(row)
'''
    if '# Complete manager-driven' not in text:text=text.replace(marker,injected)
    text=text.replace("dataAndVersions=data,", "dataAndVersions=data+'; обязательные заголовки и тело — по api/baseline-openapi.json (demo — api/demo-openapi.json); X-Company-Context для выбранной компании',")
    p.write_text(text)

def diagrams():
    replacements={
      B/'sources/diagrams.py':[
       ('Компания, заявка, тип, размер и короткий срок действия','Компания, контекст, требование и версии; короткий срок'),
       ('Применение к черновику только по явному действию пользователя','Применение к исходному черновику или отдельному ответу на уточнение'),
       ('Сохраняет дополнение; исходный снимок неизменен','Сохраняет отдельный черновик и дополнение; снимок неизменен'),
       ('Все чувствительные данные и вычисления находятся внутри банковского контура.','Целевой банковский профиль: три домена отказа; резервирование проверяется испытанием.'),
       ('Сначала надёжная запись в кабинете, затем передача банку.','Сначала надёжная запись в кабинете, затем передача банку.'),
       ('Защита хранилищ и копий, ключи, сроки хранения, испытания и репетиция восстановления.','Защита хранилищ и копий, ключи, сроки хранения, испытания и репетиция восстановления.')],
      F/'sources/diagrams.py':[
       ('Сессия, компания, маршруты, тема и подключение обновлений','Сессия, версия контекста компании, маршруты и обновления'),
       ('Отдельный черновик ответа','Отдельный черновик и подтверждение полей'),
       ('Получить снимок и курсор','Получить курсор и перечитать активные данные'),
       ('Предложения серверу','Согласованные серверные методы')],
      ROOT/'tools/atlas_revision.py':[
       ('Согласия, данные и файлы проверены','Согласия, данные и версии файлов проверены')]
    }
    for p,pairs in replacements.items():
      for a,b in pairs:replace(p,a,b)

def main():
    backend_contracts();frontend_contracts();builds();screens();diagrams()

if __name__=='__main__':main()
