"""Ordered rebuild. Run from any directory with the rendering dependencies installed."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
G=ROOT/'output/credit-workspace-architecture-v2'
B=ROOT/'output/credit-workspace-backend-architecture'
F=ROOT/'output/credit-workspace-frontend-architecture'

def run(script):
    subprocess.run([sys.executable,str(script)],cwd=ROOT,check=True,env=os.environ.copy())

def main():
    # The nested general package is canonical; output/architecture-v2 is a render mirror.
    shutil.copytree(G/'architecture-v2',ROOT/'output/architecture-v2',dirs_exist_ok=True)
    run(ROOT/'tools/build_architecture.py')
    run(ROOT/'tools/build_package.py')
    for name in ['build_architecture.py','build_package.py','atlas_revision.py','wireframes.py']:
        shutil.copy2(ROOT/'tools'/name,G/'sources'/name)
    shutil.copytree(ROOT/'output/architecture-v2',G/'architecture-v2',dirs_exist_ok=True)
    run(B/'sources/build.py')
    inputs=[G,B]
    files={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in inputs for p in sorted(folder.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='.DS_Store'}
    (F/'source-manifest.json').write_text(json.dumps(dict(date='2026-10-20',files=files,inputPolicy='Refreshed only by ordered root rebuild after rebuilding upstream; standalone frontend build detects drift.'),ensure_ascii=False,indent=2))
    run(F/'sources/build.py')
    run(ROOT/'tools/validate_architecture_review.py')
    run(ROOT/'tools/build_review_report.py')
    print('Rebuilt. Visual review of the new PDF hashes is required; no previous visual pass is inherited.')

if __name__=='__main__':main()
