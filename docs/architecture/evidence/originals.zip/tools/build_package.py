from pathlib import Path
import sys, json, re, hashlib, html, zipfile
import xml.etree.ElementTree as ET
from reportlab.platypus import SimpleDocTemplate, BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, Table, TableStyle, KeepTogether, Image
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader
import pypdfium2 as pdfium

ROOT=Path(__file__).resolve().parents[1]; OUT=(ROOT/'architecture-v2' if (ROOT/'architecture-v2').is_dir() else ROOT/'output'/'architecture-v2')
sys.path.insert(0,str(ROOT/'tools'))
from build_architecture import FONT_DIR, INK, MUTED, RED
from wireframes import Wireframe, write_svg
for name,file in [('DV','DejaVuSans.ttf'),('DV-B','DejaVuSans-Bold.ttf'),('DV-M','DejaVuSansMono.ttf')]:
    if name not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont(name,str(FONT_DIR/file)))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-B',italic='DV',boldItalic='DV-B')
STATES=['DRAFT','SUBMITTED','REVIEW','MANUAL','NEEDS_INFO','APPROVED','ALTERNATIVE','DECLINED','ACCEPTED','COMPLETED','CANCELLED','EXPIRED']

def api():
    canonical=OUT/'sources/client-contract.json'
    if canonical.exists():
        spec=json.loads(canonical.read_text())
        (OUT/'api/openapi.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
        return spec
    S={}
    def ref(name):return {'$ref':f'#/components/schemas/{name}'}
    def obj(props,req=(),desc=None):
        o={'type':'object','properties':props}
        if req:o['required']=list(req)
        if desc:o['description']=desc
        return o
    def arr(item):return {'type':'array','items':item}
    st={'type':'string'};id_=dict(st,description='Непрозрачный идентификатор; без прямых ПДн');integer={'type':'integer','format':'int64','minimum':0};dt={'type':'string','format':'date-time'}
    S['Money']=obj({'amountMinor':integer,'currency':{'type':'string','enum':['RUB']}},['amountMinor','currency'])
    S['FieldError']=obj({'field':st,'message':st},['field','message'])
    S['Error']=obj({'code':st,'message':st,'correlationId':id_,'fieldErrors':arr(ref('FieldError'))},['code','message','correlationId'])
    S['Company']=obj({'companyId':id_,'displayName':st,'taxId':st,'roles':arr(st),'sourceUpdatedAt':dt},['companyId','displayName','roles'])
    S['Session']=obj({'userId':id_,'displayName':st,'companyId':id_,'expiresAt':dt,'csrfToken':st},['userId','expiresAt','csrfToken'])
    S['SelectCompany']=obj({'companyId':id_},['companyId'])
    S['Product']=obj({'productId':id_,'version':integer,'name':st,'purpose':st,'minAmount':ref('Money'),'maxAmount':ref('Money'),'minMonths':integer,'maxMonths':integer,'preliminaryDisclosure':st},['productId','version','name','preliminaryDisclosure'])
    S['Need']=obj({'purpose':st,'amount':ref('Money'),'termMonths':{'type':'integer','minimum':1},'urgency':{'type':'string','enum':['NORMAL','URGENT']}},['purpose','amount','termMonths'])
    S['RecommendationInput']=obj({'companyId':id_,'need':ref('Need')},['companyId','need'])
    S['Recommendation']=obj({'product':ref('Product'),'explanation':st,'ruleVersion':st},['product','explanation','ruleVersion'])
    S['CreateApplication']=obj({'companyId':id_,'productId':id_,'productVersion':integer,'need':ref('Need')},['companyId','productId','productVersion','need'])
    S['Business']=obj({'annualRevenue':ref('Money'),'annualExpenses':ref('Money'),'currentDebt':ref('Money'),'businessAgeMonths':integer,'activityDescription':st,'sourceConfirmationVersion':st},desc='Минимальный пример синтетического продукта; Промышленные поля определяются продуктом и банковской системой рассмотрения.')
    S['DraftPatch']=obj({'purpose':st,'amount':ref('Money'),'termMonths':{'type':'integer','minimum':1},'business':ref('Business'),'confirmedExtractionIds':arr(id_)})
    S['Application']=obj({'applicationId':id_,'companyId':id_,'productId':id_,'productVersion':integer,'version':integer,'status':{'type':'string','enum':STATES},'terms':ref('DraftPatch'),'updatedAt':dt},['applicationId','companyId','version','status','updatedAt'])
    S['Submit']=obj({'expectedVersion':integer,'consentRecordIds':arr(id_),'documentIds':arr(id_)},['expectedVersion','consentRecordIds','documentIds'])
    S['CommandReceipt']=obj({'operationId':id_,'applicationId':id_,'acceptedAt':dt,'statusUrl':st},['operationId','acceptedAt','statusUrl'])
    S['NextAction']=obj({'type':{'type':'string','enum':['CONTINUE','PROVIDE_INFORMATION','VIEW_OFFER','WAIT','VIEW_RESULT']},'label':st,'targetPath':st},['type','label'])
    S['StatusEvent']=obj({'eventId':id_,'occurredAt':dt,'label':st},['eventId','occurredAt','label'])
    S['StatusView']=obj({'applicationId':id_,'status':{'type':'string','enum':STATES},'viewVersion':integer,'sourceVersion':integer,'updatedAt':dt,'stale':{'type':'boolean'},'nextAction':ref('NextAction'),'history':arr(ref('StatusEvent'))},['applicationId','status','viewVersion','updatedAt','stale','nextAction'])
    S['ConsentInput']=obj({'applicationId':id_,'subjectId':id_,'purpose':st,'textVersion':st},['applicationId','subjectId','purpose','textVersion'])
    S['ConsentRecord']=obj({'consentId':id_,'subjectId':id_,'purpose':st,'textVersion':st,'recordedAt':dt,'status':{'type':'string','enum':['GIVEN','REVOKED','EXPIRED']}},['consentId','subjectId','purpose','textVersion','recordedAt','status'])
    S['UploadInput']=obj({'fileName':st,'declaredMimeType':{'type':'string','enum':['application/pdf','image/jpeg','image/png']},'sizeBytes':{'type':'integer','minimum':1,'maximum':10485760},'documentType':st,'requestId':id_},['fileName','declaredMimeType','sizeBytes','documentType'])
    S['UploadIntent']=obj({'uploadId':id_,'documentId':id_,'uploadUrl':st,'grant':st,'expiresAt':dt,'maxBytes':integer},['uploadId','documentId','uploadUrl','grant','expiresAt','maxBytes'],desc='URL только file gateway того же банковского origin. Короткий scoped grant передаётся заголовком, не query.')
    S['Document']=obj({'documentId':id_,'applicationId':id_,'version':integer,'fileName':st,'scanState':{'type':'string','enum':['UPLOADING','QUARANTINED','CLEAN','REJECTED','DELETED']},'extractionState':{'type':'string','enum':['NOT_REQUESTED','PENDING','READY','FAILED','CONFIRMED']},'extractionId':id_},['documentId','applicationId','version','scanState','extractionState'])
    S['ExtractionField']=obj({'name':st,'value':st,'confidence':{'type':'number','minimum':0,'maximum':1},'page':{'type':'integer','minimum':1}},['name','value','confidence'])
    S['Extraction']=obj({'extractionId':id_,'documentId':id_,'documentVersion':integer,'fields':arr(ref('ExtractionField')),'modelVersion':st},['extractionId','documentId','documentVersion','fields','modelVersion'])
    S['ConfirmExtraction']=obj({'extractionId':id_,'documentVersion':integer,'confirmedFields':arr(ref('ExtractionField'))},['extractionId','documentVersion','confirmedFields'])
    S['DownloadIntent']=obj({'downloadUrl':st,'grant':st,'expiresAt':dt},['downloadUrl','grant','expiresAt'])
    S['InformationItem']=obj({'itemId':id_,'kind':{'type':'string','enum':['FIELD','DOCUMENT','EXPLANATION']},'label':st,'reason':st,'required':{'type':'boolean'}},['itemId','kind','label','required'])
    S['InformationRequest']=obj({'requestId':id_,'version':integer,'items':arr(ref('InformationItem')),'deadline':dt,'status':st},['requestId','version','items','status'])
    S['InformationResponse']=obj({'requestVersion':integer,'amendment':ref('DraftPatch'),'documentIds':arr(id_),'explanation':st},['requestVersion','documentIds'])
    S['Decision']=obj({'decisionId':id_,'caseVersion':integer,'outcome':{'type':'string','enum':['APPROVED','ALTERNATIVE','NEEDS_INFO','DECLINED']},'publicExplanation':st,'offerIds':arr(id_)},['decisionId','caseVersion','outcome','publicExplanation'])
    S['Offer']=obj({'offerId':id_,'applicationId':id_,'version':integer,'status':{'type':'string','enum':['AVAILABLE','ACCEPTED','EXPIRED','WITHDRAWN']},'amount':ref('Money'),'termMonths':integer,'termsDisclosure':st,'validUntil':dt,'documentIds':arr(id_)},['offerId','applicationId','version','status','amount','termMonths','termsDisclosure','validUntil'])
    S['AcceptOffer']=obj({'offerVersion':integer},['offerVersion'])
    S['Withdrawal']=obj({'expectedVersion':integer,'reason':st},['expectedVersion'])
    S['Operation']=obj({'operationId':id_,'status':{'type':'string','enum':['PENDING','SUCCEEDED','FAILED','RECONCILING']},'applicationId':id_,'updatedAt':dt,'safeMessage':st},['operationId','status','updatedAt'])
    S['FeedCard']=obj({'contentId':id_,'title':st,'summary':st,'publishedAt':dt,'reasonCategory':st,'targetPath':st},['contentId','title','summary','targetPath'])
    S['Feed']=obj({'nextAction':ref('NextAction'),'cards':arr(ref('FeedCard')),'rankingMode':{'type':'string','enum':['MODEL','RULES']}},['cards','rankingMode'])
    S['InboxItem']=obj({'notificationId':id_,'applicationId':id_,'title':st,'createdAt':dt,'read':{'type':'boolean'},'targetPath':st},['notificationId','title','createdAt','read','targetPath'])
    S['ConsentRequirement']=obj({'purpose':st,'subjectId':id_,'textVersion':st,'text':st,'requiredForOperation':{'type':'boolean'},'actorMayConsent':{'type':'boolean'}},['purpose','subjectId','textVersion','text','requiredForOperation','actorMayConsent'])
    S['ConsentRequirementList']=obj({'items':arr(ref('ConsentRequirement'))},['items'])
    S['ContentArticle']=obj({'contentId':id_,'version':integer,'title':st,'bodyText':st,'category':st,'publishedAt':dt},['contentId','version','title','bodyText','publishedAt'])
    S['Feedback']=obj({'companyId':id_,'applicationId':id_,'screenId':st,'questionId':st,'rating':{'type':'integer','minimum':1,'maximum':5}},['companyId','screenId','questionId','rating'])
    S['DocumentList']=obj({'items':arr(ref('Document')),'nextCursor':st},['items'])
    for name,item in [('CompanyList','Company'),('ProductList','Product'),('ApplicationList','Application'),('ConsentList','ConsentRecord'),('InformationRequestList','InformationRequest'),('InboxList','InboxItem')]:
        S[name]=obj({'items':arr(ref(item)),'nextCursor':st},['items'])
    paths={}
    def op(path,method,summary,result=None,body=None,status='200',idem=False,cas=False,query=(),description=None):
        o={'operationId':method+'_'+re.sub('[^a-zA-Z0-9]+','_',path).strip('_'),'summary':summary,'tags':[path.split('/')[3] if len(path.split('/'))>3 else 'session'],'responses':{}}
        if description:o['description']=description
        params=[{'name':n,'in':'path','required':True,'schema':id_} for n in re.findall(r'\{(\w+)\}',path)]
        for n in query:params.append({'name':n,'in':'query','required':False,'schema':{'type':'integer','minimum':1,'maximum':100,'default':20} if n=='limit' else st})
        if method in ['post','patch','put','delete']:params.append({'name':'X-CSRF-Token','in':'header','required':True,'schema':st})
        if idem:params.append({'name':'Idempotency-Key','in':'header','required':True,'schema':{'type':'string','minLength':16,'maxLength':128}})
        if cas:params.append({'name':'If-Match','in':'header','required':True,'schema':st,'description':'ETag версии текущего черновика'})
        if params:o['parameters']=params
        if body:o['requestBody']={'required':True,'content':{'application/json':{'schema':ref(body)}}}
        response={'description':'Accepted for processing; не кредитное одобрение' if status=='202' else 'Success'}
        if result:response['content']={'application/json':{'schema':ref(result)}}
        if result=='Application':response['headers']={'ETag':{'description':'Версия черновика','schema':st}}
        o['responses'][status]=response
        for code in ['400','401','403','404','409','422','429','503']:
            o['responses'][code]={'description':{'409':'Version, state or idempotency conflict','429':'Rate limit; соблюдать Retry-After'}.get(code,'Safe error'),'content':{'application/json':{'schema':ref('Error')}}}
        if body=='UploadInput':
            for code in ['413','415']:o['responses'][code]={'description':'File rejected by declared limit/type','content':{'application/json':{'schema':ref('Error')}}}
        paths.setdefault(path,{})[method]=o
    base='/api/v1'
    op(base+'/session','get','Текущая сессия','Session')
    op(base+'/session/company','post','Выбрать компанию с повторной проверкой полномочий','Session','SelectCompany')
    op(base+'/logout','post','Завершить сессию',status='204')
    op(base+'/companies','get','Разрешённые компании','CompanyList',query=['cursor','limit'])
    op(base+'/companies/{companyId}','get','Компания и полномочия','Company')
    op(base+'/products','get','Версионированный каталог','ProductList',query=['companyId','cursor','limit'])
    S['RecommendationList']=obj({'items':arr(ref('Recommendation'))},['items'])
    op(base+'/recommendations','post','Подобрать продукты без создания кредитной заявки','RecommendationList','RecommendationInput')
    ap=base+'/applications'
    op(ap,'get','Список заявок выбранной компании','ApplicationList',query=['companyId','cursor','limit'])
    op(ap,'post','Создать черновик','Application','CreateApplication','201',True)
    app=ap+'/{applicationId}'
    op(app,'get','Черновик или отправленный снимок','Application')
    op(app,'patch','Сохранить черновик','Application','DraftPatch',cas=True)
    op(app+'/submit','post','Надёжно принять пакет заявки','CommandReceipt','Submit','202',True)
    op(app+'/status','get','Клиентская проекция статуса','StatusView')
    op(app+'/consents','get','Согласия для заявки','ConsentList')
    op(app+'/consent-requirements','get','Тексты, цели, субъекты и допустимость согласий','ConsentRequirementList')
    op(app+'/consents','post','Зафиксировать согласие субъекта','ConsentRecord','ConsentInput','201',True)
    op(base+'/consents/{consentId}/revocation','post','Зафиксировать отзыв согласия и пересмотреть будущие операции','ConsentRecord',idem=True)
    op(app+'/documents/upload-intents','post','Разрешение загрузки в file gateway','UploadIntent','UploadInput','201',True)
    op(app+'/documents','get','Список документов заявки','DocumentList',query=['cursor','limit'])
    op(base+'/documents/{documentId}','get','Метаданные и статус документа','Document')
    op(base+'/documents/{documentId}/extraction','get','Кандидаты полей OCR','Extraction')
    op(app+'/confirm-extraction','post','Подтвердить OCR-поля для черновика','Application','ConfirmExtraction',idem=True,cas=True)
    op(base+'/documents/{documentId}/download-intents','post','Разрешение на контролируемое скачивание','DownloadIntent',status='201')
    op(app+'/information-requests','get','Запросы уточнения банка','InformationRequestList',query=['cursor','limit'])
    op(app+'/information-requests/{requestId}/responses','post','Отправить уточнение без новой заявки','CommandReceipt','InformationResponse','202',True)
    op(app+'/withdrawal','post','Запросить отзыв по правилам владельца','CommandReceipt','Withdrawal','202',True)
    op(app+'/decision','get','Разрешённый для клиента результат','Decision')
    op(base+'/offers/{offerId}','get','Актуальные условия через X03','Offer')
    op(base+'/offers/{offerId}/acceptance','post','Принять актуальную версию предложения','CommandReceipt','AcceptOffer','202',True)
    op(base+'/operations/{operationId}','get','Результат команды / сверки','Operation')
    op(base+'/feed','get','Next action и персонализированная лента','Feed',query=['companyId'])
    op(base+'/content/{contentId}','get','Утверждённая статья внутри кабинета','ContentArticle')
    op(base+'/feedback','post','Необязательная оценка понятности шага',body='Feedback',status='204')
    op(base+'/inbox','get','Внутрипродуктовые уведомления','InboxList',query=['companyId','cursor','limit'])
    op(base+'/inbox/{notificationId}/read','post','Отметить прочитанным',status='204')
    op(base+'/events','get','SSE разрешённых обновлений',description='Перед подключением snapshot; Last-Event-ID/cursor для resync; правила scopes в interfaces.md.')
    paths[base+'/events']['get']['parameters']=[{'name':'Last-Event-ID','in':'header','required':False,'schema':st},{'name':'companyId','in':'query','required':True,'schema':id_}]
    paths[base+'/events']['get']['responses']['200']={'description':'Авторизованный поток; не долговечное хранилище','content':{'text/event-stream':{'schema':st}}}
    for path,item in paths.items():
        for method,o in item.items():
            for p in o.get('parameters',[]):
                if p['name']=='companyId' and p['in']=='query':p['required']=True
    spec={'openapi':'3.0.3','info':{'title':'Credit Workspace - проект клиентского API','version':'1.0.0-draft','description':'Архитектурный контракт. Не API Альфа-Банка и не исполняемое приложение. Синтетические данные MVP. Подробные правила: docs/interfaces.md.'},'servers':[{'url':'https://credit.bank.example','description':'Условный origin; зарезервированное .example имя'}],'security':[{'SessionCookie':[]}],'paths':paths,'components':{'securitySchemes':{'SessionCookie':{'type':'apiKey','in':'cookie','name':'credit_session'}},'schemas':S}}
    (OUT/'api'/'openapi.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
    return spec

def previews():
    doc=pdfium.PdfDocument(OUT/'architecture-atlas.pdf')
    (OUT/'png').mkdir(exist_ok=True)
    for i,page in enumerate(doc):
        image=page.render(scale=.85).to_pil()
        slug=json.loads((OUT/'diagram-manifest.json').read_text())[i]['id']
        image.save(OUT/'png'/f'{slug}.png')
        if i==0:image.save(OUT/'preview.png')

def inline(text):
    x=html.escape(text)
    x=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',x)
    x=re.sub(r'`([^`]+)`',r'<font name="DV-M">\1</font>',x)
    # Clickable primary-source URLs, line wrapping handled by Paragraph.
    x=re.sub(r'(https://[^\s<]+)',r'<link href="\1" color="#4468ad">\1</link>',x)
    return x

class GuideDoc(BaseDocTemplate):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.idx=0
        frame=Frame(self.leftMargin,self.bottomMargin,self.width,self.height,id='normal')
        self.addPageTemplates(PageTemplate(id='normal',frames=frame,onPage=self.chrome))
    def beforeDocument(self):
        self.idx=0
    def chrome(self,c,d):
        c.setFillColor(colors.HexColor(MUTED));c.setFont('DV',8)
        if d.page>1:
            c.drawString(44,A4[1]-25,'УМНЫЙ КРЕДИТНЫЙ КАБИНЕТ / АРХИТЕКТУРА v2')
            c.setStrokeColor(colors.HexColor('#dfe4ea'));c.line(44,A4[1]-33,A4[0]-44,A4[1]-33)
        c.drawString(44,23,'20.10.2026 · Проектное предложение · Допущения требуют проверки')
        c.drawRightString(A4[0]-44,23,str(d.page))
    def afterFlowable(self,f):
        if isinstance(f,Paragraph) and f.style.name in ['Chapter','Heading2']:
            if f.getPlainText()=='Содержание':return
            level=0 if f.style.name=='Chapter' else 1
            if level==1 and not re.match(r'U\d\d\.',f.getPlainText()):return
            self.idx+=1;key='heading-'+str(self.idx)
            self.canv.bookmarkPage(key);self.canv.addOutlineEntry(f.getPlainText(),key,level,False)
            self.notify('TOCEntry',(level,f.getPlainText(),self.page,key))

def guide():
    styles={
      'body':ParagraphStyle('Body',fontName='DV',fontSize=9.3,leading=13.4,textColor=colors.HexColor(INK),spaceAfter=7,splitLongWords=True),
      'chapter':ParagraphStyle('Chapter',fontName='DV-B',fontSize=22,leading=28,textColor=colors.HexColor(INK),spaceAfter=18,keepWithNext=True),
      'h2':ParagraphStyle('Heading2',fontName='DV-B',fontSize=14,leading=19,textColor=colors.HexColor(INK),spaceBefore=13,spaceAfter=8,keepWithNext=True),
      'h3':ParagraphStyle('Heading3',fontName='DV-B',fontSize=11.2,leading=16,textColor=colors.HexColor(INK),spaceBefore=10,spaceAfter=6,keepWithNext=True),
      'cell':ParagraphStyle('Cell',fontName='DV',fontSize=8.1,leading=11.6,textColor=colors.HexColor(INK),splitLongWords=True),
      'th':ParagraphStyle('TH',fontName='DV-B',fontSize=8.1,leading=11.6,textColor=colors.HexColor(INK),splitLongWords=True),
    }
    doc=GuideDoc(str(OUT/'architecture-guide.pdf'),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=47,bottomMargin=43,title='Кредитный кабинет - архитектура и интерфейс v2',author='Architecture design')
    story=[]
    story += [Spacer(1,15),Paragraph('АРХИТЕКТУРА / 20.10.2026',ParagraphStyle('Eyebrow',fontName='DV-B',fontSize=10,leading=15,textColor=colors.HexColor(RED))),Spacer(1,18),Paragraph('Умный кредитный<br/>кабинет предпринимателя',ParagraphStyle('Cover',fontName='DV-B',fontSize=29,leading=36,textColor=colors.HexColor(INK))),Spacer(1,17),Paragraph('Банковский контур и минимальная демонстрационная версия',styles['h2']),Paragraph('Архитектура, пользовательский путь, поведение 15 экранов, взаимодействия сервисов, ML, персональные данные, нагрузка и восстановление.',styles['body']),Spacer(1,10)]
    im=Image(str(OUT/'preview.png'));im.drawWidth=doc.width;im.drawHeight=doc.width*1320/2000;story += [im,Spacer(1,12),Paragraph('<b>Статус:</b> проектное предложение. Не описание действующей системы Альфа-Банка. Нагрузочные показатели и SLO - расчётные гипотезы. Приложение в рамках этого пакета не создавалось.',styles['body']),PageBreak()]
    story.append(Paragraph('Содержание',styles['chapter']))
    toc=TableOfContents();toc.levelStyles=[ParagraphStyle('TOC0',fontName='DV-B',fontSize=10,leading=15,spaceBefore=10),ParagraphStyle('TOC1',fontName='DV',fontSize=9,leading=13,leftIndent=14,spaceBefore=3)]
    story += [toc,PageBreak()]
    filenames=['architecture','screens','interfaces','security-operations','decisions-requirements']
    chapters=['1. Архитектурные решения','2. Спецификация экранов','3. Взаимодействия и контракты','4. Безопасность и эксплуатация','5. Решения и трассировка']
    for ci,(name,title) in enumerate(zip(filenames,chapters)):
        if ci:story.append(PageBreak())
        story.append(Paragraph(title,styles['chapter']))
        lines=(OUT/'docs'/f'{name}.md').read_text().splitlines(); i=1
        while i<len(lines):
            line=lines[i].strip()
            if not line:i+=1;continue
            if line.startswith('## '):
                heading=line[3:]
                match=re.match(r'U(\d\d)\.',heading) if name=='screens' else None
                if match:story.append(PageBreak())
                story.append(Paragraph(inline(heading),styles['h2']))
                if match:
                    story += [Wireframe(int(match.group(1)),doc.width),Spacer(1,5),Paragraph('Схема компоновки. Синтетические данные; не работающий интерфейс.',styles['cell']),Spacer(1,9)]
                i+=1;continue
            if line.startswith('### '):story.append(Paragraph(inline(line[4:]),styles['h3']));i+=1;continue
            if line.startswith('|'):
                rows=[]
                while i<len(lines) and lines[i].strip().startswith('|'):
                    row=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                    if not all(re.fullmatch(r':?-+:?',v.replace(' ','')) for v in row):rows.append(row)
                    i+=1
                count=len(rows[0]);ratios={2:[.29,.71],3:[.25,.37,.38],4:[.20,.25,.25,.30]}.get(count,[1/count]*count)
                cells=[[Paragraph(inline(v),styles['th'] if ri==0 else styles['cell']) for v in row] for ri,row in enumerate(rows)]
                tab=Table(cells,colWidths=[doc.width*r for r in ratios],repeatRows=1,hAlign='LEFT')
                tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eaf0f7')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.7,colors.HexColor('#bdcbd9')),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#dce3ea')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f8fafc')])]))
                story.extend([tab,Spacer(1,9)]);continue
            if line.startswith('- '):
                story.append(Paragraph(inline(line[2:]),styles['body'],bulletText='•'));i+=1;continue
            para=[line];i+=1
            while i<len(lines) and lines[i].strip() and not re.match(r'^(#|\||- )',lines[i].strip()):para.append(lines[i].strip());i+=1
            story.append(Paragraph(inline(' '.join(para)),styles['body']))
    doc.multiBuild(story)

def gallery():
    boards=json.loads((OUT/'diagram-manifest.json').read_text())
    cards='\n'.join(f'<article><a href="svg/{b["id"]}.svg"><img src="svg/{b["id"]}.svg" alt="{html.escape(b["title"])}"></a><h2>{html.escape(b["title"])}</h2><a href="svg/{b["id"]}.svg">Открыть SVG</a> · <a href="png/{b["id"]}.png">PNG</a></article>' for b in boards)
    page='''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Кредитный кабинет / Архитектура v2</title><style>*{box-sizing:border-box}body{margin:0;background:#f2f4f7;color:#182839;font:16px/1.6 system-ui,sans-serif}header,main,footer{max-width:1500px;margin:auto;padding:32px}header{border-bottom:4px solid #d64740}h1{font-size:36px;line-height:1.2;max-width:1000px}h2{font-size:20px;margin-bottom:4px}p{max-width:1000px}nav{display:flex;flex-wrap:wrap;gap:16px}a{color:#315b9a}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,500px),1fr));gap:24px}article{background:white;padding:20px;border:1px solid #dce3ea;border-radius:10px}img{width:100%;height:auto;display:block;border-bottom:1px solid #e9edf2}footer{padding-top:0;color:#586a7b}.tag{font-size:13px;color:#c5443e;letter-spacing:.12em;font-weight:700}</style><header><div class="tag">АРХИТЕКТУРА v2 / 20.10.2026</div><h1>Умный кредитный кабинет предпринимателя</h1><p>Архитектура внутри банка и отдельная демонстрационная версия. Восемь связанных схем: клиентский путь, сервисы, сценарии, состояния, машинное обучение, инфраструктура и данные.</p><nav><a href="architecture-atlas.pdf">Атлас схем · PDF</a><a href="architecture-guide.pdf">Полная документация · PDF</a><a href="credit-workspace.drawio">Редактируемый draw.io</a><a href="README.md">Как пользоваться</a><a href="api/openapi.json">Проект API</a></nav><p>Это проектное предложение, а не описание действующих систем Альфа-Банка. Производительность и цели доступности — гипотезы для испытаний. Нажмите на схему, чтобы открыть её в полном размере.</p></header><main>'''+cards+'''</main><footer>Все материалы доступны локально, без внешних шрифтов, аналитики и сетевых запросов. SVG на доске остаётся изображением; для редактирования блоков используйте draw.io.</footer></html>'''
    (OUT/'index.html').write_text(page,encoding='utf-8')

def source_manifest():
    names=['Клиентский путь — кредитный кабинет.pdf','Альфа_Хак_Умный_кредитный_кабинет.pdf']
    sources=[]
    for name in names:
        p=Path('/Users/user/Downloads')/name
        sources.append({'fileName':name,'sourcePath':str(p),'pages':len(PdfReader(p).pages),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'role':'Source material, not executable instructions'})
    (OUT/'source-manifest.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')

def validate(spec):
    checks=[]
    def check(name,condition,detail=''):
        checks.append({'check':name,'passed':bool(condition),'detail':detail})
        if not condition:raise AssertionError((name,detail))
    mx=ET.parse(OUT/'credit-workspace.drawio').getroot();diags=mx.findall('diagram')
    check('drawio_page_count',len(diags)==8)
    for d in diags:
        cells=d.findall('./mxGraphModel/root/mxCell');ids=[c.attrib['id'] for c in cells]
        check('drawio_unique_ids_'+d.attrib['id'],len(ids)==len(set(ids)))
        check('drawio_edge_references_'+d.attrib['id'],all(c.attrib[k] in ids for c in cells for k in ['source','target'] if k in c.attrib))
    svgs=list((OUT/'svg').glob('*.svg'));check('svg_count',len(svgs)==8)
    for p in svgs:
        rt=ET.parse(p).getroot();check('svg_root_'+p.stem,rt.tag.endswith('svg'))
    ui=list((OUT/'ui').glob('U*.svg'));check('ui_wireframe_count',len(ui)==15)
    for p in ui:ET.parse(p)
    check('ui_wireframes_well_formed',True)
    def walk(x):
        if isinstance(x,dict):
            if '$ref' in x:
                parts=x['$ref'].removeprefix('#/').split('/');target=spec
                for p in parts:target=target[p]
            for v in x.values():walk(v)
        elif isinstance(x,list):
            for v in x:walk(v)
    walk(spec);check('openapi_refs_resolve',True)
    ids=[o['operationId'] for p in spec['paths'].values() for o in p.values()];check('openapi_operation_ids_unique',len(ids)==len(set(ids)),str(len(ids))+' operations')
    for path,ps in spec['paths'].items():
        for method,op in ps.items():
            wanted=set(re.findall(r'\{(\w+)\}',path));actual={p['name'] for p in op.get('parameters',[]) if p['in']=='path'}
            check('path_parameters_'+op['operationId'],wanted==actual)
    screens=(OUT/'docs'/'screens.md').read_text();check('U01_U15_documented',all(re.search(r'## U'+f'{i:02}'+r'\.',screens) for i in range(1,16)))
    interfaces=(OUT/'docs'/'interfaces.md').read_text();check('F01_F33_documented',all('F'+f'{i:02}' in interfaces for i in range(1,34)))
    check('state_enum_complete',spec['components']['schemas']['Application']['properties']['status']['enum']==STATES)
    for fname,count in [('architecture-atlas.pdf',8),('architecture-guide.pdf',None)]:
        doc=PdfReader(OUT/fname);text='\n'.join(p.extract_text() or '' for p in doc.pages)
        check('pdf_pages_'+fname,len(doc.pages)==count if count else len(doc.pages)>20,str(len(doc.pages)))
        check('pdf_cyrillic_'+fname,'кредит' in text.lower())
        if fname=='architecture-atlas.pdf':
            codes=r'\b[BXMDFUSCEOI]\d{2}\b'
            unexplained=r'\b(?:LOS|HMAC|BFF|OCR|IAM|RFI|CSRF|TLS|SSE|HPA|DR|TTL|DMZ|WAF|RBAC|ABAC|DRAFT|SUBMITTED|REVIEW|MANUAL|NEEDS_INFO|APPROVED|DECLINED|EXPIRED)\b'
            check('atlas_no_visible_service_codes',not re.search(codes,text))
            check('atlas_no_unexplained_acronyms',not re.search(unexplained,text))
            check('atlas_explains_simplified_data_handling','Шифрование данных и хеширование идентификаторов пока не проектируем' in text)
        else:
            check('guide_matches_simplification','HMAC' not in text and 'Данные и резервные копии шифруются' not in text)
    report={'status':'passed','date':'2026-10-20','scope':'Artifact structural/content checks only; no application load/security/ML tests performed','checks':checks}
    (OUT/'validation-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report

def package():
    archive=ROOT/'output'/'credit-workspace-architecture-v2.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():z.write(p,Path('architecture-v2')/p.relative_to(OUT))
        for p in sorted((ROOT/'tools').glob('*.py')):z.write(p,Path('sources')/p.name)
    print('Archive:',archive)

if __name__=='__main__':
    spec=api();previews();source_manifest();write_svg(OUT/'ui');guide();gallery();report=validate(spec);package()
    print('Validation:',len(report['checks']),'checks; guide pages:',len(PdfReader(OUT/'architecture-guide.pdf').pages))
