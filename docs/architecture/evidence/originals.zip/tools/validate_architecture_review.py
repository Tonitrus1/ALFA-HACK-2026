"""Executable checks of design artifacts, not tests of an implemented bank system."""
from pathlib import Path
import copy
import hashlib
import json
import re
import sys
import warnings
import xml.etree.ElementTree as ET

from openapi_spec_validator import validate as validate_openapi
from openapi_schema_validator import OAS30Validator, OAS31Validator
from jsonschema import Draft202012Validator, FormatChecker
with warnings.catch_warnings():
    warnings.simplefilter('ignore', DeprecationWarning)
    from jsonschema import RefResolver

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/architecture-review'
G=ROOT/'output/credit-workspace-architecture-v2/architecture-v2'
B=ROOT/'output/credit-workspace-backend-architecture'
F=ROOT/'output/credit-workspace-frontend-architecture'
CHECKS=[]
FIXTURES=[]

def read(path):return json.loads(path.read_text())

def ck(name, result, detail=''):
    CHECKS.append(dict(check=name,passed=bool(result),detail=detail))

def fixture(spec,name,value,valid,title):
    cls=OAS31Validator if spec['openapi'].startswith('3.1') else OAS30Validator
    validator=cls(spec['components']['schemas'][name],resolver=RefResolver.from_schema(spec),format_checker=FormatChecker())
    errors=list(validator.iter_errors(value))
    FIXTURES.append(dict(name=title,schema=name,expectedValid=valid,value=value))
    ck('fixture:'+title,(not errors)==valid,str(errors[0].message)[:300] if errors else '')

def resolve_refs(spec):
    def walk(node):
        if isinstance(node,dict):
            if '$ref' in node:
                reference=node['$ref'];assert reference.startswith('#/'),reference
                target=spec
                for p in reference[2:].split('/'):target=target[p.replace('~1','/').replace('~0','~')]
            for value in node.values():walk(value)
        elif isinstance(node,list):
            for value in node:walk(value)
    walk(spec)

def contracts():
    public=read(B/'api/openapi.json');demo=read(B/'api/demo-openapi.json');internal=read(B/'api/internal-openapi.json')
    ck('contracts-identical',public==read(G/'api/openapi.json')==read(F/'api/baseline-openapi.json'))
    ck('contract-source-current',public==read(G/'sources/client-contract.json'))
    ck('demo-contracts-identical',demo==read(G/'api/demo-openapi.json')==read(F/'api/demo-openapi.json'))
    ck('mirror-contract-identical',public==read(ROOT/'output/architecture-v2/api/openapi.json'))
    for name,spec in [('public',public),('demo',demo),('internal',internal),('combined',read(F/'api/proposed-additions.openapi.json'))]:
        try:validate_openapi(spec);resolve_refs(spec);ck('openapi:'+name,True)
        except Exception as e:ck('openapi:'+name,False,str(e)[:1000])
        ids=[o['operationId'] for methods in spec['paths'].values() for o in methods.values()]
        ck('unique-operation-ids:'+name,len(ids)==len(set(ids)))
    ck('operation-counts',sum(map(len,public['paths'].values()))==49 and sum(map(len,demo['paths'].values()))==6)
    ck('demo-isolation',all(not p.startswith('/demo/') for p in public['paths']) and all(o.get('x-demo-only') for methods in demo['paths'].values() for o in methods.values()))
    exceptions={'/api/v1/session','/api/v1/logout','/api/v1/companies','/api/v1/companies/{companyId}'}
    for path,methods in public['paths'].items():
        for method,op in methods.items():
            headers={p['name']:p for p in op.get('parameters',[]) if p['in']=='header'}
            if path not in exceptions:ck('context-header:'+method+path,headers.get('X-Company-Context',{}).get('required'))
            if method in {'post','patch','put','delete'}:ck('csrf:'+method+path,headers.get('X-CSRF-Token',{}).get('required'))
            if any(x in path for x in ['/upload-intents','/confirm-extraction','/submit','/responses','/withdrawal','/acceptance']):
                if method=='post':ck('idempotency:'+path,headers.get('Idempotency-Key',{}).get('required'))
            if 'confirm-extraction' in path or method=='patch':ck('etag-condition:'+method+path,headers.get('If-Match',{}).get('required') and '428' in op['responses'])
            if '202' in op['responses']:ck('location:'+path,'Location' in op['responses']['202'].get('headers',{}))
            if '/files/' in path:
                ck('binary-errors:'+method+path,all(r.get('content',{}).get('application/json',{}).get('schema',{}).get('$ref')=='#/components/schemas/Error' for code,r in op['responses'].items() if code.startswith(('4','5'))))
            ck('no-store:'+method+path,all('Cache-Control' in r.get('headers',{}) for r in op['responses'].values()))
    lookup=public['paths']['/api/v1/operations']['get']
    active=next(p for p in lookup['parameters'] if p['name']=='active')
    ck('operation-recovery',active['schema']=={'type':'boolean','default':False} and not active['required'])
    ck('internal-only-external-id','externalRequestId' not in public['components']['schemas']['Operation']['properties'])
    ck('internal-case-snapshot','/internal/v1/cases/{caseId}/snapshot' in internal['paths'])
    return public,demo,internal

def examples(public,demo,internal):
    for ex in read(F/'api/proposal-examples.json'):
        fixture(public,ex['schema'],ex['value'],True,'frontend-example-'+ex['schema']+str(len(FIXTURES)))
    item={'itemId':'item-1','kind':'FIELD','label':'Доход','required':True,'fieldPath':'business.annualRevenue'}
    fixture(public,'InformationItem',item,True,'information-item-field-valid')
    invalid=copy.deepcopy(item);invalid.pop('fieldPath');fixture(public,'InformationItem',invalid,False,'information-item-field-needs-target')
    invalid=copy.deepcopy(item);invalid['fieldPath']='status';fixture(public,'InformationItem',invalid,False,'information-item-forbidden-field')
    item.update(kind='DOCUMENT',requirementId='req-1');item.pop('fieldPath');fixture(public,'InformationItem',item,True,'information-item-document-valid')
    invalid=copy.deepcopy(item);invalid.pop('requirementId');fixture(public,'InformationItem',invalid,False,'information-item-document-needs-target')
    fixture(public,'DraftPatch',{'clearFields':['business.annualRevenue']},True,'clear-fields-valid')
    fixture(public,'DraftPatch',{'clearFields':['amount']},False,'clear-required-terms-forbidden')
    fixture(public,'DraftPatch',{'confirmedExtractionIds':['fake']},False,'forged-confirmation-forbidden')
    fixture(public,'DraftPatch',{},False,'empty-draft-patch-forbidden')
    extraction={'extractionId':'ext-1','documentVersion':2,'objectVersion':'obj-v1','confirmedFields':[{'name':'annualRevenue','value':'100000'}]}
    fixture(public,'ConfirmExtraction',extraction,True,'confirm-extraction-valid')
    invalid=copy.deepcopy(extraction);invalid['confirmedFields'][0]['confidence']=1;fixture(public,'ConfirmExtraction',invalid,False,'confidence-not-client-controlled')
    invalid=copy.deepcopy(extraction);invalid.pop('objectVersion');fixture(public,'ConfirmExtraction',invalid,False,'extraction-source-required')
    submit={'expectedVersion':2,'consentRecordIds':['consent-1'],'documentIds':['doc-1'],'documentReferences':[{'documentId':'doc-1','documentVersion':3,'objectVersion':'obj-v1'}],'requirementsVersion':1}
    fixture(public,'Submit',submit,True,'submit-valid')
    for name in ['documentReferences','requirementsVersion']:
        invalid=copy.deepcopy(submit);invalid.pop(name);fixture(public,'Submit',invalid,False,'submit-needs-'+name)
    response={'requestVersion':2,'draftVersion':3,'requirementsVersion':1,'documentIds':[],'documentReferences':[],'explanation':'Искусственное пояснение'}
    fixture(public,'InformationResponse',response,True,'information-response-valid')
    invalid=copy.deepcopy(response);invalid.pop('draftVersion');fixture(public,'InformationResponse',invalid,False,'information-response-needs-draft-version')
    upload=read(F/'api/proposal-examples.json')[-1]['value']
    fixture(public,'UploadInput',upload,True,'upload-valid')
    for name in ['expectedDocumentVersion','requirementId']:
        invalid=copy.deepcopy(upload);invalid.pop(name);fixture(public,'UploadInput',invalid,False,'upload-needs-'+name)
    invalid=copy.deepcopy(upload);invalid['requestId']='rfi-1';fixture(public,'UploadInput',invalid,False,'upload-request-version-required')
    invalid['requestVersion']=2;fixture(public,'UploadInput',invalid,True,'upload-rfi-context-valid')
    for value in [0,9007199254740992]:
        invalid=copy.deepcopy(upload);invalid['expectedDocumentVersion']=value;fixture(public,'UploadInput',invalid,False,'version-invalid-'+str(value))
    action={'action':'APPROVE','expectedCaseVersion':2,'clientMessage':'Одобрено в демонстрации','internalReason':'Синтетика','offerTerms':{'amount':{'amountMinor':100000,'currency':'RUB'},'termMonths':12,'termsDisclosure':'Искусственные условия','validUntil':'2026-10-21T00:00:00Z'}}
    fixture(demo,'DemoAction',action,True,'demo-offer-complete')
    for name in ['termsDisclosure','validUntil']:
        invalid=copy.deepcopy(action);invalid['offerTerms'].pop(name);fixture(demo,'DemoAction',invalid,False,'demo-offer-needs-'+name)
    invalid=copy.deepcopy(action);invalid.pop('offerTerms');fixture(demo,'DemoAction',invalid,False,'demo-approve-needs-offer')
    scan={'generation':2,'workerId':'worker-1','leaseToken':'lease-secret','objectVersion':'obj-1','verdict':'CLEAN','engineVersion':'synthetic-av-1','cleanObjectRef':'clean-object-1'}
    fixture(internal,'ScanResult',scan,True,'scan-clean-valid')
    for name in ['leaseToken','workerId','cleanObjectRef']:
        invalid=copy.deepcopy(scan);invalid.pop(name);fixture(internal,'ScanResult',invalid,False,'scan-needs-'+name)
    scan['verdict']='ERROR';scan.pop('cleanObjectRef');fixture(internal,'ScanResult',scan,True,'scan-error-remains-quarantine')
    snapshot={'cursor':'cursor-1','generatedAt':'2026-10-20T00:00:00Z','applications':[],'companyId':'company-a','contextVersion':1,'complete':False}
    fixture(public,'StreamSnapshot',snapshot,True,'stream-snapshot-barrier')
    snapshot['complete']=True;fixture(public,'StreamSnapshot',snapshot,False,'stream-snapshot-not-complete-company')
    package={'packageId':'package-1','packageType':'ACCEPTANCE','applicationId':'app-1','companyId':'company-a','version':1,'createdAt':'2026-10-20T00:00:00Z','data':{'kind':'ACCEPTANCE','offerId':'offer-1','offerVersion':2,'actorRef':'actor-1'}}
    fixture(internal,'CreditPackage',package,True,'credit-package-typed')
    package['data']={'anything':'untyped'};fixture(internal,'CreditPackage',package,False,'credit-package-arbitrary-json-forbidden')

def events():
    schema=read(B/'schemas/events-v1.schema.json');Draft202012Validator.check_schema(schema)
    validator=Draft202012Validator(schema,format_checker=FormatChecker())
    files=list((B/'examples').glob('*.json'));ck('event-example-count',len(files)==16)
    for p in files:
        value=read(p);ck('event-example:'+p.stem,validator.is_valid(value))
        bad=copy.deepcopy(value);bad['payload']['unexpected']='x';ck('event-unknown-field:'+p.stem,not validator.is_valid(bad))
        bad=copy.deepcopy(value);bad['aggregateVersion']=0;ck('event-zero-version:'+p.stem,not validator.is_valid(bad))
    topics=read(B/'schemas/topics.json');types=[t for topic in topics for t in topic['eventTypes']]
    ck('event-topic-coverage',len(types)==len(set(types))==16 and set(types)==set(schema['$defs']))
    bank=next(t for t in topics if t['topic']=='credit.bank-results.v1')
    ck('bank-topic-consumers',set(bank.get('consumerModules',[]))=={'journey','workspace','offers'} and bank.get('allowedProducers')==['integration'])

def graphs():
    modules=read(B/'sources/module-dependencies.json')
    completed=set()
    def walk_module(name,stack):
        if name in stack:raise AssertionError('Module cycle: '+name)
        if name in completed:return
        for dependency in modules[name]:walk_module(dependency,stack|{name})
        completed.add(name)
    try:
        for name in modules:walk_module(name,set())
        ck('module-dependency-dag',len(completed)==len(modules) and 'workspace' not in modules['applications'])
    except Exception as error:ck('module-dependency-dag',False,str(error))
    for package in [B,F]:
        tasks=read(package/'tasks.json');by={t['id']:t for t in tasks};seen=set();active=set()
        def visit(id):
            if id in active:raise AssertionError('Cycle:'+id)
            if id in seen:return
            active.add(id)
            for dep in by[id]['dependencies']:visit(dep)
            active.remove(id);seen.add(id)
        try:
            for id in by:visit(id)
            ck('task-graph:'+package.name,len(by)==len(tasks)==len(seen))
        except Exception as e:ck('task-graph:'+package.name,False,str(e))
        cases=read(package/'acceptance-cases.json');ids=[v['id'] for v in cases]
        ck('case-ids:'+package.name,len(ids)==len(set(ids)))
        if package==F:
            ck('task-tests-exist',all(set(t['tests'])<=set(ids) for t in tasks))
    backend_ids={t['id'] for t in read(B/'tasks.json')}
    for t in read(F/'tasks.json'):
        ck('backend-task-links:'+t['id'],set(t['existingBackendTasks'])<=backend_ids)
    matrix=read(F/'interaction-matrix.json');spec=read(F/'api/proposed-additions.openapi.json')
    ck('screen-coverage',{r['screen'] for r in matrix}=={f'U{i:02d}' for i in range(1,16)})
    for r in matrix:
        for api in r['api'].split('; '):
            method,path=api.split(' ',1);ck('operations-covered:'+r['screen']+':'+api,method.lower() in spec['paths'].get(path,{}))

def drawings():
    for package,filename,count in [(G,'credit-workspace.drawio',8),(B,'backend-architecture.drawio',10),(F,'frontend-architecture.drawio',12)]:
        root=ET.parse(package/filename).getroot();diagrams=root.findall('diagram');ck('drawio-pages:'+package.name,len(diagrams)==count)
        for d in diagrams:
            cells=d.findall('.//mxCell');ids={c.get('id') for c in cells};ck('drawio-ids:'+d.get('id'),len(ids)==len(cells))
            edges=d.findall('.//mxCell[@edge="1"]')
            ck('drawio-bindings:'+package.name+':'+d.get('id'),all(e.get('source') in ids and e.get('target') in ids for e in edges),str(len(edges))+' connections')
        for svg in package.rglob('*.svg'):
            ET.parse(svg)
        ck('svg-parse:'+package.name,True)

def content():
    general=(G/'docs/security-operations.md').read_text();backend=(B/'docs/06-security-operations.md').read_text()
    ck('slo-consistency',all(value in general and value in backend for value in ['99,95%','300 мс','500 мс','30 минут']))
    ck('generator-portability','/private/tmp/credit-architecture-validation' not in (B/'sources/build.py').read_text())
    ck('receipt-semantics','повтор 201-команды' in (B/'docs/04-interfaces.md').read_text())
    ck('general-ui-signing','В MVP кнопка называется «Смоделировать подписание»' not in (G/'docs/screens.md').read_text())

def main():
    public,demo,internal=contracts();examples(public,demo,internal);events();graphs();drawings();content()
    failed=[c for c in CHECKS if not c['passed']]
    report=dict(status='passed' if not failed else 'failed',date='2026-10-20',scope='Static contract and documentation checks only; no application, bank integration, load, security certification or ML validation executed',checks=CHECKS,counts=dict(checks=len(CHECKS),failed=len(failed),contractFixtures=len(FIXTURES)))
    (OUT/'validation-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    (OUT/'contract-fixtures.json').write_text(json.dumps(FIXTURES,ensure_ascii=False,indent=2))
    print(json.dumps(dict(status=report['status'],counts=report['counts'],failures=failed),ensure_ascii=False,indent=2))
    if failed:sys.exit(1)

if __name__=='__main__':main()
